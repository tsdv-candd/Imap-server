#include "SslServer.h"

#include <QFile>
#include <QSslSocket>
//#include <QtGlobal>

#include "timap.h"

SslServer::SslServer(QObject *parent) : QTcpServer(parent)
{
    startTlsInitialized = false;


    cfg = new Conf();
    fctn = new Fonctions();
    fDomaines = new Domaines();
    fMails = new Mails();

    readOrWrite = 0; // 0 read only, > 0 read/write

    listStats.clear();
    selectedBox.clear();
    appendSent = false;
    selectedDirectory.clear();
    selectedSubDirectory.clear();
    myIpAddress = fctn->aMailServerIpAddress();
    erreurCommande = 0;
    idleClient.clear();
    hostConnectedIp.clear();
    xAuthLogin.clear();
    xAuthUser.clear();
    xAuthDomaine.clear();
    _userDir.clear();
    _fileMails.clear();
    _fileUids.clear();
    statIdentification = false;
    appendClient.clear();
    listDirsStr.clear();
    _validFlags = "Deleted Seen Draft Answered Flagged *";
    maxInferiors = 3; // -1 Sans limite; 0 creation interdite; autre valeur (ex: 3) 3 sous-dossiers ;
    currentClient.clear();
    nbCurrentInferiors = 0;


   connect(this, SIGNAL(error(QString)), this, SLOT(slError(QString)));


}



void SslServer::slError(const QString err)
{
    qDebug() << "sssssssssssssssssss" << err;
}




void SslServer::incomingConnection(int socketDescriptor)
{

    QSslSocket *sslSocket = new QSslSocket(this);


    if(! sslSocket->setSocketDescriptor(socketDescriptor))
    {
        emit error(sslSocket->errorString());
        return;

    }


    if(getSecurity())
    {
        sslSocket->setLocalCertificate(m_sslLocalCertificate);
        sslSocket->setPrivateKey(m_sslPrivateKey);
        sslSocket->setProtocol(m_sslProtocol);

        if(security.toUpper() == "SSL")
        {
            sslSocket->startServerEncryption();
            qDebug() << "\t\t#" << security;
        }
        else
        {
            qDebug() << "\t\t+ " << security;
        }


    }
    else
        qDebug() << "\t\t- " << security;


    connect(sslSocket, SIGNAL(readyRead()), this, SLOT(readyRead()), Qt::DirectConnection);
    connect(sslSocket, SIGNAL(disconnected()), this, SLOT(disconnected()), Qt::DirectConnection);




    hostConnectedIp = sslSocket->peerAddress().toString();



    qDebug() << socketDescriptor << " client connected...[" + hostConnectedIp + ":" + QString::number( port )+"]";

    if(security.toUpper() == "TLS")
    {
        security = "STARTTLS1";
    }


    const QString starttls(security.contains("STARTTLS", Qt::CaseInsensitive) ? " STARTTLS" : "");

    // IDLE = informer le client si un nouveau message !!
    capability = "IMAP4 IMAP4rev1 NAMESPACE QUOTA ID IDLE UNSELECT" + starttls;



    QStringList listIsPermittedIp(fctn->isPermittedIp(hostConnectedIp, "IMAP"));
    // authentification = listIsPermittedIp.at(0).toInt();
    int closeConnection = listIsPermittedIp.at(1).toInt();


    if(closeConnection > 0)
    {
        const QString forbidden("* BAD Forbidden ! You don't have"
                                " permission to access in this server"
                                " from IP %1. Goodbye");
        sendData(sslSocket, forbidden.arg(hostConnectedIp));
        log("-", forbidden.arg(hostConnectedIp));
        sslSocket->close();
        //! Pas de deleteLater(); ici
    }
    else
    {
        sendData(sslSocket, "* OK " + cfg->imapBienvenue);
        log("-", "* OK " + capability);
        this->addPendingConnection(sslSocket);
    }


    // Si le client se connecte mais durant 30 minutes (recommandé par la RFC)
    // n’envoie pas de données, on le déconnecte automatiquement

    // Si le client se connecte mais durant un certain temps
    // (n’envoie pas de données), on le déconnecte automatiquement
    if(cfg->imapDeconnectionClient > 0)
    {
        if(! sslSocket->waitForReadyRead(10000))
            //     if(! sslSocket->waitForReadyRead((cfg->imapDeconnectionClient * 60000)))
        {
            sendData(sslSocket, "Connection timeout");
            sslSocket->close();
        }
    }


}







void SslServer::setParams(
        const QString _grp, const QString _addr, const qint16 _port,
        const QString _security, QSsl::SslProtocol _protocol, const QString _certificate,
        const QString _key
        )
{

    grp = _grp;
    addr = _addr;
    port = _port;
    security = _security;
    protocol = _protocol;
    certificate = _certificate;
    key = _key;
}





const QSslCertificate &SslServer::getSslLocalCertificate() const
{
    return m_sslLocalCertificate;
}

const QSslKey &SslServer::getSslPrivateKey() const
{
    return m_sslPrivateKey;
}

QSsl::SslProtocol SslServer::getSslProtocol() const
{
    return m_sslProtocol;
}



void SslServer::setSslLocalCertificate(const QSslCertificate &certificate)
{
    m_sslLocalCertificate = certificate;
}

bool SslServer::setSslLocalCertificate(const QString &path, QSsl::EncodingFormat format)
{
    QFile certificateFile(path);

    if (!certificateFile.open(QIODevice::ReadOnly))
        return false;

    m_sslLocalCertificate = QSslCertificate(certificateFile.readAll(), format);
    return true;
}


void SslServer::setSslPrivateKey(const QSslKey &key)
{
    m_sslPrivateKey = key;
}

bool SslServer::setSslPrivateKey(const QString &fileName, QSsl::KeyAlgorithm algorithm, QSsl::EncodingFormat format, const QByteArray &passPhrase)
{
    QFile keyFile(fileName);

    if (!keyFile.open(QIODevice::ReadOnly))
        return false;

    m_sslPrivateKey = QSslKey(keyFile.readAll(), algorithm, format, QSsl::PrivateKey, passPhrase);
    return true;
}


void SslServer::setSslProtocol(QSsl::SslProtocol protocol)
{
    m_sslProtocol = protocol;
}



bool SslServer::getSecurity() const
{
    const QStringList listProtocol(QStringList() << "SSL" << "TLS" << "STARTTLS0" << "STARTTLS1");
    return listProtocol.contains(security, Qt::CaseInsensitive);
}



void SslServer::disconnected()
{

    QSslSocket *sslSocket = (QSslSocket *)sender();
    qDebug() << sslSocket->socketDescriptor() << " disconnected";
    idleClient.clear();

    //sslSocket->close();
    sslSocket->deleteLater();

}





void SslServer::nbInferiors(const QString dirPath)
{

    if(dirPath == "/") return;

    ++nbCurrentInferiors;
    QDir folder(dirPath);
    folder.setFilter(QDir::NoDotAndDotDot | QDir::AllEntries);
    foreach(QFileInfo fileInfo, folder.entryInfoList())
    {
        if(fileInfo.isDir())
        {
            nbInferiors(fileInfo.absoluteFilePath());
        }

    }
}








void SslServer::slIdle(QString file)
{

    if(idleClient.isEmpty()) return;

    if(idleStats.count() < 3)
    {
        idleStats.clear();
        idleStats << "0" << "0" << "0";
    }
    QString idleExists(idleStats.at(0));
    QString idleRecent(idleStats.at(1));
    QString idleExpunge(idleStats.at(2));


    QStringList myListStats(stats(fctn->base64Encode("INBOX")));

    QString exists(myListStats.at(0));
    QString recent(myListStats.at(1));
    QString expunge(myListStats.at(6));


    QSslSocket *sslSocket = (QSslSocket *)sender();
    if(idleExists != exists)
    {
        sendData(sslSocket, "* " + exists + " EXISTS");
    }
    if(idleRecent != recent)
    {
        sendData(sslSocket, "* " + recent + " RECENT");
    }
    if(idleExpunge != expunge)
    {
        sendData(sslSocket, "* " + expunge + " EXPUNGE");
    }

    idleStats.clear();

    idleStats << exists << idleRecent << idleExpunge;

}






void SslServer::readyRead()
{

    QSslSocket *sslSocket = (QSslSocket *)sender();


    // if (sslSocket->canReadLine()) {

    QRegExp rx;
    rx.setCaseSensitivity(Qt::CaseInsensitive);
    rx.setMinimal(true);
    QString responseLine;

    do
    {
        responseLine = sslSocket->readLine();
        sslSocket->flush();

        if(! _lastData.endsWith("\r\n"))
            _lastData += responseLine;

        _received += responseLine;
    }
    while(sslSocket->canReadLine());


    QString stringData = _lastData;//.replace(QRegExp("\r\n|\r|\n"), "\r\n");


    QString newCommand = stringData.trimmed();

    if(! stringData.endsWith("\r\n"))
    {
        return;
    }












    if(! appendSent)
    {
        qDebug() << sslSocket->socketDescriptor() << "Reception [" + newCommand + "]";

        if(newCommand.isEmpty())
        {
            newCommand.clear();
            _lastData.clear();

            sendData(sslSocket, currentClient + " BAD - command can't be empty!");
            log("", currentClient + " BAD - command can't be empty!");
            erreurCommande++;
            return;
        }

    }




    //! Trop de commandes invalides
    if (cfg->imapNombreDeCommandesInvalides > 0 && erreurCommande > cfg->imapNombreDeCommandesInvalides)
    {
        sendData(sslSocket, currentClient + " BAD - Too many invalid commands ! Goodbye");
        log(newCommand, currentClient + " BAD - Too many invalid commands ! Goodbye");
        erreurCommande = 0;
        newCommand.clear();
        _lastData.clear();
        sslSocket->close();
        return;
    }





    // Command too long RFC 2683 (https://tools.ietf.org/html/rfc2683)

    if(newCommand.size() > 8000)
    {
        QString copy(newCommand);
        newCommand.clear();
        _lastData.clear();

        sendData(sslSocket, currentClient + " BAD - Command too long. Command lenght: " + QString::number(newCommand.size()) + "; Max size allowed per command: 8000");
        log(copy, currentClient + " BAD - Command too long. Command lenght: " + QString::number(newCommand.size()) + "; Max size allowed per command: 8000");
        erreurCommande++;
        return;
    }





    //! -----------------------------------------------------------------
    //! STARTTLS see https://tools.ietf.org/html/rfc2595
    //! -----------------------------------------------------------------
    if(security.toUpper() == "STARTTLS0" || security.toUpper() == "STARTTLS1")
    {
        rx.setPattern("(.*)STARTTLS\\s*$");
        if(rx.exactMatch(newCommand))
        {
            QString copy(newCommand);
            newCommand.clear();
            _lastData.clear();
            rx.indexIn(copy);
            currentClient = rx.capturedTexts().at(1).trimmed();
            sendData(sslSocket, currentClient + " OK Begin TLS negotiation now");
            sslSocket->startServerEncryption();

            startTlsInitialized = true;
            return;
        }

    }




    //! -----------------------------------------------------------------
    //! CAPABILITY COMMAND
    //! -----------------------------------------------------------------

    rx.setPattern("(.*)CAPABILITY\\s*$");
    if(rx.exactMatch(newCommand))
    {
        QString copy(newCommand);
        newCommand.clear();
        _lastData.clear();
        rx.indexIn(copy);

        currentClient = rx.cap(1).trimmed();

        sendData(sslSocket, "* CAPABILITY " + capability);
        sendData(sslSocket, currentClient + " OK CAPABILITY completed");

        return;
    }






    if(security.toUpper() == "STARTTLS1" && ! startTlsInitialized)
    {

        rx.setPattern("([\\w\\.]+) (.*)\\s*$");

        if(rx.exactMatch(newCommand))
        {

            QString copy(newCommand);

            rx.indexIn(copy);
            currentClient = rx.cap(1).trimmed();

        }

        sendData(sslSocket, currentClient + " BAD [ALERTE] Please use STARTTLS command! It is required for " + addr + " on port " + QString::number(port));

        newCommand.clear();
        _lastData.clear();

        return;
    }










    //! <QUOTA : SETQUOTA, GETQUOTA, GETQUOTAROOT>


    // <SETQUOTA>
    rx.setPattern("([\\w\\.]+) SETQUOTA(.*)\\s*$");

    if(rx.exactMatch(newCommand))
    {

        QString copy(newCommand);
        newCommand.clear();
        _lastData.clear();

        rx.indexIn(copy);
        currentClient = rx.cap(1).trimmed();

        if(! begin(sslSocket, currentClient, false))
        {
            return;
        }

        sendData(sslSocket, currentClient + " NO - Setquota permission denied");
        log(copy, currentClient + " NO - Setquota permission denied");

        return;
    }

    // </SETQUOTA>




    // <GETQUOTA>
    rx.setPattern("([\\w\\.]+) GETQUOTA( (.*))?\\s*$");

    if(rx.exactMatch(newCommand))
    {

        QString copy(newCommand);
        newCommand.clear();
        _lastData.clear();

        rx.indexIn(copy);
        currentClient = rx.cap(1).trimmed();

        if(! begin(sslSocket, currentClient, false))
        {
            return;
        }

        QString data("* QUOTA \"\" (STORAGE%1 MESSAGE%2)"), argument1(" 0 0"), argument2(" 0 0");

        const qint64 quotaLimit(fctn->iniReturnValue(_fileMails, xAuthUser, "quota").toLongLong());
        const qint64 nombreDeMailPermis(fctn->iniReturnValue(_fileMails, xAuthUser, "nombreDeMailPermis").toLongLong());

        QList<qint64> quotaList(fctn->quotaGet(_userDir));
        const qint64 nbMailActuel(quotaList.at(0));
        const qint64 quotaActuel(quotaList.at(1));


        /*
                    if(quotaLimit > 0)
                    {
                        argument1 = " " + QString::number(quotaActuel) + " " +  QString::number(quotaLimit);
                    }
                    if(nombreDeMailPermis > 0)
                    {
                        argument2 = " " + QString::number(nbMailActuel) + " " +  QString::number(nombreDeMailPermis);
                    }
                    */
        argument1 = " " + QString::number(quotaActuel) + " " +  QString::number(quotaLimit);
        argument2 = " " + QString::number(nbMailActuel) + " " +  QString::number(nombreDeMailPermis);


        sendData(sslSocket, data.arg(argument1).arg(argument2));
        log(copy, data.arg(argument1).arg(argument2));


        sendData(sslSocket, currentClient + " OK GETQUOTA Completed");
        log(copy, currentClient + " OK GETQUOTA Completed");

        return;
    }



    // </GETQUOTA>


    // <GETQUOTAROOT>
    rx.setPattern("([\\w\\.]+) GETQUOTAROOT (\")?(.*)\\2\\s*$");

    if(rx.exactMatch(newCommand))
    {

        QString copy(newCommand);
        newCommand.clear();
        _lastData.clear();

        rx.indexIn(copy);
        currentClient = rx.cap(1).trimmed();
        QString inbox(formatChemain(rx.cap(3).trimmed()));

        QString myInbox = inbox;
        myInbox.replace("/", ".");

        inbox = returnDir(inbox);


        if(! begin(sslSocket, currentClient, false))
        {
            return;
        }

        const QString mailsIni(fctn->chemain(_userDir + inbox + "/mails.ini"));

        QFile f(mailsIni);
        if(! f.exists())
        {
            sendData(sslSocket, currentClient + " NO - getquota error: no such mailbox, permission denied");
            log(copy, currentClient + " NO - getquota error: no such mailbox, permission denied");
            return;
        }


        QString data("* QUOTAROOT %1 \"\"\r\n* QUOTA \"\" (STORAGE%2 MESSAGE%3)"), argument1(" 0 0"), argument2(" 0 0");

        const qint64 quotaLimit(fctn->iniReturnValue(_fileMails, xAuthUser, "quota").toLongLong());
        const qint64 nombreDeMailPermis(fctn->iniReturnValue(_fileMails, xAuthUser, "nombreDeMailPermis").toLongLong());

        QList<qint64> quotaList(fctn->quotaGet(_userDir));
        const qint64 nbMailActuel(quotaList.at(0));
        const qint64 quotaActuel(quotaList.at(1));

        /*
            if(quotaLimit > 0)
            {
                argument1 = " " + QString::number(quotaActuel) + " " +  QString::number(quotaLimit);
            }
            if(nombreDeMailPermis > 0)
            {
                argument2 = " " + QString::number(nbMailActuel) + " " +  QString::number(nombreDeMailPermis);
            }
            */
        argument1 = " " + QString::number(quotaActuel) + " " +  QString::number(quotaLimit);
        argument2 = " " + QString::number(nbMailActuel) + " " +  QString::number(nombreDeMailPermis);


        sendData(sslSocket, data.arg(myInbox).arg(argument1).arg(argument2));
        log(copy, data.arg(myInbox).arg(argument1).arg(argument2));

        sendData(sslSocket, currentClient + " OK GETQUOTAROOT Completed");
        log(copy, currentClient + " OK GETQUOTAROOT Completed");



        return;
    }


    //</GETQUOTAROOT>





    // ID
    rx.setPattern("([\\w\\.]+) ID (.*)\\s*$");

    if(rx.exactMatch(newCommand))
    {

        QString copy(newCommand), data, myId("* ID (\"name\" \"aMailServer Imap\" \"version\" \"1\" \"vendor\" \"Word Dev'\" \"support-url\" \"http://wordDev.fr/\")");
        newCommand.clear();
        _lastData.clear();

        rx.indexIn(copy);
        currentClient = rx.cap(1).trimmed();
        const QString id(rx.cap(2).trimmed());

        if(! begin(sslSocket, currentClient, false))
        {
            return;
        }


        rx.setPattern("\"name\" \"(.*)\" ");
        if(rx.indexIn(id) != -1)
        {
            QString name(rx.cap(1).trimmed());

            if(! name.isEmpty())
            {
                name = (name.size() <= 50 ? name : name.left(50) + "...");
                data = " [" + name + "]";
            }

        }

        sendData(sslSocket, myId);
        log("-", myId);


        sendData(sslSocket, currentClient + " OK Nice to meet you" + data + " :-)");
        log(copy, currentClient + " OK Nice to meet you" + data + " :-)");

        return;
    }

    // </ID>









    /*

        // A terminer

        // TAG6 UID SORT (ARRIVAL) US-ASCII ALL

        rx.setPattern("([\\w\\.]+) (UID )?SORT (.*)$");
        if(rx.exactMatch(newCommand))
        {
            QString copy(newCommand);
            newCommand.clear();
            _lastData.clear();

            rx.indexIn(copy);
            currentClient = rx.cap(1).trimmed();
            bool uid(! rx.cap(2).trimmed().isEmpty());

            if(! begin(sslSocket, currentClient))
            {
                return;
            }


            sendData(sslSocket, currentClient + " OK" + (uid ? " UID" : "") + " SORT completed");
            log(copy, currentClient + " OK" + (uid ? " UID" : "") + " SORT completed");
            return;

        }

*/


    rx.setPattern("([\\w\\.]+) (UID )?COPY (\")?([\\d,:\\*]+)\\3 (.*)$");
    if(rx.exactMatch(newCommand))
    {
        QString copy(newCommand);
        newCommand.clear();
        _lastData.clear();

        rx.indexIn(copy);

        currentClient = rx.cap(1).trimmed();
        bool uid(! rx.cap(2).trimmed().isEmpty());
        QString msgStr = rx.cap(4).trimmed();
        QString dirTo = formatChemain(rx.cap(5).trimmed());
        QString myDir = dirTo;
        myDir.replace("/", ".");

        dirTo = returnDir(dirTo);

        if(! begin(sslSocket, currentClient))
        {
            return;
        }

        QDir dir(fctn->chemain(_userDir + dirTo + "/"));
        if(! dir.exists())
        {
            sendData(sslSocket, currentClient + " NO [TRYCREATE] Directory " + myDir + " does not exist!");
            log(copy, currentClient + " NO [TRYCREATE] Directory " + myDir + " does not exist!");

            return;
        }


        QStringList listToParse(returnInt(msgStr, uid));

        foreach(QString const uidMsg, listToParse)
        {

            const QStringList listMsgNum(uidMsg.split(":"));
            QString msgNum, msgUid;
            if(listMsgNum.count() == 2)
            {
                msgNum = listMsgNum.at(0);
                msgUid = listMsgNum.at(1);
                copyMsg(msgUid, dirTo);
            }


        }


        sendData(sslSocket, currentClient + " OK" + (uid ? " UID" : "") + " COPY completed");
        log(copy, currentClient + " OK" + (uid ? " UID" : "") + " COPY completed");

        return;

    }


















    rx.setPattern("([\\w\\.]+) RENAME (\")?(.*)\\2 (\")?(.*)\\4\\s*$");
    if(rx.exactMatch(newCommand))
    {

        QString copy(newCommand);
        newCommand.clear();
        _lastData.clear();
        rx.indexIn(copy);

        currentClient = rx.cap(1).trimmed();


        if(! begin(sslSocket, currentClient, false))
        {
            return;
        }

        QString dirFrom(formatChemain(rx.cap(3)));
        QString dirTo(formatChemain(rx.cap(5)));
        QString myDir = dirFrom;
        myDir.replace("/", ".");
        QString myDirTo(dirTo);
        myDirTo.replace("/", ".");



        dirFrom = fctn->chemain(dirFrom + "/");
        dirTo = fctn->chemain(dirTo + "/");

        const QStringList parentB(dirTo.split("/"));




        dirFrom = returnDir(dirFrom);
        dirTo = returnDir(dirTo);
        const QStringList parentA(dirFrom.split("/"));



        if(dirFrom == "/")
        {
            sendData(sslSocket, currentClient + " NO Please select a directory to rename");
            log(copy, currentClient + " NO Please select a directory to rename");
            return;
        }

        if(dirTo == "/")
        {
            sendData(sslSocket, currentClient + " NO Please select a target");
            log(copy, currentClient + " NO Please select a target");
            return;
        }

        QDir dir;
        if( ! dir.exists(_userDir + dirFrom))
        {
            sendData(sslSocket, currentClient + " NO directory " + myDir + " does not exist!");
            log(copy, currentClient + " NO directory " + myDir + " does not exist!");
            return;

        }

        const QStringList dirInfo(hasSubscribeOrIsMarked(_userDir + dirFrom));
        const bool marked(dirInfo.at(1) == "1");
        if(marked)
        {
            sendData(sslSocket, currentClient + " NO Dir " + myDir + " is marked, can not by rename");
            log(copy, currentClient + " NO Dir " + myDir + " is marked, can not by rename");
            return;
        }


        nbCurrentInferiors = 0;
        // Ex : copien dirA vers dirB alors que dirA contient des sous-dossiers
        nbInferiors(_userDir + dirFrom);


        const int countTo((myDirTo.split(".").count() - 1) + nbCurrentInferiors);

        if(countTo > maxInferiors && maxInferiors > -1 && parentB.at(0) != "Trash")
        {
            sendData(sslSocket, currentClient + " NO [ALERT] Dir " + myDirTo + " can not have more subfolders");
            log(copy, currentClient + " NO Dir " + myDirTo + " can not have more subfolders");
            return;
        }


        dir.rename(_userDir + dirFrom, _userDir + dirTo);

        removeDir(dirFrom);

        sendData(sslSocket, currentClient + " OK Dir " + myDir + " rename successfull");
        log(copy, currentClient + " OK Dir " + myDir + " rename successfull");

        return;
    }








    rx.setPattern("([\\w\\.]+) DELETE (.*)$");
    if(rx.exactMatch(newCommand))
    {

        QString copy(newCommand);
        newCommand.clear();
        _lastData.clear();
        rx.indexIn(copy);

        currentClient = rx.cap(1).trimmed();
        QString dir = formatChemain(rx.cap(2));
        QString myDir = dir;
        myDir.replace("/", ".");


        if(! begin(sslSocket, currentClient, false))
        {
            return;
        }


        dir = fctn->chemain(dir);
        if(dir.isEmpty() || dir == "/")
        {
            sendData(sslSocket, currentClient + " NO Please select a directory to delete");
            log(copy, currentClient + " NO Please select a directory to delete");
            return;
        }

        dir = returnDir(dir);

        const QString dirToDel(_userDir + dir);
        QDir d(dirToDel);

        if(! d.exists())
        {
            sendData(sslSocket, currentClient + " NO directory " + myDir + " does not exist!");
            log(copy, currentClient + " NO directory " + myDir + " does not exist!");
            return;
        }


        /*
            if(hasChildren(dirToDel))
            {
                sendData(sslSocket, currentClient + " NO Name " + myDir +" has inferior hierarchical names");
                log(copy, currentClient + " NO Name " + myDir +" has inferior hierarchical names");

                return;
            }
    */
        const QStringList dirInfo(hasSubscribeOrIsMarked(dirToDel));
        const bool marked(dirInfo.at(1) == "1");
        if(marked)
        {
            sendData(sslSocket, currentClient + " NO Dir " + myDir + " is marked, can not by deleted");
            log(copy, currentClient + " NO Dir " + myDir + " is marked, can not by deleted");
            return;
        }

        if(! removeDir(dir))
        {
            sendData(sslSocket, currentClient + " NO Dir " + myDir + " no deleted");
            log(copy, currentClient + " NO Dir " + myDir + " no deleted");
            return;
        }

        sendData(sslSocket, currentClient + " OK Dir " + myDir + " deleted successfull");
        log(copy, currentClient + " OK Dir " + myDir + " deleted successfull");

        return;
    }






    rx.setPattern("([\\w\\.]+) CREATE (.*)$");
    if(rx.exactMatch(newCommand))
    {
        QString copy(newCommand);
        newCommand.clear();
        _lastData.clear();

        rx.indexIn(copy);

        currentClient = rx.capturedTexts().at(1).trimmed();
        QString dir = formatChemain(rx.cap(2));


        if(! begin(sslSocket, currentClient, false))
        {
            return;
        }

        dir = fctn->chemain(dir);
        QString myDir = dir;
        myDir.replace("/", ".");

        const QStringList parentA(myDir.split("."));

        if(dir.isEmpty() || dir == "/")
        {
            sendData(sslSocket, currentClient + " NO Please specify a directory to create");
            log(copy, currentClient + " NO Please specify a directory to create");
            return;
        }

        dir = returnDir(dir);
        const QStringList parentB(dir.split("/"));

        QString dirToCreate(_userDir + dir);
        QString mailFile(dirToCreate + "/mails.ini");
        QString globalFile(dirToCreate + "/globals.ini");

        QDir newDir(dirToCreate);
        QFile fMails(mailFile);
        QFile fGlobals(globalFile);

        if(newDir.exists())
        {

            sendData(sslSocket, currentClient + " NO Dir " + myDir + " already exists");
            log(copy, currentClient + " NO Dir " + myDir + " already exists");
            return;

        }

        if(parentB.count() > maxInferiors && maxInferiors > -1 && parentA.at(0) != "Trash")
        {
            sendData(sslSocket, currentClient + " NO [ALERT] Dir " + parentA.at(0) + " can not have more subfolders");
            log(copy, currentClient + " NO Dir " + parentA.at(0) + " can not have more subfolders");
            return;
        }

        if(! newDir.mkdir(dirToCreate) || ! fMails.open(QIODevice::ReadWrite | QIODevice::Append) || ! fGlobals.open(QIODevice::ReadWrite | QIODevice::Append))
        {
            sendData(sslSocket, currentClient + " NO Dir " + myDir + " no created");
            log(copy, currentClient + " NO Dir " + myDir + " no created");
            return;
        }


        fMails.close();
        fGlobals.close();

        QStringList listUids(uids());
        QString uidvalidity(listUids.at(1));
        qint64 nextUidvalidity(uidvalidity.toLongLong() + 1);

        QSettings settings(globalFile, QSettings::IniFormat);
        settings.beginGroup("globals");
        settings.setValue("uidvalidity", uidvalidity);
        settings.setValue("subscribe", 1);
        settings.setValue("marked", 0);
        settings.endGroup();

        fctn->updateIniDirective("globals", _fileUids, "nextUidvalidity", QString::number(nextUidvalidity));

        sendData(sslSocket, currentClient + " OK Dir " + myDir + " created successfull");
        log(copy, currentClient + " OK Dir " + myDir + " created successfull");

        return;
    }








    //! -----------------------------------------------------------------
    //! LOGIN COMMAND (the server must reject connection if not secure mode
    //! No STARTTLS Initiated or not in SSL/TLS connected
    //! -----------------------------------------------------------------

    rx.setPattern("([\\w\\.]+) LOGIN (.*)$");
    if(rx.exactMatch(newCommand) || statIdentification)
    {
        QString copy(newCommand);
        newCommand.clear();
        _lastData.clear();

        rx.indexIn(copy);

        currentClient = rx.cap(1).trimmed();
        QString loginMdp(rx.cap(2).simplified().replace("\"", ""));

        const QStringList listLoginMdp(loginMdp.split(" "));
        if(listLoginMdp.count() != 2)
        {
            log(copy, currentClient + " BAD command mal reformated");
            sendData(sslSocket, currentClient + " BAD command mal reformated");
            return;

        }
        const QString _xAuthLogin(listLoginMdp.at(0));
        QStringList userDomaine(_xAuthLogin.split("@"));

        if(userDomaine.count() != 2)
        {
            log(copy, currentClient + " BAD send mail as account");
            sendData(sslSocket, currentClient + " BAD send mail as account");
            return;

        }

        xAuthLogin = _xAuthLogin;
        xAuthUser = userDomaine.at(0);
        xAuthDomaine = userDomaine.at(1);

        _userDir = fctn->chemain(cfg->_mailDir.arg(xAuthDomaine).arg(xAuthUser));
        _fileMails = fctn->chemain(cfg->_fileMails.arg(xAuthDomaine));
        _fileUids = _userDir + "@conf/uids.ini";
        authenticated = true;
        statIdentification = false;
        log(copy, currentClient + " OK authenticated");
        sendData(sslSocket, currentClient + " OK autheticated");
        return;
    }















    // APPEND

    rx.setPattern("([\\w\\.]+) APPEND (\")?([\\w\\.\\+\\d\\-= ]+)\\2 (\\((.*)\\) )?((\")?(.*)\\7 )?\\{([0-9]+)\\}");
    if(rx.exactMatch(newCommand) || appendSent)
    {

        QString copy(newCommand);
        newCommand.clear();
        _lastData.clear();
        rx.indexIn(copy);

        if(! appendSent)
        {
            // /!\ _received.clear(); doit être detruite ici ! (du moins avant "+ Ready")
            // Placée ailleurs, cela provoque une erreur chez le client mail qui reste en attente du massega OK
            // ou alors elle contiendra les entêtes envoyées au paravant par le client (ex : xxx capability ou
            // xxx login "login@dom.tld" "mdp" ...)
            _received.clear();

            QString err;

            appendClient = rx.cap(1).trimmed();

            QString dir = formatChemain(rx.cap(3).trimmed());

            QString myDir = dir;
            myDir.replace("/", ".");

            dir = returnDir(dir);
            dir = fctn->chemain(dir);
            appendDir = fctn->chemain(_userDir + dir + "/");

            QDir d(appendDir);

            if(dir.isEmpty() || dir == "/" || ! d.exists())
            {
                err = " NO [TRYCREATE] Directory " + myDir + " does not exist!";
            }

            appendFlags = rx.cap(5).trimmed();
            //appendDate = rx.cap(8).trimmed();
            appendSize = rx.cap(9).trimmed().toLongLong();


            if(! begin(sslSocket, appendClient, false))
            {
                return;
            }



            // <QUOTA>

            if(err.isEmpty())
            {
                const qint64 quota(fctn->iniReturnValue(_fileMails, xAuthUser, "quota").toLongLong());
                const qint64 tailleMaximaleDesMessages(fctn->iniReturnValue(_fileMails, xAuthUser, "tailleMaximaleDesMessages").toLongLong());
                const qint64 nombreDeMailPermis(fctn->iniReturnValue(_fileMails, xAuthUser, "nombreDeMailPermis").toLongLong());

                QList<qint64> quotaList(fctn->quotaGet(_userDir));
                const qint64 nbMailActuel(quotaList.at(0));
                const qint64 quotaActuel(quotaList.at(1));

                if(quota > 0 && quotaActuel >= quota)
                {
                    err = " NO - Message has not been saved because quota exeded";
                }

                if(nombreDeMailPermis > 0 && nbMailActuel >= nombreDeMailPermis)
                {
                    err = " NO - Message has not been saved because limit mails exeded";
                }

                if(tailleMaximaleDesMessages > 0 && appendSize >= tailleMaximaleDesMessages)
                {
                    err = " No - Message has not been saved because your message size exceds fixed maximum "
                          "message size. Your message size: "
                            + fctn->stringNumber(appendSize) + ", Max size: "
                            + fctn->stringNumber(tailleMaximaleDesMessages);
                }

            }


            if(! err.isEmpty())
            {

                sendData(sslSocket, appendClient + err);
                log("-", appendClient + err);

                //! Certains clients mails tentent de renvoyer le mesage plusieurs fois, ces 3 lignes empêchent cette action (tested)
                sendData(sslSocket, "* BYE IMAP4rev1 server terminating connection");
                log(copy, "* BYE IMAP4rev1 server terminating connection");
                sslSocket->close();

                return;
            }

            // </QUOTA>



            sendData(sslSocket, "+ Ready for literal data");
            log(copy, "+ Ready for literal data");
            appendSent = true;



            return;
        }


        // +6 fait suit à la destruction de _received dans la partie if(! appendSent)
        // La suppression cause une erreur

        if((_received.size() + 6) >= appendSize)
        {
            sendData(sslSocket, appendClient + " OK APPEND completed");
            log("-", appendClient + " OK APPEND completed");

            QString msgId(fctn->regenererMessageId());
            QString msgFile(appendDir + msgId + ".eml");

            QFile f(msgFile);

            if(f.open(QIODevice::WriteOnly))
            {
                QTextStream out(&f);
                out << _received;
                f.close();
                fctn->addNewMsg(xAuthUser, xAuthDomaine, msgId,  _received.size(), appendDir, fctn->nettoyageFlags(appendFlags));

            }

            appendSent = false;
            appendClient.clear();
            appendDir.clear();
            appendFlags.clear();
            //appendDate.clear();
            appendSize = 0;
            _received.clear();

            return;
        }


        return;
    }










    //rx.setPattern("([\\w\\.]+) (UID )?SEARCH UID 1:\\*\\s*$");
    rx.setPattern("([\\w\\.]+) (UID )?SEARCH( UID)? (.*)\\s*$");
    // srch1             SEARCH UID 98
    if(rx.exactMatch(newCommand))
    {
        QString copy(newCommand);
        newCommand.clear();
        _lastData.clear();

        rx.indexIn(copy);
        currentClient = rx.cap(1).trimmed();
        if(! begin(sslSocket, currentClient))
        {
            return;
        }

        bool uid = ! rx.cap(2).trimmed().isEmpty() || ! rx.cap(3).trimmed().isEmpty();

        QString msgStr = rx.cap(4).replace("UID", "").trimmed();
        if(msgStr == "ALL") msgStr = "1:*";

        QStringList listToParse(returnInt(msgStr, uid));

        QString data;

        foreach(QString const value, listToParse)
        {

            const QStringList listMsgNum(value.split(":"));
            QString msgNum, msgUid;
            if(listMsgNum.count() == 2)
            {
                // msgNum = listMsgNum.at(0);
                msgUid = listMsgNum.at(1);
            }

            data += msgUid + " ";
        }
        data = "* SEARCH " + data.trimmed();
        ;

        sendData(sslSocket, data);
        log(copy, data);


        sendData(sslSocket, currentClient + " OK SEARCH completed");
        log(copy, currentClient + " OK SEARCH completed");



        return;
    }









    rx.setPattern("([\\w\\.]+) (UID )?STORE (\")?([\\d,:\\*]+)\\3 (\\+|\\-)?Flags(\\.SILENT)? \\((.*)\\)\\s*$");

    if(rx.exactMatch(newCommand))
    {
        QString copy(newCommand);
        newCommand.clear();
        _lastData.clear();

        rx.indexIn(copy);

        currentClient = rx.cap(1).trimmed();
        bool uid = ! rx.cap(2).trimmed().isEmpty();

        QString msgStr = rx.cap(4).trimmed();
        QString signe = rx.cap(5).trimmed();
        QString silent = rx.cap(6).trimmed();
        QString flags = rx.cap(7).trimmed();

        if(! begin(sslSocket, currentClient))
        {
            return;
        }

        QStringList listToParse(returnInt(msgStr, uid));

        QString data, _data;
        foreach(QString const uidMsg, listToParse)
        {
            const QStringList listMsgNum(uidMsg.split(":"));
            QString msgNum, msgUid;
            if(listMsgNum.count() == 2)
            {
                msgNum = listMsgNum.at(0);
                msgUid = listMsgNum.at(1);


                QString myFlags(updateFlags(flags, msgUid, signe));

                if(silent.isEmpty())
                {
                    if(uid)
                    {
                        data = "* " + msgNum + " FETCH (FLAGS (" + myFlags + ") UID " + msgUid + ")";
                    }
                    else
                    {
                        data = "* " + msgNum + " FETCH FLAGS (" + myFlags + ")";
                    }
                    sendData(sslSocket, data);

                    _data += data + "\r\n";
                }

            }

        }


        sendData(sslSocket, currentClient + " OK STORE Completed");
        log(copy, _data.trimmed() + "\r\n" + currentClient + " OK STORE Completed");

        return;
    }













    // FETCHA
    rx.setPattern("([\\w\\.]+) (UID )?FETCH (\")?([\\d,:\\*]+)\\3 (.*)$");
    if(rx.exactMatch(newCommand))
    {
        QString copy(newCommand);
        newCommand.clear();
        _lastData.clear();
        rx.indexIn(copy);

        currentClient = rx.cap(1).trimmed();
        const bool uid(! rx.cap(2).trimmed().isEmpty());
        QString msgStr = rx.cap(4).trimmed();
        QString cmd = rx.cap(5).trimmed();


        if(! begin(sslSocket, currentClient))
        {
            return;
        }

        QString data, msgNum, msgUid;

        QStringList listToParse(returnInt(msgStr, uid));


        foreach(QString const value, listToParse)
        {

            const QStringList listMsgNum(value.split(":"));
            if(listMsgNum.count() == 2)
            {
                msgNum = listMsgNum.at(0);
                msgUid = listMsgNum.at(1);

                fetch(uid, msgUid, cmd, copy, msgNum);
            }
        }


        data = currentClient + " OK " + (uid ? "UID " : "") + "FETCH Completed";

        sendData(sslSocket, data);

        log("-", data);

        return;
    }























        // http://www.networksorcery.com/enp/rfc/rfc3691.txt
        rx.setPattern("([\\w\\.]+) UNSELECT\\s*");
        if(rx.exactMatch(newCommand))
        {


            QString copy(newCommand);
            newCommand.clear();
            _lastData.clear();
            rx.indexIn(copy);
            currentClient = rx.cap(1).trimmed();

            if(! begin(sslSocket, currentClient))
            {
                return;
            }

            selectedDirectory.clear();
            selectedSubDirectory.clear();

            sendData(sslSocket, currentClient + " OK UNSELECT completed, now in authenticated state");

            //log(copy, data);

            return;

        }




        rx.setPattern("([\\w\\.]+) NAMESPACE\\s*");
        if(rx.exactMatch(newCommand))
        {


            QString copy(newCommand);
            newCommand.clear();
            _lastData.clear();
            rx.indexIn(copy);
            currentClient = rx.cap(1).trimmed();

            if(! begin(sslSocket, currentClient, false))
            {
                return;
            }

            QString data("* NAMESPACE ((\"\" \".\")) NIL NIL");
            sendData(sslSocket, data);
            sendData(sslSocket, currentClient + " OK NAMESPACE completed");


            //log(copy, data);

            return;

        }










    // ATTENTION AU " DANS \"(.*)\" CAR CERTAINS ENVOIENT EN BRUT (DIRECTEMENT SANS ")
    rx.setPattern("([\\w\\.]+) (LSUB|LIST) (\")?(.*)\\3 (\")?(.*)\\5\\s*$");
    if(rx.exactMatch(newCommand))
    {

        QString copy(newCommand);
        newCommand.clear();
        _lastData.clear();
        rx.indexIn(copy);

        currentClient = rx.capturedTexts().at(1).trimmed();

        if(! begin(sslSocket, currentClient, false))
        {
            return;
        }

        QString commande = rx.capturedTexts().at(2).trimmed().toUpper();
        // QString dir1 = formatChemain(rx.cap(4));
        QString dir2 = formatChemain(rx.cap(6));
        listDir(sslSocket, dir2, currentClient, copy, (commande == "LIST" ? true : false));

        return;
    }




    rx.setPattern("([\\w\\.]+) (UN)?SUBSCRIBE (\")?(.*)\\3\\s*$");
    if(rx.exactMatch(newCommand))
    {

        QString copy(newCommand);
        newCommand.clear();
        _lastData.clear();
        rx.indexIn(copy);

        currentClient = rx.capturedTexts().at(1).trimmed();
        QString UN = rx.capturedTexts().at(2).trimmed().toUpper();
        QString dir = formatChemain(rx.cap(4));
        dir = returnDir(dir);

        if(! begin(sslSocket, currentClient, false))
        {
            return;
        }

        QString globalFile(_userDir + fctn->chemain(dir + "/globals.ini"));

        if(QFile::exists(globalFile)) // Pour ne pas créer les sous-dossiers
        {
            QSettings settings(globalFile, QSettings::IniFormat);
            settings.beginGroup("globals");
            settings.setValue("subscribe", (! UN.isEmpty() ? 0 : 1));
            settings.endGroup();
        }

        sendData(sslSocket, currentClient + " OK " + UN + "SUBSCRIBE completed");
        log(copy, currentClient + " OK " + UN + "SUBSCRIBE completed");

        return;
    }







    rx.setPattern("([\\w\\.]+) (NOOP|CHECK)\\s*");
    if(rx.exactMatch(newCommand))
    {
        QString copy(newCommand);
        newCommand.clear();
        _lastData.clear();
        rx.indexIn(copy);
        currentClient = rx.capturedTexts().at(1).trimmed();
        QString cmd = rx.capturedTexts().at(2).trimmed().toUpper();


        if(! begin(sslSocket, currentClient))
        {
            return;
        }

        listStats.clear();


        QStringList myListStats(stats(selectedSubDirectory));

        sendData(sslSocket, "* " + myListStats.at(0) + " EXISTS");
        sendData(sslSocket, "* " + myListStats.at(1) + " RECENT");
        sendData(sslSocket, "* " + myListStats.at(2) + " UNSEEN");
        sendData(sslSocket, "* " + myListStats.at(6) + " EXPUNGE");
        sendData(sslSocket, currentClient + " OK " + cmd + " completed");

        return;
    }

    rx.setPattern("(.*)STATUS \"?(.*)\"? \\((.*)\\)\\s*");

    if(rx.exactMatch(newCommand))
    {

        QString copy(newCommand);
        newCommand.clear();
        _lastData.clear();

        rx.indexIn(copy);
        currentClient = rx.cap(1).trimmed();

        if(! begin(sslSocket, currentClient, false))
        {
            return;
        }


        QString dir = rx.cap(2).trimmed();
        dir = formatChemain(dir);
        QString myDir = dir;
        myDir.replace("/", ".");

        dir = returnDir(dir);



        QString cmds = rx.capturedTexts().at(3).trimmed().toUpper();
        cmds.replace("\\", "");

        QStringList myListStats(stats(dir));

        QStringList ListCmds(cmds.split(" "));

        ListCmds.removeDuplicates();

        QString data("* STATUS " + myDir + " (");

        foreach(QString cmd, ListCmds)
        {
            cmd = cmd.trimmed();

            if(cmd == "MESSAGES")
            {
                data += " MESSAGES " + myListStats.at(0);
            }

            if(cmd == "RECENT")
            {
                data += " RECENT " + myListStats.at(1);
            }


            if(cmd == "UNSEEN")
            {
                data += " UNSEEN " + myListStats.at(2);
            }

            if(cmd == "UIDVALIDITY")
            {
                data += " UIDVALIDITY " + myListStats.at(4);
            }

            if(cmd == "UIDNEXT")
            {
                QStringList listUids(uids());
                data += " UIDNEXT " + listUids.at(0);
            }

        }


        data += " )";
        data.replace("[ ]+", " ");
        sendData(sslSocket, data);
        sendData(sslSocket, currentClient + " OK STATUS completed");


        log(copy, data);

        return;
    }






    rx.setPattern("([\\w\\.]+) (SELECT|EXAMINE)(\")?(.*)\\3\\s*$");
    if(rx.exactMatch(newCommand))
    {
        QString copy(newCommand);
        newCommand.clear();
        _lastData.clear();
        rx.indexIn(copy);

        currentClient = rx.cap(1).trimmed();
        QString cmd = rx.cap(2).trimmed().toUpper();
        QString dir = formatChemain(rx.cap(4));
        dir = returnDir(dir);

        if(! begin(sslSocket, currentClient, false))
        {
            return;
        }

        dir = fctn->chemain(dir);
        const QString myDir(fctn->chemain(_userDir + dir + "/"));
        QDir tmpDir(myDir);

        if(dir.isEmpty() || dir == "/" || ! tmpDir.exists())
        {
            sendData(sslSocket, currentClient + " NO - Directory not exists!");
            log(copy, currentClient + " NO - Directory not exists!");
            return;
        }






        selectedDirectory = myDir;
        selectedSubDirectory = fctn->chemain(dir);

        QStringList myListStats(stats(dir));
        QString data;
        sendData(sslSocket, "* " + myListStats.at(0) + " EXISTS");
        sendData(sslSocket, "* " + myListStats.at(1) + " RECENT");
        sendData(sslSocket, "* FLAGS (\\Deleted \\Seen \\Draft \\Answered \\Flagged)");
        sendData(sslSocket, "* OK [UIDVALIDITY " + myListStats.at(4) + "]");
        if(! myListStats.at(3).isEmpty())
        {
            sendData(sslSocket, "* OK [UNSEEN " + myListStats.at(3) + "] First unseen message");
        }
        if(cmd == "SELECT")
        {
            sendData(sslSocket, "* OK [PERMANENTFLAGS (\\Deleted \\Seen \\Draft \\Answered \\Flagged \\*)] flags permitted");
            sendData(sslSocket, currentClient + " OK [READ-WRITE] SELECT completed");
            readOrWrite = 1;
        }
        else
        {
            sendData(sslSocket, "* OK [PERMANENTFLAGS ()] No permanent flags permitted");
            sendData(sslSocket, currentClient + " OK [READ-ONLY] EXAMINE completed");
            readOrWrite = 0;
        }

        // sendData(sslSocket, data);



        log(copy, data);
        return;
    }









    //! ##################################################
    rx.setPattern("(.*)IDLE\\s*$");
    if(rx.exactMatch(newCommand))
    {

        QString copy(newCommand);
        newCommand.clear();
        _lastData.clear();
        rx.indexIn(copy);

        idleClient = currentClient = rx.capturedTexts().at(1).trimmed();

        if(! begin(sslSocket, currentClient))
        {
            return;
        }

        QFileSystemWatcher *sw  = new QFileSystemWatcher;
        sw->addPath(selectedDirectory + "mails.ini");
        connect(sw, SIGNAL(fileChanged(QString)), this, SLOT(slIdle(QString)));

        qDebug() << "\t\t+ idling:#" + selectedDirectory + "mails.ini#";


        sendData(sslSocket, "+ idling");
        log(copy, "+ idling");

        return;
    }






    //! ##################################################
    rx.setPattern("([\\w\\.]+) CLOSE\\s*$");
    if(rx.exactMatch(newCommand))
    {

        QString copy(newCommand);
        newCommand.clear();
        _lastData.clear();
        rx.indexIn(copy);

        currentClient = rx.cap(1).trimmed();

        if(! begin(sslSocket, currentClient, false))
        {
            return;
        }

        // idleClient.clear();
        expunge(sslSocket);
        // selectedDirectory.clear();
        // selectedSubDirectory.clear();
        // listStats.clear();
        //  selectedBox.clear();
        sendData(sslSocket, currentClient + " OK CLOSE completed");
        log(copy, currentClient + " OK CLOSE completed");
        sslSocket->close();
        return;
    }







    //! ##################################################
    rx.setPattern("([\\w\\.]+) EXPUNGE\\s*$");
    if(rx.exactMatch(newCommand))
    {
        QString copy(newCommand);
        newCommand.clear();
        _lastData.clear();
        rx.indexIn(copy);

        currentClient = rx.cap(1).trimmed();


        if(! begin(sslSocket, currentClient))
        {
            return;
        }


        expunge(sslSocket);

        sendData(sslSocket, currentClient + " OK expunge completed");
        log(copy, currentClient + " OK expunge completed");
        return;
    }











    //! ##################################################
    // DONE (aucun arguent)
    if(newCommand.toUpper().startsWith("DONE")/*  ! idleClient.isEmpty()*/)
    {
        QString copy(newCommand);
        newCommand.clear();
        _lastData.clear();

        if(! begin(sslSocket, currentClient, false))
        {
            return;
        }

        sendData(sslSocket, idleClient + " OK IDLE Completed");
        log(copy, idleClient + " OK IDLE Completed");


        return;
    }









    //! ##################################################
    // LOGOUT (aucun argument)

    rx.setPattern("([\\w\\.\\-]+) LOGOUT\\s*$");
    if(rx.exactMatch(newCommand))
    {
        QString copy(newCommand);
        newCommand.clear();
        _lastData.clear();
        rx.indexIn(copy);

        currentClient = rx.cap(1).trimmed();

        sendData(sslSocket, "* BYE IMAP4rev1 server terminating connection");
        sendData(sslSocket, currentClient + " OK LOGOUT completed");



        log(copy, "* BYE IMAP4rev1 server terminating connection\r\n" + currentClient + " OK LOGOUT completed");
        idleClient.clear();


        sslSocket->close();

        return;
    }





















    if(! appendSent)
    {
        sendData(sslSocket, "* BAD command unrecognized");
        log(newCommand, "* BAD command unrecognized");
        erreurCommande++;
        newCommand.clear();
        _lastData.clear();
    }




    return;
    //   }

}









void SslServer::sendData(QSslSocket *sslSocket, QString data)
{

    if(! idleClient.isEmpty())
    {
        //       data = idleClient + " OK IDLE Completed";
        //     idleClient.clear();
    }

    QString myData = data.trimmed().replace("#\r\n#", "\r\n") + "\r\n";

    if(sslSocket->isWritable())
    {
        sslSocket->write(myData.toLatin1().constData(), myData.length());
        sslSocket->flush();

        qDebug() << "\t# SENT: " << myData.trimmed() << "\r\n";
    }

}




// selection : true = authentification et selection d'un répertoire
bool SslServer::begin(QSslSocket *sslSocket, const QString client, const bool selection)
{
    // QSslSocket *sslSocket = (QSslSocket *)sender();


    QString data;

    if(authenticated == false)
    {
        data = client + " NO Please authenticate first!";
    }
    else if(selection && selectedDirectory.isEmpty())
    {
        data = client + " NO Please select folder first!";
    }

    if(! data.isEmpty())
    {
        sendData(sslSocket, data);
        log("-", data);
        return false;
    }

    return true;
}






void SslServer::log(QString const received, QString const send, QString daemon, int const num)
{

    int socketDescriptor(12);
    QString txt("\"%1\"\t%2\t\"%3\"\t");
    txt = txt.arg(daemon.toUpper()).arg(QString::number(socketDescriptor)).arg(fctn->currentTxtDateTime());
    QString txtReceived(txt + "\"" + "hostConnectedIp" + "\"\t\"RECEIVED: " + received + "\"");
    QString txtSend(txt + "\"" + myIpAddress + "\"\t\"SENT: " + send + "\"");

    txtReceived.replace("\r\n", "[\\r\\n]");
    if(received.trimmed() == "-")
        txtReceived = "";

    txtSend.replace("\r\n", "[\\r\\n]");

    QString logTxt(num == 1 ? txtReceived + "\r\n" + txtSend : num == 2 ? txtReceived : txtSend);
    QFile f(cfg->_myPath + daemon.toLower() + ".log");
    f.open(QIODevice::WriteOnly | QIODevice::Append);
    QTextStream w(&f);
    w << logTxt.trimmed() + "\r\n";
    f.close();
}



QString SslServer::returnDir(const QString dir, const bool type)
{
    QString cryptDir;
    QStringList listDir(dir.split("/"));
    foreach(const QString entry, listDir)
    {
        if(entry.isEmpty()) continue;

        if(type)
        {
            cryptDir += fctn->base64Encode(entry) + "/";
        }
        else
        {
            cryptDir += fctn->base64Decode(entry) + "/";
        }
    }

    return cryptDir.left(cryptDir.size() - 1);
}



QString SslServer::formatChemain(QString chemain)
{
    chemain.replace("\"", "");
    chemain.replace("\\.", "/");
    chemain.replace(".", "/");
    return chemain.trimmed();
}







QString SslServer::updateFlags(QString flags, QString uidMsg, QString type)
{

    type = type.trimmed();
    QString stringFlags(fctn->nettoyageFlags(_validFlags));
    QStringList listStringFlags(stringFlags.split(" "));

    QString stringMyFlags(fctn->nettoyageFlags(flags));

    stringMyFlags.replace("recent", "", Qt::CaseInsensitive);

    QStringList listMyStringFlags(stringMyFlags.split(" "));

    QString iniFile(selectedDirectory + "mails.ini");

    QString msgId(detectIdByUid(iniFile, uidMsg));

    QSettings settings(iniFile, QSettings::IniFormat);
    settings.beginGroup(msgId);
    if(settings.childKeys().count() < 1) return "";

    QString actuelFlags(fctn->nettoyageFlags(settings.value("flags").toString()));
    QStringList listActuelFlags(actuelFlags.split(" "));

    QString tmpFlags;

    if(type == "+")
    {
        tmpFlags = stringMyFlags + " " + actuelFlags;
    }

    else if(type == "-")
    {
        foreach(QString actuelFlag, listActuelFlags)
        {
            if(! listMyStringFlags.contains(actuelFlag, Qt::CaseInsensitive))
            {
                tmpFlags += actuelFlag + " ";
            }
        }
    }

    else // if(type == "=")
    {
        tmpFlags = stringMyFlags;
    }

    QString validFlags;

    QStringList listTmpFlages(fctn->nettoyageFlags(tmpFlags).split(" "));

    foreach(QString myFlag, listTmpFlages)
    {
        myFlag = myFlag.trimmed();

        if(listStringFlags.contains("*") || listStringFlags.contains(myFlag, Qt::CaseInsensitive))
        {
            validFlags += myFlag + " ";
        }
    }

    validFlags = validFlags.trimmed();

    listMyStringFlags.clear();
    listMyStringFlags = validFlags.split(" ");
    listMyStringFlags.removeDuplicates();

    if(listMyStringFlags.contains("seen") && listMyStringFlags.contains("unseen"))
    {
        if(flags == "unseen")
        {
            listMyStringFlags.removeOne("seen");
        }
        else
        {
            listMyStringFlags.removeOne("unseen");
        }
    }

    validFlags = listMyStringFlags.join(" ");
    settings.setValue("flags", validFlags);
    settings.endGroup();

    return fctn->prepareFlags(validFlags);
}



QString SslServer::detectIdByUid(QString mailsFile, QString uid)
{
    QString returnValue("-1");
    mailsFile = mailsFile.trimmed();
    uid = uid.trimmed();
    QSettings settings(mailsFile, QSettings::IniFormat);
    QStringList listMsg(settings.childGroups());

    foreach(QString const id, listMsg)
    {
        settings.beginGroup(id);
        QString myUid(settings.value("uid").toString().trimmed());
        settings.endGroup();
        if(uid == myUid)
        {
            returnValue = id;
            break;
        }
    }

    return returnValue;
}





QString SslServer::detectUidById(const QString iniFile, const QString id) const
{
    QSettings settings(iniFile, QSettings::IniFormat);
    settings.beginGroup(id);
    QString uid(settings.value("uid").toString().trimmed());
    settings.endGroup();
    return ! uid.isEmpty() ? uid : "-1";
}





void SslServer::copyMsg(QString const uidMsg, QString const to)
{
    QString msgFrom, msgTo, dirTo, iniFile;

    dirTo = fctn->chemain(_userDir + to + "/");
    iniFile = selectedDirectory + "mails.ini";

    QString file(iniReturnValueByUid(iniFile, uidMsg, "file"));
    QString flags(iniReturnValueByUid(iniFile, uidMsg, "flags"));

    msgFrom = selectedDirectory + file + ".eml";
    msgTo = dirTo + file + ".eml";

    if(QFile::copy(msgFrom, msgTo))
    {
        fctn->addNewMsg(xAuthUser, xAuthDomaine, file, msgFrom.size(), dirTo, fctn->nettoyageFlags(flags));
    }

}




QStringList SslServer::hasSubscribeOrIsMarked(QString const folder)
{
    QStringList list(QStringList() << "0" << "0");

    QString iniFile(folder + "/globals.ini");
    if(! QFile::exists(iniFile)) return list;
    QSettings settings(iniFile, QSettings::IniFormat);
    settings.beginGroup("globals");
    const int subscribe(settings.value("subscribe").toInt());
    const int marked(settings.value("marked").toInt());
    settings.endGroup();

    list.clear();
    list << QString::number(subscribe) << QString::number(marked);

    return list;
}





bool SslServer::removeDir(QString dirPath)
{
    dirPath = fctn->chemain(dirPath + "/");
    if(dirPath == "/") return false;

    dirPath = _userDir + dirPath;

    QDir folder(dirPath);
    folder.setFilter(QDir::NoDotAndDotDot | QDir::AllEntries | QDir::System | QDir::Hidden);

    foreach(QFileInfo fileInfo, folder.entryInfoList())
    {


        if(fileInfo.isDir())
        {

            removeDir(fileInfo.baseName());
        }
        else
        {
            QFile::remove(fileInfo.filePath());
        }
    }

    folder.rmdir(dirPath);

    return true;
}





QStringList SslServer::uids() const
{
    QStringList listUids;
    QSettings settings(_fileUids, QSettings::IniFormat);
    settings.beginGroup("globals");
    QString nextUid(settings.value("nextUid").toString().trimmed());
    QString nextUidvalidity(settings.value("nextUidvalidity").toString().trimmed());
    settings.endGroup();
    listUids << nextUid << nextUidvalidity;
    return listUids;
}




QString SslServer::iniReturnValueByUid(QString file, QString uid, QString directive)
{
    file = file.trimmed();
    uid = uid.trimmed();
    directive = directive.trimmed();

    if(! QFile::exists(file)) return "";

    QSettings settings(file, QSettings::IniFormat);
    QStringList listMsg(settings.childGroups());
    QString returnValue;

    foreach(QString const group, listMsg)
    {
        settings.beginGroup(group);
        QString myUid(settings.value("uid").toString().trimmed());
        if(myUid == uid)
        {
            returnValue = settings.value(directive).toString().simplified();
            break;
        }
        settings.endGroup();
    }

    return returnValue;
}









void SslServer::listDir(QSslSocket *sslSocket, QString dir, const QString client, const QString cmd, const bool type)
{
    listDirsStr.clear();
    QString data, dirToList;

    const QString recursif(dir.contains("*") ? "*" : dir.contains("%") ? "%" : "");

    if(dir.startsWith("#Public", Qt::CaseInsensitive))
    {
        dirToList = _userDir;
    }
    else
    {

        dir.replace("*", "");
        dir.replace("%.%", "");
        dir.replace(".%", "");
        dir.replace("%.", "");
        dir.replace("%", "");
        dir.replace(".", "/");

        dir = returnDir(dir);
        dirToList = _userDir + dir;
    }



    listParentFolder(dirToList, recursif);


    // QSslSocket *sslSocket = (QSslSocket *)sender();


    if(listDirsStr.isEmpty())
    {
        if(type)
        {
            sendData(sslSocket, "LIST * (\\NoSelect) \".\" \"\"");
            sendData(sslSocket, client + " OK LIST Completed");
        }
        else
        {
            sendData(sslSocket, "LSUB * (\\NoSelect) \".\" \"\"");
            sendData(sslSocket, client + " OK LSUB Completed");
        }

        // sendData(sslSocket, data);
        log(cmd, data);
        return;
    }


    QStringList listFolder(listDirsStr.trimmed().split("\r\n"));
    listDirsStr.clear();

    listFolder.removeDuplicates();


    int i(0);
    foreach(const QString dirInList, sortList(listFolder))
    {
        QString copyDir(dirInList);

        QString myDir(removeSep(copyDir.replace(_userDir, "")).trimmed());
        if(myDir.isEmpty())
        {
            continue;
        }


        const QString no(hasChildren(dirInList) ? "" : "No");

        const QStringList dirInfo(hasSubscribeOrIsMarked(dirInList));

        const bool hasSubscribe(dirInfo.at(0) == "1");

        const QString un(dirInfo.at(1) == "1" ? "" : "Un");

        myDir = returnDir(myDir, false);
        myDir.replace("/", ".");

        const int intCurrentInferiors(myDir.split(".").count());

        const QString noInferiors((intCurrentInferiors >= maxInferiors  && maxInferiors > -1) ? " \\NoInferiors" : "");

        if(type)
        {
            data = "* LIST (\\Has" + no + "Children \\" + un + "Marked" + noInferiors +") \".\" \"" + myDir + "\"";
            sendData(sslSocket, data);
            log(i < 1 ? cmd : "-", data);
        }

        else if(! type && hasSubscribe)
        {
            data = "* LSUB (\\Has" + no + "Children \\" + un + "Marked" + noInferiors +") \".\" \"" + myDir + "\"";
            sendData(sslSocket, data);
            log(i < 1 ? cmd : "-", data);
        }

        i++;
    }

    sendData(sslSocket, client + " OK " + (type ? "LIST" : "LSUB") + " Completed");
    log("-", client + " OK " + (type ? "LIST" : "LSUB") + " Completed");

}










QStringList SslServer::stats(QString boite)
{

    boite = fctn->chemain(boite.trimmed());
    QString dir(_userDir + boite);

    QString iniFile;
    iniFile = dir + "/mails.ini";

    QSettings mSettings(iniFile, QSettings::IniFormat);

    const QStringList listMsg(mSettings.childGroups());
    int messages(0), recent(0), unseen(0), expunge(0);
    QString firstUnseen;

    foreach(QString msg, listMsg)
    {
        mSettings.beginGroup(msg);
        const QString flags(mSettings.value("flags").toString().trimmed().toLower());
        const QStringList listFlags(flags.split(" "));
        const QString uid(mSettings.value("uid").toString().trimmed());
        mSettings.endGroup();

        recent += (! listFlags.contains("seen")) ? 1 : 0;

        messages += 1;
        //unseen += listFlags.contains("unseen") ? 1 : 0;
        unseen = recent;
        expunge += listFlags.contains("deleted") ? 1 : 0;


        if(firstUnseen.isEmpty() && unseen > 0)
        {
            firstUnseen = uid;
        }

    }





    iniFile = dir + "/globals.ini";

    QSettings gSettings(iniFile, QSettings::IniFormat);

    gSettings.beginGroup("globals");
    QString uidvalidity(gSettings.value("uidvalidity").toString().trimmed());
    gSettings.endGroup();

    QStringList listUids(uids());
    QString nextUid(listUids.at(1));

    listStats.clear();
    listStats << QString::number(messages)
              << QString::number(recent)
              << QString::number(unseen)
              << firstUnseen
              << uidvalidity
              << nextUid
              << QString::number(expunge);

    selectedBox = boite;
    return listStats;

}





void SslServer::listParentFolder(QString const userDir, const QString recursif, int i)
{
    const QString myDir(fctn->chemain(userDir + "/"));

    QDir dir(myDir);

    if(dir.exists())
    {
        listDirsStr += myDir + "\r\n";
    }

    dir.setFilter(QDir::NoDotAndDotDot | QDir::AllEntries | QDir::System | QDir::Hidden);
    foreach(QFileInfo fileInfo, dir.entryInfoList())
    {

        if(fileInfo.isDir() && fileInfo.baseName() != "@conf")
        {

            if(recursif == "*")
            {
                listParentFolder(fileInfo.absoluteFilePath(), "*");
            }

            else if(recursif == "%" && i <= 1)
            {
                listParentFolder(fileInfo.absoluteFilePath(), "%", ++i);

            }

            listDirsStr += fctn->chemain(fileInfo.absoluteFilePath() + "/") + "\r\n";
        }
    }
}







QStringList SslServer::sortList(QStringList const list) const
{
    QMap<QString, QString> map;
    foreach(QString const str, list)
    {
        map.insert(str.toLower().trimmed(), str.trimmed());
    }

    return map.values();
}



QString SslServer::removeSep(QString path)
{

    while(fctn->chemain(path).endsWith("/"))
    {
        path = path.left(path.length() -1);
    }
    return path;
}









bool SslServer::hasChildren(QString const folder)
{
    QDir dir(folder);
    dir.setFilter(QDir::NoDotAndDotDot | QDir::AllEntries |
                  QDir::System | QDir::Hidden);

    foreach(QFileInfo fileInfo, dir.entryInfoList())
    {
        if(fileInfo.isDir())
        {
            return true;
        }
    }

    return false;
}




void SslServer::expunge(QSslSocket *sslSocket)
{

    if(readOrWrite < 1)
    {
        return;
    }


    QString mailsFile(selectedDirectory + "mails.ini");

    QSettings settings(mailsFile, QSettings::IniFormat);
    QStringList listMsg(settings.childGroups());
    // QSslSocket *sslSocket = (QSslSocket *)sender();

    foreach(QString const id, listMsg)
    {
        settings.beginGroup(id);
        QString file(settings.value("file").toString().trimmed());
        QString flags(settings.value("flags").toString().trimmed().toLower());
        QString allFlags(fctn->nettoyageFlags(flags));

        if(allFlags.contains("deleted", Qt::CaseInsensitive))
        {
            QFile::remove(selectedDirectory + file + ".eml");
            settings.remove("");
            sendData(sslSocket, "* " + id + " EXPUNGE");
        }

        settings.endGroup();
    }

}









void SslServer::fetch(const bool uid, QString uidMsg, QString cmd, QString copy, const QString i)
{
    QString mailsFile(selectedDirectory + "mails.ini");

    QString myFile, myDate;

    myFile = iniReturnValueByUid(mailsFile, uidMsg, "file");
    myDate = iniReturnValueByUid(mailsFile, uidMsg, "dateText");

    myDate.mid(6);

    QString data, tmp(cmd), tmp2(cmd);
    tmp.replace("-", "");
    tmp2.replace(")", "");
    tmp2.replace("(", "");

    const QStringList listCmd(tmp2.split(" "));

    QString msgFile = selectedDirectory + myFile + ".eml";
    if(! QFile::exists(msgFile))
    {
        return;
    }

    const QString msgContents(fctn->fileGetContents(msgFile));




    bool _flags, _internaldate, _rfc822size, _envelope, _body, _uid, _bodystructure, seen, _rfc822header, _rfc822text, _rfc822;
    _flags = _internaldate = _rfc822size = _body = _envelope = _uid = _bodystructure = seen = _rfc822header = _rfc822text = _rfc822 = false;

    // _rfc822 = false;
    // _envelope = false;







    QRegExp rx, rx2;
    rx.setMinimal(true);
    rx.setCaseSensitivity(Qt::CaseInsensitive);
    rx2.setMinimal(true);
    rx2.setCaseSensitivity(Qt::CaseInsensitive);


    // ALL : Macro équivalente à (FLAGS INTERNALDATE RFC822.SIZE ENVELOPE)
    rx.setPattern("\\b(ALL)\\b");
    if(rx.indexIn(cmd) != -1)
    {
        _flags = _internaldate = _rfc822size = _envelope = true;
    }



    // FAST : Macro équivalente à (FLAGS INTERNALDATE RFC822.SIZE)
    rx.setPattern("\\b(FAST)\\b");
    if(rx.indexIn(cmd) != -1)
    {
        _flags = _internaldate = _rfc822size = true;
    }




    // FULL : Macro équivalente à (FLAGS INTERNALDATE RFC822.SIZE ENVELOPE BODY)
    rx.setPattern("\\b(FULL)\\b");
    if(rx.indexIn(cmd) != -1)
    {
        _flags = _internaldate = _rfc822size = _envelope = _body = true;
    }




    rx.setPattern("\\b(BODYSTRUCTURE)\\b");
    if(rx.indexIn(cmd) != -1)
    {
        _bodystructure = true;
    }

    rx.setPattern("\\b(ENVELOPE)\\b");
    if(rx.indexIn(tmp) != -1)
    {
        _envelope = true;
    }



    rx.setPattern("\\b(FLAGS)\\b");
    if(rx.indexIn(cmd) != -1)
    {
        _flags = true;
    }




    rx.setPattern("\\b(INTERNALDATE)\\b");
    if(rx.indexIn(cmd) != -1)
    {
        _internaldate = true;
    }



    if(listCmd.contains("RFC822.HEADER", Qt::CaseInsensitive))
    {
        _rfc822header = true;
    }



    if(listCmd.contains("RFC822.SIZE", Qt::CaseInsensitive))
        // rx.setPattern("\\s\\b(RFC822\\.SIZE)\\b");
        // if(rx.indexIn(cmd) != -1)
    {
        _rfc822size = true;
        //  cmd.replace(rx, ""); // Pour ne pas confondre avec RFC822 (msg contents)
    }




    /*
    // Renvoyer le contenu du message sans les entetes
    // Equivalent à BODY[TEXT] mais ne supporte pas les sections (<octet>)
    // Erreur de faire RFC822.TEXT<512>
    // Return RFC822.TEXT {sizeOfBody}\r\n...

    rx.setPattern("\\s\\b(RFC822\\.TEXT)\\b");
    if(rx.indexIn(cmd) != -1)
    {
        _rfc822text = rx.cap(1);
      //  cmd.replace(rx, ""); // Pour ne pas confondre avec RFC822 (msg contents)
        seen = true;
    }
*/

    if(listCmd.contains("RFC822.TEXT", Qt::CaseInsensitive))
    {
        //rx.setPattern("\\b(RFC822\\.TEXT)\\b");
        //rx.indexIn(cmd);
        _rfc822text = true;

        //  cmd.replace(rx, ""); // Pour ne pas confondre avec RFC822 (msg contents)
    }



    //! A mettre après la detection de RFC822.SIZE, RFC822.HEADER et RFC822.TEXT
    // Renvoyer la totalité du message y compris les entetes
    // Equivalent à BODY[] mais ne supporte pas les sections (<octet>)
    // Erreur de faire RFC822<512>
    // Return RFC822 {sizeOfMsg}\r\n...

    /*rx.setPattern("\\s\\b(RFC822)\\b\\s*");
    if(rx.indexIn(cmd) != -1)
    {
        _rfc822 = rx.cap(1).trimmed();
        seen = true;
    }
*/

    if(listCmd.contains("RFC822", Qt::CaseInsensitive))
    {
        _rfc822 = true;
    }



    rx.setPattern("\\b(UID)\\b");
    if(rx.indexIn(cmd) != -1)
    {
        _uid = true;
    }



    //! _______________________________________________________
    //! _______________________________________________________


    data = "* " + i + " FETCH (";

    if(_uid || uid)
        data += "UID " + uidMsg;


    if(_flags)
    {

        QString flags(iniReturnValueByUid(mailsFile, uidMsg, "flags"));
        data += " FLAGS (" + fctn->prepareFlags(flags) + ")";
    }

    if(_internaldate)
    {
        data += " INTERNALDATE \"" + myDate + "\"";

    }


    if(_rfc822size)
    {
        data += " RFC822.SIZE " + iniReturnValueByUid(mailsFile, uidMsg, "size");

    }

    if(_envelope)
    {
        data += " ENVELOPE (" + detectEnvelope(uidMsg) + ")";
    }




    QString command, answer;
    TImap imf;
    QSharedPointer<TMessage> message = imf.parseString(msgContents);


    if(_rfc822header)
    {
        command = "BODY[HEADER]";
        answer = imf.fetchBody(message, command, "RFC822.HEADER");
        data += " " + answer; //!\ Pas de \r\n ici (tested) !!
    }


    if(_rfc822)
    {
        command = "BODY[]";
        answer = imf.fetchBody(message, command, "RFC822");
        data += " " + answer; //!\ Pas de \r\n ici (tested) !!
    }

    if(_rfc822text)
    {
        command = "BODY[TEXT]";
        answer = imf.fetchBody(message, command, "RFC822.TEXT");
        data += " " + answer; //!\ Pas de \r\n ici (tested) !!
    }







    //! _______________________________________________________
    //! _______________________________________________________









    if(_bodystructure || _body)
    {
        data += " BODYSTRUCTURE " + imf.fetchBodyStructure(message);
    }



    //! HEADER, HEADER.FIELDS, HEADER.FIELDS.NOT, MIME, et TEXT
    QRegularExpression partRegex("\\s*BODY(?<peek>\\.PEEK)?\\[(?<part>[^\\]]*)\\]\\s*",
                                 QRegularExpression::CaseInsensitiveOption
                                 | QRegularExpression::DontCaptureOption
                                 //| QRegularExpression::OptimizeOnFirstUsageOption
                                 | QRegularExpression::DotMatchesEverythingOption);

    QRegularExpressionMatchIterator matchIterator = partRegex.globalMatch(cmd);
    while (matchIterator.hasNext()) {
        QRegularExpressionMatch m = matchIterator.next();


        if (m.captured("peek").isEmpty())
        {
            seen = true;
        }

        QString part = m.captured("part").trimmed();

        QString command = "BODY[" + part + "]";

        QString answer = imf.fetchBody(message, command);
        data += " " + answer; //!\ Pas de \r\n ici (tested) !!
    }


    data += ")"; //!\ Pas de \r\n ici (tested) !!


    data.replace("FETCH ( ", "FETCH (");



    if(seen)
    {

        updateFlags("seen", uidMsg);
    }

    QSslSocket *sslSocket = (QSslSocket *)sender();
    sendData(sslSocket, data);

    //log(i <= 1 ? copy : "-", "[...]");
    log(copy, data);

}











QString SslServer::detectEnvelope(QString uidMsg)
{

    QString mailsFile(selectedDirectory + "mails.ini");
    QString subject, from, sender, replyTo, to, cc(" NIL"), bcc(" NIL"), inReplyTo(" NIL"), messageId(" NIL");



    QString file(iniReturnValueByUid(mailsFile, uidMsg, "file"));
    QString date(iniReturnValueByUid(mailsFile, uidMsg, "dateText"));

    QString myFile(selectedDirectory + file.trimmed() + ".eml");

    QRegExp rx;
    rx.setMinimal(true);
    rx.setCaseSensitivity(Qt::CaseInsensitive);

    QString contents(fctn->returnAllHeadres(myFile));
    QStringList listContents(contents.split("\r\n"));


    foreach(QString strContent, listContents)
    {
        strContent = strContent.trimmed();


        rx.setPattern("Subject([\\s]+)?:(.*)$");
        if(rx.indexIn(strContent) != -1)
        {
            subject = rx.cap(2).trimmed();
            continue;
        }



        rx.setPattern("From([\\s]+)?:(.*)$");
        if(rx.indexIn(strContent) != -1)
        {
            QString _from = fctn->detecterMail(rx.cap(2).trimmed());
            from = " (" + envelopeMail(_from) + ")";
            continue;
        }


        rx.setPattern("Sender([\\s]+)?:(.*)$");
        if(rx.indexIn(strContent) != -1)
        {
            QString _sender = fctn->detecterMail(rx.cap(2).trimmed());
            sender = " (" + envelopeMail(_sender) + ")";
            continue;
        }



        rx.setPattern("Reply\\-To([\\s]+)?:(.*)$");
        if(rx.indexIn(strContent) != -1)
        {
            QString _replyTo = fctn->detecterMail(rx.cap(2).trimmed());
            replyTo = " (" + envelopeMail(_replyTo) + ")";
            continue;
        }




        rx.setPattern("To([\\s]+)?:(.*)$");
        if(rx.indexIn(strContent) != -1)
        {
            QString _to = fctn->detecterMail(rx.cap(2).trimmed());
            // explode ","
            to = " (" + envelopeMail(_to) + ")";
            continue;
        }



        rx.setPattern("Cc([\\s]+)?:(.*)$");
        if(rx.indexIn(strContent) != -1)
        {
            QString _cc = fctn->detecterMail(rx.cap(2).trimmed());
            cc = "(" + envelopeMail(_cc) + ")";
            continue;
        }




        rx.setPattern("Bcc([\\s]+)?:(.*)$");
        if(rx.indexIn(strContent) != -1)
        {
            QString _bcc = fctn->detecterMail(rx.cap(2).trimmed());
            bcc = " (" + envelopeMail(_bcc) + ")";
            continue;
        }




        rx.setPattern("In\\-Reply\\-To([\\s]+)?:(.*)$");
        if(rx.indexIn(strContent) != -1)
        {
            QString _inReplyTo = fctn->detecterMail(rx.cap(2).trimmed());
            inReplyTo = ! _inReplyTo.isEmpty() ? " \"" + _inReplyTo +"\"" : " NIL";
            continue;
        }


        rx.setPattern("Message\\-Id([\\s]+)?:(.*)$");
        if(rx.indexIn(strContent) != -1)
        {
            QString _messageId = rx.cap(2).trimmed();
            messageId = ! _messageId.isEmpty() ? " \"" + _messageId+"\"" : " NIL";
            continue;
        }

    }


    QString data("\"" + date + "\"" + " \"" + subject + "\"" + from + (! sender.isEmpty() ? sender : from) + (! replyTo.isEmpty() ? replyTo : from) + to + cc + bcc + inReplyTo + messageId);


    return data.simplified();

}





QString SslServer::envelopeMail(QString value)
{
    QString mailboxName("NIL"), domaineName("NIL");
    QStringList mailboxDomain = value.split("@");
    if(mailboxDomain.count() == 2)
    {
        mailboxName = "\"" + mailboxDomain.at(0).trimmed() + "\"";
        domaineName = "\"" + mailboxDomain.at(1).trimmed() + "\"";
    }
    return "(NIL NIL " + mailboxName + " " + domaineName + ")";
}













QStringList SslServer::sortListNumeric(QStringList const list)
{
    QMap<int, QString> map;
    foreach(QString const str, list)
    {
        qint64 i(str.toLongLong());
        map.insert(i, QString::number(i));
    }

    return map.values();
}





QStringList SslServer::detectAllIds()
{

    QString mailsFile(selectedDirectory + "mails.ini");
    QStringList list;//(QStringList() << "");
    QFile file(mailsFile);
    if(! file.exists())
    {
        return list;
    }

    QSettings settings(mailsFile, QSettings::IniFormat);
    return sortListNumeric(settings.childGroups());

}



QStringList SslServer::detectAllUids()
{
    QString mailsFile(selectedDirectory + "mails.ini");
    QSettings settings(mailsFile, QSettings::IniFormat);

    QStringList list;//(QStringList() << "");
    QFile file(mailsFile);
    if(! file.exists())
    {
        return list;
    }

    QStringList listReturn;//(QStringList() << "");
    foreach(const QString grp, settings.childGroups())
    {
        settings.beginGroup(grp);
        const QString uid(settings.value("uid").toString().simplified());

        if(! uid.isEmpty())
        {
            listReturn << uid;
        }
        settings.endGroup();
    }
    return sortListNumeric(listReturn);

}





QStringList SslServer::parseCmd(QString value, const bool type)
{
    value.replace(QRegExp("\\s*"), "");

    QStringList endList, listUids;
    qint64 idvalidity(0);
    if(type)
    {
        listUids = detectAllUids();

        if(listUids.count() > 0)
        {
            idvalidity = listUids.last().toLongLong();
        }

    }
    else
    {
        listUids = detectAllIds();

        if(listUids.count() > 0)
        {
            idvalidity = listUids.count();
        }
    }

    if(idvalidity < 1)
    {
        return endList;
    }


    qint64 a(0), b(0);

    QRegExp rx;

    rx.setPattern("(\\d+):(\\*|(\\d+))$");
    if(rx.exactMatch(value))
    {
        a = rx.cap(1).simplified().toLongLong();
        const QString strFin(rx.cap(2).simplified());

        if(a < 1 || a > idvalidity)
        {
            return endList;
        }

        b = (strFin == "*" ? idvalidity : rx.cap(2).simplified().toLongLong());

        if(b < a)
        {
            return endList;
        }

        if(b > idvalidity)
        {
            b = idvalidity;
        }

        for(int i(a); i <= b; ++i)
        {
            endList << QString::number(i);
        }


    }

    endList.removeDuplicates();


    return endList;
}







// type : true = Uids ; false = Ids
QStringList SslServer::returnInt(QString value, const bool type)
{

    QRegExp rx;
    rx.setCaseSensitivity(Qt::CaseInsensitive);
    rx.setMinimal(true);

    value.replace(QRegExp("\\s*"), "");
    QStringList listStr(value.split(",")), returnList, endList;


    listStr.removeDuplicates();

    foreach(const QString str, listStr)
    {
        // 1, 2, 3, n..
        rx.setPattern("^\\d+$");

        if(rx.exactMatch(str))
        {
            returnList << str;

        }

        // 1:5 ; 2:8 ; 2:*
        else
        {

            rx.setPattern("^(\\d+):(\\*|(\\d+))$");
            if(rx.exactMatch(str))
            {

                const QString strFin(rx.cap(2).simplified());
                returnList << parseCmd(str, type);

                if(strFin == "*")
                {

                    break;
                }
            }

        }


    }

    returnList.removeDuplicates();

    QStringList allEntry(detectAllUids());

    foreach(QString entry, returnList)
    {
        if(entry.isEmpty()) continue;


        if(type)
        {

            if(! allEntry.contains(entry)) continue;

            const qint64 indexOf(allEntry.indexOf(entry));
           if(indexOf == -1) continue; // facultatif

            endList << QString::number(indexOf + 1) + ":" + entry;

        }
        else
        {

            const qint64 msg(entry.toLongLong() - 1);
            if(msg < 0 || msg > allEntry.count())
            {
                continue;
            }

            endList << entry + ":" + allEntry.at(msg);
        }

    }

    endList.removeDuplicates();
    return endList;

}




