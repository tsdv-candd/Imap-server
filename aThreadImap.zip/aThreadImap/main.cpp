#include "myserver.h"
#include "SslServer.h"

#include <QCoreApplication>
#include <QSettings>


int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    Conf cfg;

    QSettings settings(cfg._fileMultiHoming, QSettings::IniFormat);
    foreach(const QString grp, settings.childGroups())
    {
        settings.beginGroup(grp);

        const QString server(settings.value("server").toString().simplified().toUpper());

        settings.endGroup();

        if(server == "IMAP")
        {
            myServer *aqw = new myServer(grp);
            aqw->start();

        }
    }

    return a.exec();
}
