
#ifndef SSLSERVER_H
#define SSLSERVER_H

#include <QTcpServer>
#include <QString>
#include <QSsl>
#include <QSslCertificate>
#include <QSslKey>
#include <QSslSocket>
#include <QKeyEvent>

#include "myFiles/fonctions.h"
#include "myFiles/mails.h"
#include "myFiles/domaines.h"

class SslServer : public QTcpServer
{
    Q_OBJECT


signals:
 void error(const QString err);

public:
    SslServer(QObject *parent = 0);



    const QSslCertificate &getSslLocalCertificate() const;
    const QSslKey &getSslPrivateKey() const;
    QSsl::SslProtocol getSslProtocol() const;


    void setSslLocalCertificate(const QSslCertificate &certificate);
    bool setSslLocalCertificate(const QString &path, QSsl::EncodingFormat format = QSsl::Pem);

    void setSslPrivateKey(const QSslKey &key);
    bool setSslPrivateKey(const QString &fileName, QSsl::KeyAlgorithm algorithm = QSsl::Rsa, QSsl::EncodingFormat format = QSsl::Pem, const QByteArray &passPhrase = QByteArray());

    void setSslProtocol(QSsl::SslProtocol protocol);
    bool getSecurity() const;

    void setParams(const QString _grp, const QString _addr, const qint16 _port,
                   const QString _security, QSsl::SslProtocol _protocol, const QString _certificate,
                   const QString _key
                   );
    void nbInferiors(const QString dirPath);

private slots:
    void readyRead();
    void disconnected();
    void slIdle(QString file);

   void slError(const QString err);


protected:
    void incomingConnection(int socketDescriptor);


private:

      QSslCertificate m_sslLocalCertificate;
    QSslKey m_sslPrivateKey;
    QSsl::SslProtocol m_sslProtocol;

    void sendData(QSslSocket *sslSocket_, QString data);
    QString responseLine, _lastData, _received, capability;
    bool statIdentification, startTlsInitialized;
    QString addr, grp, certificate, key, security;
    quint16 port;
    QSsl::SslProtocol protocol;

    int nbCurrentInferiors;

    QStringList idleStats;


    QString formatChemain(QString chemain);

    QString returnDir(const QString dir, const bool type = true);

    bool begin(QSslSocket *sslSocket_, const QString client, const bool selection = true);

    void log(QString const received, QString const send, QString daemon = "imapd", const int num = 1);


    Conf *cfg;
    Fonctions *fctn;
    Domaines *fDomaines;
    Mails *fMails;

    QStringList listStats;
    bool authenticated, appendSent;
    QString selectedDirectory, selectedSubDirectory, myIpAddress, hostConnectedIp, selectedBox, idleClient;

    int closeConnection, erreurCommande;
    int authentification, readOrWrite;


    QString xAuthLogin, xAuthUser, xAuthDomaine, _userDir, _fileMails, _fileUids;

    QString currentClient, appendClient, appendDir, appendFlags, appendDate, _validFlags;

    qint64 appendSize;

    int maxInferiors;


    QString detectIdByUid(QString mailsFile, QString uid);
    QString detectUidById(const QString iniFile, const QString id) const;
  //  QStringList returnIds(QString value);
  //  QStringList detectIds(QString value);
   // QStringList detectUids(QString value);
  //  QStringList returnUids(QString value);

    void copyMsg(QString const uidMsg, QString const to);

    QStringList hasSubscribeOrIsMarked(QString const folder);
    bool removeDir(QString dirPath);
    QStringList uids() const;
    QString updateFlags(QString flags, QString uidMsg, QString type = "=");

    QString iniReturnValueByUid(QString file, QString uid, QString directive);
    void listDir(QSslSocket *sslSocket_, QString dir, QString const client, const QString cmd, const bool type = true);

    QStringList stats(QString boite = "");
    QString listDirsStr;

    void listParentFolder(const QString userDir, const QString recursif = "*", int i = 0);
    QStringList sortList(QStringList const list) const;

    QString removeSep(QString path);

    bool hasChildren(QString const folder);
    void expunge(QSslSocket *sslSocket_);
    void fetch(const bool uid, QString uidMsg, QString cmd, QString copy, const QString i);
    QString detectEnvelope(QString uidMsg);

    QString envelopeMail(QString value);







    QStringList returnInt(QString value, const bool type = true);
    QStringList parseCmd(QString value, const bool type);
    QStringList detectAllUids();
    QStringList detectAllIds();
    QStringList sortListNumeric(QStringList const list);







};

#endif // SSLSERVER_H
