#ifndef TIMAP_H
#define TIMAP_H

#include"tmessage.h"
#include<QString>
#include<QList>
#include<QHash>
#include<QSharedPointer>

class TImap
{
    enum TImfPhase {HeaderReading, BodyReading};
private:
    QString getAndQuote(QHash<QString,QSharedPointer<TFieldInfo> > hash, QString key, bool useDefault=false, QString _default = "");
    QString inQuote(QString value, bool exists = true, bool useDefault = false, QString _default = "");
    QString getAddressStructure(QSharedPointer<TFieldInfo> fieldInfo);
    QString fetchBody(QSharedPointer<TMessage> message, QString section, int origin, int octet);
    static bool startPositionLessThan(const QSharedPointer<TFieldInfo> fieldInfo1, const QSharedPointer<TFieldInfo> fieldInfo2);
public:
    QString loadFromFile(QString fileName);
    QSharedPointer<TMessage> parseString(QString imfString);
    QString fetchBody(QSharedPointer<TMessage> message, QString command, QString returnStr = "");
    QString fetchBodyStructure(QSharedPointer<TMessage> message);
    void showMessageTree(QSharedPointer<TMessage> rootMessage);
};

#endif // TIMAP_H
