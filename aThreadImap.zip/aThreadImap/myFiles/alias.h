#ifndef ALIAS_H
#define ALIAS_H

#include <QStringList>
#include <QString>

#include "fonctions.h"



class Alias
{
public:
    Alias();


public:
    //  QString  _fileAlias;
    //QString _domaine;


    QStringList listAlias(const QString &file) const;
    QStringList detectRedirectAlias(QString alias, QString domaine);

    bool aliasExists(QString alias, QString domaine);

    Conf *cfg;
    Fonctions *fctn;

};

#endif // ALIAS_H
