#ifndef INET_H
#define INET_H

#include <QObject>
#include <QDnsLookup>
#include <QNetworkReply>
#include <QStringList>
#include <qDebug>

class iNet : public QObject
{
    Q_OBJECT
public:

    explicit iNet(QObject *parent = 0);


    // MX
    void envoieMX(const QString &domaine, const QStringList &autresParametres);


signals:

    // MX
    void sgMxFound(const bool &result, const QStringList &autresParametres) const;
    void sgMxValue(const QString &value, const QStringList &autresParametres) const;





private slots:

    // MX
    void slResolveMX(const QString &domaine);
    void resultsReady();





private:

    QDnsLookup *myDns;
    QStringList otherParameters;
};

#endif // INET_H
