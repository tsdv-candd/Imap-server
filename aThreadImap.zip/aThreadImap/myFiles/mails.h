#ifndef MAILS_H
#define MAILS_H

#include <QString>
//#include <QDebug>
#include <QStringList>
#include <QSettings>
#include <QDateTime>


#include "fonctions.h"



class Mails
{
public:
    Mails();


    //void addMail();



    QString mailReturnConf(QString groupe, QString const &directive,
                           QString domaine) const;
QString mailDetectCompteById(QString id, QString domaine) const;


    Conf *cfg;

};

#endif // MAILS_H
