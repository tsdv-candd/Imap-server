#ifndef LISTES_H
#define LISTES_H

#include <QString>
//#include <QDebug>
#include <QStringList>
#include <QSettings>

#include "fonctions.h"


class Listes
{
public:
    Listes();


public:

    bool listeExists(QString const &liste, QString const &domaine) const;

    QString listeReturnConf(QString const &liste, QString directive,
                            QString const &domaine) const;

    QStringList listeValues(QString const &liste, const QString &domaine) const;


    Conf *cfg;
    Fonctions *fctn;
};

#endif // LISTES_H
