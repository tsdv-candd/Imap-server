#include "inet.h"

iNet::iNet(QObject *parent) :
    QObject(parent)
{

    myDns = new QDnsLookup;
    myDns->setType(QDnsLookup::MX);
}




void iNet::envoieMX(const QString &domaine, const QStringList &autresParametres)
{
    otherParameters.clear();
    otherParameters << autresParametres;
    slResolveMX(domaine);
}




void iNet::slResolveMX(const QString &domaine)
{   
    qDebug() << endl << " ----------- " << domaine << endl;
    myDns->setName(domaine);
    connect(myDns, SIGNAL(finished()), this, SLOT(resultsReady()));
    myDns->lookup();
}




void iNet::resultsReady()
{

    // Check the lookup succeeded.
    if (myDns->error() != QDnsLookup::NoError)
    {
        qDebug() << "DNS lookup failed";

        emit sgMxFound(false, otherParameters);

        myDns->deleteLater();
        return;
    }
    // MX records
    foreach(const QDnsMailExchangeRecord &record, myDns->mailExchangeRecords())
    {

        emit sgMxValue(record.exchange(), otherParameters);
        qDebug() << record.name() << record.timeToLive() << record.preference() << record.exchange();

break;
    }
    myDns->deleteLater();

}







