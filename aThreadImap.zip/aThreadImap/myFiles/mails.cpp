#include "mails.h"

Mails::Mails()
{
    cfg = new Conf();

}



QString Mails::mailReturnConf(QString groupe, QString const &directive,
                              QString domaine) const
{

    groupe = groupe.trimmed().toLower();
    domaine = domaine.trimmed().toLower();


    QSettings settings(cfg->_fileMails.arg(domaine), QSettings::IniFormat);
    settings.beginGroup(groupe);
    QString returnValue = settings.value(directive.trimmed()).toString().simplified();
    QString transfert = settings.value("transfert").toString().trimmed();
    settings.endGroup();

    if(directive == "transfertDestination")
    {
        if(transfert != "1" || returnValue.toLower() == groupe + "@" + domaine)
        {
            return "";
        }
        else
        {
            return returnValue.toLower();
        }

    }

    return returnValue.trimmed();
}







QString Mails::mailDetectCompteById(QString id, QString domaine) const
{
    id = id.trimmed();
    domaine = domaine.toLower().trimmed();
    QSettings settings(cfg->_fileMails.arg(domaine), QSettings::IniFormat);

    foreach(QString const &key, settings.childGroups())
    {
        settings.beginGroup(key);
        QString idCompte = settings.value("id").toString().trimmed();
        settings.endGroup();
        if(idCompte == id) return key;
    }
    return "";
}





