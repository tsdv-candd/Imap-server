

#ifndef MYSERVER_H
#define MYSERVER_H

#include "SslServer.h"
#include <QObject>
#include <QSslSocket>
#include <QThread>

class myServer : public QThread
{
    Q_OBJECT

public:
myServer (const QString grp, QObject *parent = 0);



public slots:
    void run();

private:
    QString addr, grp;
    QString security, server;
    quint16 port;
    QSsl::SslProtocol protocol;
    QString certificate;
    QString key;
bool etat;

Fonctions *fctn;
SslServer *sslServer;

};

#endif // MYSERVER_H
