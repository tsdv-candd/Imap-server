#include "domaines.h"

Domaines::Domaines()
{
    cfg = new Conf();


}


QMap<QString, QString> Domaines::domaineReturnConfMap(QString const &domaine) const
{

    QMap<QString, QString> map;
    QSettings settings(cfg->_fileDomaines, QSettings::IniFormat);
    settings.beginGroup(domaine.trimmed().toLower());
    foreach(QString myKey, settings.allKeys())
    {
        map.insert(myKey, settings.value(myKey).toString().simplified());
    }

    return map;
}


QString Domaines::domaineReturnConf(QString const &domaine, QString const &directive) const
{

    QMap<QString, QString> map(domaineReturnConfMap(domaine));
    QString returnValue = map[directive.trimmed()];


    if(directive == "catchall")
    {
        QStringList list(returnValue.toLower().split("@"));
        return list.at(0).trimmed();
    }

    return returnValue.trimmed();
}








bool Domaines::domaineExists(QString const &domaine) const
{

    QSettings settings(cfg->_fileDomaines, QSettings::IniFormat);
    settings.beginGroup(domaine.trimmed().toLower());
    return settings.allKeys().count() > 1;
}








