#ifndef DOMAINES_H
#define DOMAINES_H

#include <QString>
#include <QStringList>
#include <QSettings>
#include <QDateTime>

#include "fonctions.h"


class Domaines
{
public:
    Domaines();


    //void addDomaine();



    QString domaineReturnConf(QString const &domaine, QString const &directive) const;

    QMap<QString, QString> domaineReturnConfMap(QString const &domaine) const;

    bool domaineExists(QString const &domaine) const;


    Conf *cfg;
    //Fonctions *fctn;

};

#endif // DOMAINES_H
