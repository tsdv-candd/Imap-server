1) 
Plase configure this project path in ./files/conf.cpp
_myPath = "C:/software/ServerWithBugs/"; replace C:/software/ServerWithBugs/ with project current path.

Nb : You need add this path of directory content this "data" sub-directory

C:/software/ServerWithBugs/			<---- this !
C:/software/ServerWithBugs/data
C:/software/ServerWithBugs/files
C:/software/ServerWithBugs/logs
C:/software/ServerWithBugs/pid
C:/software/ServerWithBugs/cert.pem
C:/software/ServerWithBugs/key.pem
C:/software/ServerWithBugs/libeay32.dll
C:/software/ServerWithBugs/libssl32.dll
C:/software/ServerWithBugs/ssleay32.dll


2) copy 
libeay32.dll, ssleay32.dll and libssl32.dll to debug and/or relase of Qt.


3) Test account : login "a@qq.com" & pwd "aa"

4) If you have delet messages (mails) with your mail client, you cann unzip this ./ServerWithBugs/data/aa.com.zip in "data" directory to have more messages (mails)


IF YOU HAVE AN ERROR : "qt.network.ssl: QSslSocket: cannot resolve TLSv1_1_client_method" YOU NEED TO COPY "libeay32.dll", "ssleay32.dll" and "libssl32.dll" INTO debug AND/OR relase OF Qt AND RECOMPILE THIS PROJECT.



5) If you need help, please tell me


Thanks


 