#ifndef FONCTIONS_H
#define FONCTIONS_H

#include <QMessageBox>
#include <QDir>
#include <QCalendarWidget>
#include <QIcon>
#include <QRegExp>
#include <QFile>
#include <QSettings>
#include <QCryptographicHash>
#include <QtNetwork>
#include <QTextStream>
#include <QDebug>
#include <QThread>
#include <QDesktopServices>

#include "conf.h"



// Usage Sleeper::sleep(2);

class Sleeper : public QThread
{

public:

    static void usleep(unsigned long usecs)
    {
        QThread::usleep(usecs);
    }

    static void msleep(unsigned long msecs)
    {
        QThread::msleep(msecs);
    }

    static void sleep(unsigned long secs)
    {
        QThread::sleep(secs);
    }

};




class Fonctions
{

public:


    Fonctions();


    QString base64Encode(const QString &string) const;

    QString base64Decode(const QString &string) const;

    QString fileGetContents(const QString &file) const;

    void filePutContents(const QString &file, const QString &contents) const;

    QString wordWrap(const QString &content, const int &width = 72) const;

    bool antiHammering(const QString &server, const QString &ip, const bool &success);

    QStringList isPermittedIp(const QString &ip, const QString &serveur);

    bool isIpInRange(const QString &ip, const QString &minIp, const QString &maxIp);

    bool isValidIpRange(const QString &minIp, const QString &maxIp);

    int dateswap(QString form, uint unixtime);

    QString timeStampMail(uint unixtime = 0);

    void updMsgInQueue(const QString &groupe, const QString &key, const QString &error, const bool &stop = false) const;

    int mailDelivrableSiCompteLocale(QString const &userFrom, QString const &domaineFrom, int const &size);

    bool listContains(const QStringList &listOut, const QStringList &listIn, const bool &sensitivity = false) const;

    void stopAllServer() const;

    void pid(const QString &server, const QString &etat) const;

    int etatServeur(const QString &server) const;

    void creatLog(const QString &log) const;

    bool manipLog(QString const &log) const;

    QString preparerErreur(const QString &msgId, const QString &newMsgId, QString error);

    QList<int> domaineListeGrise(const QString &domaine);

    QStringList detectFiltre(const QString &typeListe, const QString &de);

    bool dansListBlanche(const QString &user, const QString &domaine, const QStringList &listeAVerifier);

    QList<int> compteListeGrise(const QString &user, const QString &domaine);

    QString currentTxtDateTime() const;

    qint64 timeStampMSecs() const;

    qint64 timeStampSecs() const;

    void log(const QString &resultat, const int &descripteur = 0) const;

    QString chemain(QString value);

    QString insererSignature(QString from, QString to, QString const &value);

    QString regenererMessageId() const;

    QStringList machineIpAddresses() const;

    QStringList aMailServerIpAddresses() const;

    QString aMailServerIpAddress() const;

    QString stringNumber(qint64 const &number) const;

    QString detecterMail(const QString &mail) const;

    QString addHeader(
            QString const &hostConnectedIp, QString const &from,
            QString const &messageId, QString const &authUser,
            QString const &contents
            );


    QString headerReturnValues(QString header, const QString &values);

    QString returnAllHeadres(const QString &values);

    QStringList gestionRepondeur(QString mail, QString domaine) const;

    QStringList listSignatureDomaine(QString const &domaines);

    QString iniReturnValue(const QString &file, QString const &groupe, QString const &directive) const;

    void addNewMsg(QString const &user, QString const &domaine, QString const &msgId, const int &size, const QString &dir = "", const QString &flags = "unseen");

    void updateIniDirective(const QString &groupe, const QString &iniFile, const QString &directive, const QString &newValue) const;

    int minMax(QStringList const &list, bool const &type = true) const;

    bool mailDelivrableSiCompteLocal(QString const &user, QString const &domaine,
                                     int const &size) const;

    bool verifMail(QString mail);

    bool verifIp(QString ip, const bool &sensitivity = false);

    bool verifDomaine(QString domaine);

    bool msgBoxHtml(QString msg, QString const &title = "", int const &type = 1) const;

    bool mailExists(QString mail, QString domaine);

    bool domaineExists(QString domaine);

    bool domaineExpired(QString const &domaine) const;

    bool accountExpired(QString const &user, QString const &domaine) const;

    void creatDataDirectory(const bool alert = true);

    void preparerMail(QString value);


    bool verifContent(const QString &content, const QString &regex) const;

    bool creatDirectory(const QString &dirToCreate, const int &uidvalidity) const;
    bool removeDir(QString dirPath);


    QStringList listeDomaines() const;
    QStringList listeComptes(QString const &domaine) const;



    QString nettoyageFlags(QString flags);
    QString prepareFlags(const QString &flags);

    bool inArray(QString nouvelleEntree, QStringList list, const bool caseSensitive = false);

    QStringList arrayUnique(const QStringList list, const bool caseSensitive = false);


    QByteArray xorArray(const QByteArray input, char c);
    QByteArray cramMd5Response(const QByteArray &nonce, const QByteArray &user, const QByteArray &pass);

    int serverAccess(const QString &domaine, const QString &user, QString type = "SMTP");

    bool joker(const QString &contents, QString regex) const;

    void addMsgToQueue(const QString &contents, const QStringList &params, const QStringList &rcptTo);

    QStringList replyToError(const QString &replyTo, const QString &returnPath = "", const QString &from = "");

    bool isValidMsgInQueue(const QString &msgId);

    QStringList domaineIps(const QString &domaine);


    QStringList detectUserDomaine(QString value);

    Conf *cfg;


    // Utilisées pour calculer le quota {{{
    void calculerQuota(QString const &folder);

    QList<qint64> quotaGet(QString const &folder);



    QStringList statsDomaine(const QString &domaine);
    QStringList statsCompte(const QString &user, const QString &domaine);
    QStringList listeNombreMails;
    QStringList listePoids;
    // }}}

};

#endif // FONCTIONS_H
