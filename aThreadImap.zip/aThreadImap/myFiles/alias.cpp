#include "alias.h"
#include "domaines.h"

Alias::Alias()
{
    cfg = new Conf();
}



QStringList Alias::listAlias(QString const &file) const
{

    QStringList listReturn;
    QSettings settings(file, QSettings::IniFormat);
    foreach(QString const &group, settings.childGroups())
    {
        settings.beginGroup(group);

        QString idCompte(settings.value("idCompte").toString().trimmed());
        QString etat(settings.value("etat").toString().trimmed());


        settings.endGroup();

        etat = etat == "1" ? "1" : "0";
        QString ligne(group.toLower() + "||" + idCompte + "||" + etat);

        listReturn << ligne;
    }

    return listReturn;
}






//! ////////////////////////////////////////////////////////////////////////
// Detecter si un compte est local (géré par aMailServer)

bool Alias::aliasExists(QString alias, QString domaine)
{
    alias = alias.trimmed().toLower();
    domaine = domaine.trimmed().toLower();
    if(alias.isEmpty() || domaine.isEmpty()) return false;

    QSettings settings(cfg->_fileAlias.arg(domaine), QSettings::IniFormat);
    settings.beginGroup(alias);
    return settings.allKeys().count() > 0;
}






QStringList Alias::detectRedirectAlias(QString alias, QString domaine)
{

    alias = alias.trimmed().toLower();
    domaine = domaine.trimmed().toLower();
    QString file(cfg->_fileAlias.arg(domaine));


    Domaines d;
    int domaineNombreAliasMax(d.domaineReturnConf(domaine, "nombreAliasMax").toInt());


    QStringList listReturn;
    QStringList list = listAlias(file);
    QString user;


    if(list.count() < 1) return listReturn;
    int i(0);
    foreach(QString myAlias, list)
    {
        QStringList listToExplode(myAlias.split("||"));
        QString regAlias(listToExplode.at(0));
        QString regIdCompte(listToExplode.at(1));
        QString etat(listToExplode.at(2));

        if(regAlias.isEmpty() || regIdCompte.isEmpty() || etat.isEmpty()) continue;

        if(regAlias == alias)
        {
            listReturn.clear();

            // detection du compte
            QSettings settings(cfg->_fileMails.arg(domaine), QSettings::IniFormat);
            foreach(const QString &mail, settings.childGroups())
            {
            settings.beginGroup(mail);
           QString idCompte(settings.value("id").toString().trimmed());
            settings.endGroup();
            if(regIdCompte == idCompte)
            {

            user = mail;
            break;

            }


            }



            listReturn << user << etat;
            break;
        }

        // Limite par Domaine;
        if(domaineNombreAliasMax > 0 && i >= domaineNombreAliasMax) break;



        i++;
    }

    return listReturn;
}








