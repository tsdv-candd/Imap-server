#include "conf.h"

#include<QDebug>







Conf::Conf()
{


    // End with /
    _myPath = "C:/software/aThreadImap/";


    _dataDir = _myPath + "data/";

    _traitementDir = _dataDir + "@mails/";


    _queueDir =  _traitementDir + "queue/";
    _helpDir =  _myPath + "aide/";
    _pidDir =  _myPath + "pid/";

    _logsDir =  _myPath + "logs/%1/";


    _fileQueue = _traitementDir + "queue.ini";

    _fileConfig = _dataDir + "config.ini";
    _fileErrorMsg = _dataDir + "errorMsg.txt";
    _fileRepondeurMsg = _dataDir + "repondeurMsg.txt";
    _fileAntiHammering = _dataDir + "antiHammering.ini";
    _fileMultiHoming = _dataDir + "multiHoming.ini";

    _validFlags = "Deleted Seen Draft Answered Flagged *";

    //! Domaines

    _fileDomaines = _dataDir + "domaines.ini";

    _domaineDir = _dataDir + "%1/";
    _fileMails = _dataDir + "%1/@conf/mails.ini";
    _fileDomaineGreyListingTriplets = _dataDir + "%1/@conf/greyListingTriplets.ini";
    _fileDomaineSignature = _dataDir + "%1/@conf/signature.txt";
    _fileDomaineRbls = _dataDir + "%1/@conf/rbls.ini";




    //! Comptes
    _mailDir = _dataDir + "%1/%2/";
    _fileAlias = _dataDir + "%1/@conf/alias.ini";
    _fileCompteGreyListingTriplets = _dataDir + "%1/%2/@conf/greyListingTriplets.ini";
    _fileFiltres = _dataDir + "%1/@conf/filtres.ini";
    _fileListes = _dataDir + "%1/@conf/listes.ini";
    _fileMailsListes = _dataDir + "%1/%2/@conf/mailsListes.ini";
    _fileMailsFiltres = _dataDir + "%1/%2/@conf/filtres.ini";
    _fileUids = _dataDir + "%1/%2/@conf/uids.ini";

    _fileSignatureEtRepondeur = _dataDir + "%1/%2/@conf/signatureEtRepondeur.txt";

    urlCreateur = "http://www.google.com/";

    version = "1.0";
    recharger();
}








void Conf::recharger()
{   
    QSettings settingsSmtp(_fileConfig, QSettings::IniFormat);
    QSettings settingsPop3(_fileConfig, QSettings::IniFormat);
    QSettings settingsImap(_fileConfig, QSettings::IniFormat);
    QSettings settingsLogs(_fileConfig, QSettings::IniFormat);

    settingsSmtp.beginGroup("configurationSmtp");
    settingsPop3.beginGroup("configurationPop3");
    settingsImap.beginGroup("configurationImap");
    settingsLogs.beginGroup("configurationLogs");

    int _smtpEtat(settingsSmtp.value("etat").toString().toInt());
    QString _defaultDomain(settingsSmtp.value("defaultDomain").toString().trimmed().toLower());
    QString _smtpBienvenue(settingsSmtp.value("smtpBienvenue").toString().trimmed());
    int _smtpPort(settingsSmtp.value("smtpPort").toString().toInt());
    QString _smtpHost(settingsSmtp.value("smtpHost").toString().trimmed().toLower());

    QString _smtpAuthPlain(settingsSmtp.value("smtpAuthPlain").toString().trimmed());
    QString _smtpExpn(settingsSmtp.value("smtpExpn").toString().trimmed());
    int _smtpTailleMaximaleDesMessages(settingsSmtp.value("smtpTailleMaximaleDesMessages").toString().toInt());
    // QString _smtpMailMerror(settingsSmtp.value("smtpMailMerror").toString().trimmed().toLower());
    int _smtpNombreDeCommandesInvalides(settingsSmtp.value("smtpNombreDeCommandesInvalides").toString().toInt());
    int _smtpDeconnectionClient(settingsSmtp.value("smtpDeconnectionClient").toString().toInt());

    settingsSmtp.endGroup();



    int _pop3Etat(settingsPop3.value("etat").toString().toInt());
    QString _pop3Bienvenue(settingsPop3.value("pop3Bienvenue").toString().trimmed());
    int _pop3Port(settingsPop3.value("pop3Port").toString().toInt());
    QString _pop3Host(settingsPop3.value("pop3Host").toString().trimmed().toLower());
    QString _pop3AuthPlain(settingsPop3.value("pop3AuthPlain").toString().trimmed());
    int _pop3NombreDeCommandesInvalides(settingsPop3.value("pop3NombreDeCommandesInvalides").toString().toInt());
    int _pop3DeconnectionClient(settingsPop3.value("pop3DeconnectionClient").toString().toInt());
    int _pop3IntervalleEntreConnexions(settingsPop3.value("pop3IntervalleEntreConnexions").toString().toInt());
    int _pop3sPort(settingsPop3.value("pop3sPort").toString().toInt());

    settingsPop3.endGroup();



    int _imapEtat(settingsImap.value("etat").toString().toInt());
    QString _imapBienvenue(settingsImap.value("imapBienvenue").toString().trimmed());
    QString _imapAuthPlain(settingsImap.value("imapAuthPlain").toString().trimmed());
    int _imapNombreDeCommandesInvalides(settingsImap.value("imapNombreDeCommandesInvalides").toString().toInt());
    int _imapDeconnectionClient(settingsImap.value("imapDeconnectionClient").toString().toInt());
    settingsImap.endGroup();



    int _logSmtp(settingsLogs.value("logSmtp").toString().toInt());
    int _logPop3(settingsLogs.value("logPop3").toString().toInt());
    int _logImap(settingsLogs.value("logImap").toString().toInt());
    int _logDelivrance(settingsLogs.value("logDelivrance").toString().toInt());
    int _logDelivrerLocale(settingsLogs.value("logDelivrerLocale").toString().toInt());
    int _logDelivrerExterne(settingsLogs.value("logDelivrerExterne").toString().toInt());
    int _logRelais(settingsLogs.value("logRelais").toString().toInt());
    int _logTcp(settingsLogs.value("logTcp").toString().toInt());
    qint64 _tailleLogs(settingsLogs.value("tailleLogs").toString().trimmed().toLongLong());
    int _actionLogs(settingsLogs.value("actionLogs").toString().toInt());
    settingsLogs.endGroup();


    //! ######################################################################
    //! <Parametres LOGS>






    //! Log  format JJ-MM-AAAA (Jour-Mois-Année)

    logDelivrance = _logDelivrance > 0 ? true : false;
    logDelivrerLocale = _logDelivrerLocale > 0 ? true : false;
    logDelivrerExterne = _logDelivrerExterne > 0 ? true : false;
    logRelais = _logRelais > 0 ? true : false;
    logTcp = _logTcp > 0 ? true : false;
    logSmtp = _logSmtp > 0 ? true : false;
    logPop3 = _logPop3 > 0 ? true : false;
    logImap = _logImap > 0 ? true : false;

    tailleLogs = _tailleLogs > 0 ? (_tailleLogs * 1024 * 1024) : (20 * 1024 * 1024);
    actionLogs = _actionLogs < 1 ? 0 : 1;





    //! ######################################################################
    //! <Parametres SMTP>



    //! Etat
    smtpEtat = _smtpEtat > 0 ? true : false;


    //! Domaine par défaut
    defaultDomain = _defaultDomain;


    //! Message de bienvenue
    smtpBienvenue = _smtpBienvenue;
    //smtpBienvenue = "aMailServer SMTP ready...";

    //! Port sur lequel aMailServer ecoute
    smtpPort = _smtpPort > 0 ? _smtpPort : 25;


    //! Hôte sur laquelle aMailServer ecoute
    //! Ex : 127.0.0.1
    //! Ex : mondomaine.tld
    //! Ex : localhost

    //! Mettez any pour dir toutes les hôtes (Recommandé)


    smtpHost = !_smtpHost.isEmpty() ? _smtpHost : "any";



    //! Autoriser l'identification en texte plein (login et mot de passe non cryptés)
    //! true ou false
    smtpAuthPlain = _smtpAuthPlain == "0" ? false : true;






    /**
Autoriser la commande EXPN ? C'est une commande, prévue par la RFC, permettant à une personne
(ex : avec un client mail, un script ou encore en ligne de commande) de lister
l'ensemble des inscrits à une liste de distribution.

Ex :

EXPN liste-de-distribution@domaine.tld

aMailSrver répond:

<inscrit1@domaine.tld>
<inscrit2@domaine.tld>
<inscritN@domaine.tld>

Mettez -1, 0, 1
-1 : commande désactivée
0 : commande disponible à tout le monde (Attention aux spammeurs et aux fraudeurs !!)
1 ou une valeur superieure(1, 2,3,4 etc...) : il faut être identifié,
commande disponible qu'au propriétaire de la liste en question (OPTION RECOMMANDÉE)
*/
    smtpExpn = _smtpExpn == "0" ? false : true;




    //! Deconnecter le client après trop de commandes invalide !
    //! C'est pratique pour eviter d'utiliser le serveur à des fins de testes...
    //! Mettez 0 pour illimité
    //! Important mettez quand même un nombre correcte. Nous vous recommandons
    //! un nombre compris entre 10 et 20

    smtpNombreDeCommandesInvalides = (_smtpNombreDeCommandesInvalides >= 10 && _smtpNombreDeCommandesInvalides <= 20) ? _smtpNombreDeCommandesInvalides : 0;





    //! Deconnecter le client s'il reste longtemps sans activité ?
    //! Si oui, indiquez un nombre en seconde. Si non, mettez 0 (chiffre);

    smtpDeconnectionClient = (_smtpDeconnectionClient >= 30 && _smtpDeconnectionClient <= 120) ? (_smtpDeconnectionClient * 1000): 0;




    //! Taille maximale des messages en Ko
    //! Mettez 0 pour illimité
    //! Cette règle s'applique sur tous les messages entrants et sortants,
    //! tous domaines et comptes confondus
    smtpTailleMaximaleDesMessages = (_smtpTailleMaximaleDesMessages == 0 ||_smtpTailleMaximaleDesMessages >= 1024) ? _smtpTailleMaximaleDesMessages : 0;



    //! La directive smtpMailMerror est détectée dans fonction.cpp






    //! ######################################################################
    //! <Parametres POP3>




    //! Etat
    pop3Etat = _pop3Etat > 0 ? true : false;


    //! Message de bienvenue
    pop3Bienvenue = _pop3Bienvenue;
    //pop3Bienvenue = "aMail POP3 Server ready...";

    //! Ports sur lesquels aMailServer écoute
    // Non sécurisé
    pop3Port = _pop3Port > 0 ? _pop3Port : 110;

    // Sécurisé (SSL/TLS)
    pop3sPort = (_pop3sPort > 0 && _pop3sPort != _pop3Port) ? _pop3sPort : 995;


    //! Hôte sur laquelle aMailServer ecoute
    //! Ex : 127.0.0.1
    //! Ex : mondomaine.tld
    //! Ex : localhost

    //! Mettez any pour dir toutes les hôtes (Recommandé)
    pop3Host = ! _pop3Host.isEmpty() ? _pop3Host : "any";



    //! Autoriser l'identification en texte plein (login et mot de passe non cryptés)
    //! true ou false
    pop3AuthPlain = _pop3AuthPlain == "0" ? false : true;







    //! Deconnecter le client après trop de commandes invalide !
    //! C'est pratique pour eviter d'utiliser le serveur à des fins de testes...
    //! Mettez 0 pour illimité
    //! Important mettez quand même un nombre correcte. Nous vous recommandons
    //! un nombre compris entre 10 et 20

    pop3NombreDeCommandesInvalides = (_pop3NombreDeCommandesInvalides >= 10 && _pop3NombreDeCommandesInvalides <= 20) ? _pop3NombreDeCommandesInvalides : 0;





    //! Deconnecter le client s'il reste longtemps sans activité ?
    //! Si oui, indquez un nombre en seconde. Si non, mettez 0 (chiffre);

    pop3DeconnectionClient = (_pop3DeconnectionClient >= 30 && _pop3DeconnectionClient <= 120) ? _pop3DeconnectionClient : 0;




    //! Economisez les ressources en limitant les connexions
    //! multiples ou assez fréquantes.
    //! Mettez un interval en seconde ou mettez 0 pour ne pas limiter
    //! 0 est, toute fois, recommandé

    pop3IntervalleEntreConnexions = (_pop3IntervalleEntreConnexions >= 1 && _pop3IntervalleEntreConnexions <= 120) ? _pop3IntervalleEntreConnexions : 0;










    //! ######################################################################
    //! <Parametres IMAP>




    //! Etat
    imapEtat = _imapEtat > 0 ? true : false;


    //! Message de bienvenue
    imapBienvenue = _imapBienvenue;
    //imapBienvenue = "aMailServer IMAP ready...";

    //! Ports sur lesquels aMailServer écoute
    // Non sécurisé
   // imapPort = _imapPort > 0 ? _imapPort : 110;

    // Sécurisé (SSL/TLS)
   // imapsPort = (_imapsPort > 0 && _imapsPort != _imapPort) ? _imapsPort : 995;


    //! Hôte sur laquelle aMailServer ecoute
    //! Ex : 127.0.0.1
    //! Ex : mondomaine.tld
    //! Ex : localhost

    //! Mettez any pour dir toutes les hôtes (Recommandé)
  //  imapHost = ! _imapHost.isEmpty() ? _imapHost : "any";



    //! Autoriser l'identification en texte plein (login et mot de passe non cryptés)
    //! true ou false
    imapAuthPlain = _imapAuthPlain == "0" ? false : true;







    //! Deconnecter le client après trop de commandes invalide !
    //! C'est pratique pour eviter d'utiliser le serveur à des fins de testes...
    //! Mettez 0 pour illimité
    //! Important mettez quand même un nombre correcte. Nous vous recommandons
    //! un nombre compris entre 10 et 20

    imapNombreDeCommandesInvalides = (_imapNombreDeCommandesInvalides >= 10 && _imapNombreDeCommandesInvalides <= 20) ? _imapNombreDeCommandesInvalides : 0;





    //! Deconnecter le client s'il reste longtemps sans activité ?
    //! Si oui, indquez un nombre en seconde. Si non, mettez 0 (chiffre);

    imapDeconnectionClient = (_imapDeconnectionClient >= 30 && _imapDeconnectionClient <= 120) ? _imapDeconnectionClient : 0;




    //! ######################################################################
    //! <Parametres DELIVREUR EXTERNE>

    // Faits en temps réel


}







QString Conf::chemain(QString value)
{
    value = value.trimmed();
    value.replace("\\", "/");
    value.replace(QRegExp("(/)+"), "/");

    return value;
}

