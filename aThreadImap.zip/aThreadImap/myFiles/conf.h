#ifndef CONF_H
#define CONF_H

#include <QCoreApplication>
#include <QString>
#include <QDebug>
#include <QDateTime>
#include <QStringList>
#include <QSettings>
#include <time.h>
#include<QFileInfo>


class Conf
{
public:
    Conf();

    QString _myPath;
    QString _dataDir, _traitementDir;
    QString _domaineDir;
    QString _mailDir, _pidDir;
    QString _queueDir, _helpDir, _logsDir;
    QString _fileErrorMsg;
    QString _fileRepondeurMsg, _fileAntiHammering;
    QString _fileDomaineRbls;
    QString _fileAlias;
    QString _fileFiltres;
    QString _fileListes;
    QString _fileMailsListes;
    QString _fileMailsFiltres, _fileUids;
    QString _fileDomaineSignature;
    QString _fileSignatureEtRepondeur;
    QString _fileMails;
    QString _fileConfig;
    QString _fileDomaines;
    QString _fileQueueMsg,_fileQueue, _fileQueueToScan, _fileQueueLocale, _fileQueueExterne, _filequeueRelais;
    QString _fileQueueErreurLocale, _fileQueueErreurExterne, _fileMultiHoming;
    QString _validFlags, _fileDomaineGreyListingTriplets, _fileCompteGreyListingTriplets;


    //! <Parametres LOGS>
    bool logSmtp, logPop3, logImap, logDelivrance, logDelivrerLocale, logDelivrerExterne, logRelais, logTcp;
    qint64 tailleLogs;
    int actionLogs;





    //! <Parametres SMTP>
    qint64 smtpPort, smtpTailleMaximaleDesMessages, smtpDeconnectionClient, smtpNombreDeCommandesInvalides;
    QString smtpHost, smtpBienvenue, defaultDomain;
    bool smtpEtat, smtpAuthPlain, smtpExpn, smtpVrfy;



    //! <Parametres POP3>
    QString pop3Bienvenue, pop3Host;
    bool pop3Etat, pop3AuthPlain;
    qint64 pop3Port, pop3sPort, pop3NombreDeCommandesInvalides, pop3DeconnectionClient, pop3IntervalleEntreConnexions;

    //! <Parametres IMAP>
    QString imapBienvenue, imapostssssssssssssss;
    bool imapEtat, imapAuthPlain;
    qint64 imapPort, imapsPort, imapNombreDeCommandesInvalides, imapDeconnectionClient;


    QString urlCreateur, version;


    void recharger();

QString chemain(QString value);

};

#endif // CONF_H
