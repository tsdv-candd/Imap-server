Evry email account have this architecture :

email/Drafts, email/INBOX, email/Junk, email/Sent and email/Trash where email is this account adress email :

frelancer@gmail.com/Drafts
frelancer@gmail.com/INBOX
frelancer@gmail.com/Junk
frelancer@gmail.com/Sent
frelancer@gmail.com/Trash


Evry directory have 1 ini files and zero, one or more mail file (xxxx.eml)

* mails.ini content for each mail 6 entry:

uid : this unique id for this mail
file : this file name in this directory
size : mail size in kb
flags : mail flags
dateText : received date text
dateTime : received timestamp

Eg :
uid=497
file=1433783069174
size=75
flags=seen deleted $Junk
dateText="Sat, 13 Jun 2015 23:23:53 +0200"
dateTime=1434230633


For this project you need execute command in this respective directory be parsing firt this mails.ini file

Eg :

A00004 UID SEARCH FLAGGED you need pars ini file and add this mail where this flags directive content flagged

A00004 UID SEARCH 497 you need pars ini file and add this mail where this uid directive equal 497
...

