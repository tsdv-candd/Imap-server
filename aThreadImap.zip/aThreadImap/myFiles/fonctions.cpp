#include "fonctions.h"
#include <QHostInfo>


Fonctions::Fonctions()
{
    cfg = new Conf;
}



QString Fonctions::fileGetContents(const QString &file) const
{
    QFile f(file);
    f.open(QIODevice::ReadOnly);
    QTextStream in(&f);
    const QString &contents(in.readAll());
    f.close();
    return contents;
}




void Fonctions::filePutContents(const QString &file, const QString &contents) const
{
    QFile f(file);
    f.open(QIODevice::WriteOnly);
    QTextStream out(&f);
    out << contents;
    f.close();

}



QString Fonctions::base64Encode(const QString &string) const
{
    QByteArray ba;
    ba.append(string);
    return ba.toBase64().replace("=", "");
}



QString Fonctions::base64Decode(const QString &string) const
{
    const QByteArray &text(QByteArray::fromBase64(string.toLocal8Bit()));

    return text.data();
}





QString Fonctions::wordWrap(const QString &content, const int &width) const
{

    QString out;

    int chars = 0;
    for(int i = 0; i < content.length(); i++)
    {
        chars++;

        if(content[i] == '\n') // new line
        {
            out.append(content[i]);
            chars = 0;
            continue;
        }

        if(chars > width)
        {
            out.append("\r\n");
            chars = 1;
        }

        out.append(content[i]);
    }

    return out;
}





bool Fonctions::antiHammering(const QString &server, const QString &ip, const bool &success)
{


    const qint64 &currentTime(timeStampSecs());


    QSettings settings(cfg->_fileAntiHammering, QSettings::IniFormat);

    foreach(const QString &grp, settings.childGroups())
    {
        settings.beginGroup(grp);

        int i(0);
        const qint64 &smtp(settings.value("Smtp").toString().toLongLong());
        const qint64 &pop3(settings.value("Pop3").toString().toLongLong());
        const qint64 &imap(settings.value("Imap").toString().toLongLong());

        if((smtp + 60) < currentTime)
        {
            settings.remove("Smtp");
            i++;
        }

        if((pop3 + 60) < currentTime)
        {
            settings.remove("Pop3");
            i++;
        }

        if((imap + 60) < currentTime)
        {
            settings.remove("Imap");
            i++;
        }

        if(i >= 3)
        {
            settings.remove("");
        }

        settings.endGroup();
    }


    bool blocage(false);

    const bool &serverAntiHammering(iniReturnValue(cfg->_fileConfig, "configuration" + server, "antiHammering").toInt() > 0);
    if(serverAntiHammering)
    {
        settings.beginGroup(ip);

        const qint64 &myServer(settings.value(server).toString().toLongLong());
        const int &nbEssais(settings.value(server + "/nbEssais").toString().toInt());

        // int / 2 (ex : nbEssais >= 10 donne 5 essais, >= 14 donne 7 essais).
        // En effet lors de l'appel des fonctions d'identifiation
        // (authLogin, authCramMd5...) cette fonction est initialisée 2
        // fois (une fois pour controle, et une fois en cas d'echec)
        if(nbEssais >= 10)
        {
            blocage = true;
        }
        else if(success)
        {
            settings.remove(server);
        }
        else
        {
            settings.setValue(server, QString::number(myServer > 0 ?
                                                          myServer : currentTime));
            settings.setValue(server + "/nbEssais", QString::number(nbEssais + 1));
        }

        settings.endGroup();
    }

    return blocage;









}



QStringList Fonctions::isPermittedIp(const QString &ip, const QString &serveur)
{

    QString authentification("1");
    QString closeConnection("1");

    QSettings settings(cfg->_fileConfig, QSettings::IniFormat);
    settings.beginGroup("configurationIps");
    const QStringList &listKeys(settings.childKeys());

    /*    // Aucune entrée (pas de restriction IP)
if(listKeys.count() < 1)
{
    closeConnection = false;
}
else
{
*/

    foreach(const QString &key, listKeys)
    {
        const int &etat(settings.value(key).toString().toInt());
        const QString &minIp(settings.value(key + "/minIp").toString().trimmed());
        const QString &maxIp(settings.value(key + "/maxIp").toString().trimmed());
        const int &authSmtp(settings.value(key + "/authSmtp").toString().toInt());
        const QString &serveurs(settings.value(key + "/serveurs").toString().trimmed());

        if(etat < 1)
        {
            continue;
        }

        // 0 : pas d'identification, 1 : identification requise
        if(isIpInRange(ip, minIp, maxIp))
        {

            if(serveurs.contains(serveur, Qt::CaseInsensitive))
            {
                authentification = authSmtp < 1 ? "0" : "1";
                closeConnection = "0";

                if(authentification == "1")
                {
                    break;
                }

            }


            // break;
        }
    }

    settings.endGroup();

    return QStringList() << authentification << closeConnection;

}

//! ---------------------------------------------------------------------




bool Fonctions::isValidIpRange(const QString &minIp, const QString &maxIp)
{
    quint64 rangeMin(QHostAddress(minIp).toIPv4Address());
    quint64 rangeMax(QHostAddress(maxIp).toIPv4Address());

    return(rangeMin <= rangeMax && verifIp(minIp) && verifIp(maxIp));
}



bool Fonctions::isIpInRange(const QString &ip, const QString &minIp, const QString &maxIp)
{
    quint64 addr(QHostAddress(ip).toIPv4Address());
    quint64 rangeMin(QHostAddress(minIp).toIPv4Address());
    quint64 rangeMax(QHostAddress(maxIp).toIPv4Address());
    return(addr >= rangeMin && addr <= rangeMax && isValidIpRange(minIp, maxIp));
}







int Fonctions::dateswap(QString form, uint unixtime)
{
    QDateTime fromunix;
    fromunix.setTime_t(unixtime);
    QString numeric = fromunix.toString((const QString)form);
    bool ok;
    return (int)numeric.toFloat(&ok);
}








QString Fonctions::timeStampMail(uint unixtime)
{
    /* mail rtf Date format! http://www.faqs.org/rfcs/rfc788.html */
    if(unixtime == 0)
        unixtime = (uint)time( NULL );


    QDateTime fromunix;
    fromunix.setTime_t(unixtime);
    QStringList RTFdays = QStringList() << "giorno_NULL" << "Mon" << "Tue" << "Wed" << "Thu" << "Fri" << "Sat" << "Sun";
    QStringList RTFmonth = QStringList() << "mese_NULL" << "Jan" << "Feb" << "Mar" << "Apr" << "May" << "Jun" << "Jul" << "Aug" << "Sep" << "Oct" << "Nov" << "Dec";
    QDate timeroad(dateswap("yyyy",unixtime),dateswap("M",unixtime),dateswap("d",unixtime));
    QStringList rtfd_line;
    rtfd_line.clear();
    // rtfd_line.append("Date: ");
    rtfd_line.append(RTFdays.at(timeroad.dayOfWeek()));
    rtfd_line.append(", ");
    rtfd_line.append(QString::number(dateswap("d",unixtime)));
    rtfd_line.append(" ");
    rtfd_line.append(RTFmonth.at(dateswap("M",unixtime)));
    rtfd_line.append(" ");
    rtfd_line.append(QString::number(dateswap("yyyy",unixtime)));
    rtfd_line.append(" ");
    rtfd_line.append(fromunix.toString("hh:mm:ss"));
    rtfd_line.append(" +0200");

    return QString(rtfd_line.join(""));
}





void Fonctions::updMsgInQueue(const QString &groupe, const QString &key, const QString &error, const bool &stop) const
{
    int nombreEnvoies(iniReturnValue(cfg->_fileConfig, "configurationDelivreurExterne", "nombreEnvoies").toInt());
    int dureeEntreEnvoies(iniReturnValue(cfg->_fileConfig, "configurationDelivreurExterne", "dureeEntreEnvoies").toInt());
    nombreEnvoies = (nombreEnvoies > 0 && nombreEnvoies <= 5) ? nombreEnvoies : 3;
    dureeEntreEnvoies = (dureeEntreEnvoies > 0 && dureeEntreEnvoies <= 24) ? dureeEntreEnvoies : 3;

    QSettings settings(cfg->_fileQueue, QSettings::IniFormat);
    settings.beginGroup(groupe);
    const int &nbTest(settings.value(key + "/nbTest").toString().toInt());
    const qint64 &lastTest(settings.value(key + "/lastTest").toString().toLongLong());

    if(nombreEnvoies == 1 || nbTest >= nombreEnvoies || stop)
    {
        settings.setValue(key, "1");
    }
    else
    {
        if((lastTest + (dureeEntreEnvoies * 3600)) <= timeStampSecs())
        {
            settings.setValue(key+ "/nbTest", QString::number(nbTest + 1));
            settings.setValue(key+ "/lastTest", QString::number(timeStampSecs()));
        }
    }
    settings.setValue(key + "/error", error);
}






//! ////////////////////////////////////////////////////////////////////////
// Calcule le quota d'un sous-dossier et le nombre des mails qu'il contient

QList<qint64> Fonctions::quotaGet(QString const &folder)
{

    QList<qint64> returnList;

    listeNombreMails.clear();
    listePoids.clear();

    calculerQuota(folder);

    qint64 globalSize(0);

    foreach(const QString &size, listePoids)
    {

        globalSize += size.toLongLong();
    }

    returnList << listeNombreMails.count() << globalSize;

    return returnList;
}




void Fonctions::calculerQuota(QString const &folder)
{

    QDir dir(folder);
    dir.setFilter(QDir::NoDotAndDotDot | QDir::AllEntries | QDir::System | QDir::Hidden);

    foreach(QFileInfo entry, dir.entryInfoList())
    {

        if(entry.isDir())
        {
            calculerQuota(entry.absoluteFilePath());
        }

        else if(entry.isFile() && entry.suffix().toLower() == "eml")
        {
            listeNombreMails << "1";
            listePoids << QString::number(entry.size());
        }
    }

}



//! ////////////////////////////////////////////////////////////////////////
// Stats Domaine

QStringList Fonctions::statsDomaine(const QString &domaine)
{
    qint64 size(0), nbMails(0), nbAlias(0), nbListes(0), nbInscrits(0), nbComptes(0);

    const QString &mailsFile(cfg->_fileMails.arg(domaine));
    QSettings settings(mailsFile, QSettings::IniFormat);

    foreach(const QString &user, settings.childGroups())
    {
        QStringList listStats(statsCompte(user, domaine));
        size += listStats.at(0).toLongLong();
        nbMails += listStats.at(1).toLongLong();
        nbAlias += listStats.at(2).toLongLong();
        nbListes += listStats.at(3).toLongLong();
        nbInscrits += listStats.at(4).toLongLong();
        nbComptes++;
    }

    QStringList listReturn;

    listReturn
            << QString::number(size) // Quota
            << QString::number(nbMails) // Nombre de mails (messages)
            << QString::number(nbAlias)
            << QString::number(nbListes)
            << QString::number(nbInscrits)
            << QString::number(nbComptes);

    return listReturn;
}



//! ////////////////////////////////////////////////////////////////////////
// Stats Compte

QStringList Fonctions::statsCompte(const QString &user, const QString &domaine)
{

    QString idCompte;
    qint64 size(0), nbMails(0), nbAlias(0), nbListes(0), nbInscrits(0);

    const QString &mailsFile(cfg->_fileMails.arg(domaine));
    QSettings mSettings(mailsFile, QSettings::IniFormat);

    const QString &aliasFile(cfg->_fileAlias.arg(domaine));
    QSettings aSettings(aliasFile, QSettings::IniFormat);

    const QString &listesFile(cfg->_fileListes.arg(domaine));
    QSettings lSettings(listesFile, QSettings::IniFormat);

    const QString &inscritsFile(cfg->_fileMailsListes.arg(domaine).arg(user));
    QSettings iSettings(inscritsFile, QSettings::IniFormat);


    QStringList listAlias(aSettings.childGroups());
    QStringList listListes(lSettings.childGroups());

    // Id du compte
    mSettings.beginGroup(user);
    const QString &id(mSettings.value("id").toString().trimmed());
    mSettings.endGroup();


    // Alias
    foreach(const QString &alias, listAlias)
    {
        aSettings.beginGroup(alias);
        idCompte = aSettings.value("idCompte").toString().trimmed();
        aSettings.endGroup();

        if(id == idCompte)
        {
            nbAlias += 1;
        }
    }

    // Listes
    foreach(const QString &liste, listListes)
    {
        lSettings.beginGroup(liste);
        idCompte = lSettings.value("idCompte").toString().trimmed();
        lSettings.endGroup();

        if(id == idCompte)
        {
            nbListes += 1;
        }
    }

    // Inscrits aux listes
    nbInscrits = iSettings.allKeys().count();


    listeNombreMails.clear();
    listePoids.clear();

    QString mailDir(cfg->_mailDir.arg(domaine).arg(user));
    calculerQuota(mailDir);

    nbMails = listeNombreMails.count();

    foreach(const QString &strSize, listePoids)
    {
        size += strSize.toLongLong();
    }


    QStringList listReturn;

    listReturn
            << QString::number(size) // Quota
            <<  QString::number(nbMails) // Nombre de mails (messages)
             << QString::number(nbAlias)
             << QString::number(nbListes)
             << QString::number(nbInscrits);

    return listReturn;
}











/**
Verifier si le compte, locale, peut recevoir un courrier (quota domaine et compte)
    1 OK



    -8 Domaine désactivé
    -9 Domaine expiré

    -10 Compte désactivé
    -11 Compte expiré

    -1 Domaine a dépassé le nombre de mail permis
    -2 Domaine a dépassé le Quota alloué

    -3 Compte a dépassé le nombre de mail permis
    -4 Compte a dépassé le quota qui lui est alloué

    -5 Compte a dépassé le quota générale alloué (restriction par domaine)

    -6 Poid du mail dépasse la taille fixée de manière générale (restriction par domaine)
    -7 Poid du mail dépasse la taille maximale fixée

*/












int Fonctions::mailDelivrableSiCompteLocale(QString const &user, QString const &domaine, int const &size)
{

    if(size < 1)
    {
        return 1;
    }

    // Si le domaine est locale (géré par aMailServer)
    if(domaineExists(domaine))
    {

        QString iniFile(cfg->_fileDomaines);


        // Etat
        const int &etat(iniReturnValue(iniFile, domaine, "etat").toInt());
        // Domaine désactivé
        if(etat < 1)
        {
            return -8;
        }

        // Domaine expiré
        if(domaineExpired(domaine))
        {
            return -9;
        }



        //! Stats Domaine
        QStringList listStatsDomaine(statsDomaine(domaine));
        const qint64 &quotaActuelDomaine(listStatsDomaine.at(0).toLongLong());
        const qint64 &nbMailActuelDomaine(listStatsDomaine.at(1).toLongLong());


        // Nb mails
        const int &nbMailDomaine(iniReturnValue(iniFile, domaine, "nombreDeMailPermis").toInt());
        if(nbMailActuelDomaine >= nbMailDomaine && nbMailDomaine > 0)
        {
            return -1;
        }



        // Quota
        const qint64 &quotaDomaine(iniReturnValue(iniFile, domaine, "quota").toLongLong());

        if((quotaActuelDomaine + size) >= quotaDomaine && quotaDomaine > 0)
        {
            return -2;
        }


        // ]]]



        // Si le compte est locale (géré par aMailServer) [[[
        if(mailExists(user, domaine))
        {
            iniFile = cfg->_fileMails.arg(domaine);

            // Etat
            const int &etat(iniReturnValue(iniFile, user, "etat").toInt());

            // Compte désactivé
            if(etat < 1)
            {
                return -10;
            }

            // Compte expiré
            if(accountExpired(user, domaine))
            {
                return -11;
            }



            //! Stats Compte
            QStringList listStatsCompte(statsCompte(user, domaine));
            const qint64 &quotaActuelCompte(listStatsCompte.at(0).toLongLong());
            const qint64 &nbMailActuelCompte(listStatsCompte.at(1).toLongLong());




            // Nb mails
            int nbMailCompte(iniReturnValue(iniFile, user, "nombreDeMailPermis").toInt());
            if(nbMailActuelCompte >= nbMailCompte && nbMailCompte > 0)
            {
                return -3;
            }

            // Quota
            const qint64 &quotaCompte(iniReturnValue(iniFile, user, "quota").toLongLong());

            // Compte a dépassé le quota qui lui est alloué
            if((quotaActuelCompte + size) >= quotaCompte && quotaCompte > 0)
            {
                return -4;
            }

            // Compte a dépassé le quota générale alloué (restriction par domaine)
            const qint64 &quotaParCompte(iniReturnValue(iniFile, domaine, "quotaParCompte").toLongLong());
            if((quotaActuelCompte + size) >= quotaParCompte && quotaParCompte > 0)
            {
                return -5;
            }

            // Taille maximale des messages (restriction par domaine)
            const qint64 &tailleMaximaleDesMessagesDomaine(iniReturnValue(iniFile, domaine, "tailleMaximaleDesMessagesDomaine").toLongLong());
            if(size >= tailleMaximaleDesMessagesDomaine && tailleMaximaleDesMessagesDomaine > 0)
            {
                return -6;
            }

            // Taille maximale des messages (restriction par domaine)
            const qint64 &tailleMaximaleDesMessagesCompte(iniReturnValue(iniFile, user, "tailleMaximaleDesMessages").toLongLong());
            // Poid du mail dépasse la taille maximale fixée
            if(size >= tailleMaximaleDesMessagesCompte && tailleMaximaleDesMessagesCompte > 0)
            {
                return -7;
            }

        }
        // ]]]

    }

    return 1;
}





//! ////////////////////////////////////////////////////////////////////////
// Liste BLANCHE

bool Fonctions::dansListBlanche(const QString &user, const QString &domaine, const QStringList &listeAVerifier)
{

    // Domaine
    QStringList listeBlancheDomaine(detectFiltre("listeBlanche", domaine));

    foreach(const QString &filtre, listeBlancheDomaine)
    {
        foreach(const QString &valeurAFiltrer, listeAVerifier)
        {
            if(! valeurAFiltrer.isEmpty() && joker(valeurAFiltrer, filtre))
            {
                return true;
            }
        }
    }


    // Compte
    QStringList listeBlancheCompte(detectFiltre("listeBlanche", user + "@" + domaine));

    foreach(const QString &filtre, listeBlancheCompte)
    {
        foreach(const QString &valeurAFiltrer, listeAVerifier)
        {
            if(! valeurAFiltrer.isEmpty() && joker(valeurAFiltrer, filtre))
            {
                return true;
            }
        }
    }

    return false;
}





QStringList Fonctions::detectFiltre(const QString &typeListe, const QString &de)
{
    QString user, domaine, iniFile, iniFileFiltres;
    QStringList returnList;
    int listeOui(0);
    QStringList userDomain(de.split("@"));

    // Compte
    if(userDomain.count() > 1)
    {
        user = userDomain.at(0).trimmed();
        domaine = userDomain.at(1).trimmed();
        iniFile = cfg->_fileMails.arg(domaine);
        iniFileFiltres = cfg->_fileMailsFiltres.arg(domaine).arg(user);

        // Permission de liste NOIRE/BLANCHE pour le compte
        listeOui = iniReturnValue(iniFile, user, typeListe).toInt();
        if(listeOui < 1)
        {
            return returnList;
        }

    }

    // Domaine
    else
    {
        domaine = userDomain.at(0).trimmed();
        iniFile = cfg->_fileDomaines;
        iniFileFiltres = cfg->_fileFiltres.arg(domaine);

        // Permission de liste NOIRE/BLANCHE pour le domaine
        listeOui = iniReturnValue(iniFile, domaine, typeListe).toInt();
        if(listeOui < 1)
        {
            return returnList;
        }
    }


    QSettings settings(iniFileFiltres, QSettings::IniFormat);
    settings.beginGroup(typeListe);
    int etat(settings.value("etat").toString().toInt());

    // Liste désactivée
    if(etat < 1)
    {
        return returnList;
    }

    foreach(QString const &key, settings.allKeys())
    {
        if(key.toLower() == "etat" || key.toLower() == "action") continue;
        returnList << settings.value(key).toString().trimmed();
    }

    settings.endGroup();
    returnList.removeDuplicates();

    return returnList;
}







QList<int> Fonctions::domaineListeGrise(const QString &domaine)
{
    QList<int> listReturn;
    QSettings settings(cfg->_fileDomaines, QSettings::IniFormat);
    settings.beginGroup(domaine);
    int listeGrise(settings.value("listeGrise").toString().toInt());
    int intervalleRenvoie(settings.value("intervalleRenvoie").toString().toInt());
    int validiteEntrees(settings.value("validiteEntrees").toString().toInt());
    int validiteRegles(settings.value("validiteRegles").toString().toInt());
    settings.endGroup();

    listeGrise = listeGrise >= 0 && listeGrise <= 2 ? listeGrise : 0;
    intervalleRenvoie = (intervalleRenvoie > 0 && intervalleRenvoie <= 60) ? intervalleRenvoie : 5; // 5 mn
    validiteEntrees = (validiteEntrees > 0 && validiteEntrees <= 24) ? validiteEntrees : 6; // 6H
    validiteRegles = (validiteRegles > 0 && validiteRegles <= 365) ? validiteRegles : 30; // 30 jours

    listReturn << listeGrise
               << intervalleRenvoie
               << validiteEntrees
               << validiteRegles;

    return listReturn;
}

QList<int> Fonctions::compteListeGrise(const QString &user, const QString &domaine)
{
    QList<int> listReturn;

    QSettings settings(cfg->_fileMails.arg(domaine), QSettings::IniFormat);
    settings.beginGroup(user);

    int etatListeGrise(settings.value("listeGrise").toString().toInt());
    int intervalleRenvoie(settings.value("intervalleRenvoie").toString().toInt());
    int validiteEntrees(settings.value("validiteEntrees").toString().toInt());
    int validiteRegles(settings.value("validiteRegles").toString().toInt());
    settings.endGroup();

    etatListeGrise = etatListeGrise > 0 ? 1 : 0;
    intervalleRenvoie = (intervalleRenvoie > 0 && intervalleRenvoie <= 60) ? intervalleRenvoie : 5; // 5 mn
    validiteEntrees = (validiteEntrees > 0 && validiteEntrees <= 24) ? validiteEntrees : 6; // 6H
    validiteRegles = (validiteRegles > 0 && validiteRegles <= 365) ? validiteRegles : 30; // 30 jours

    listReturn << etatListeGrise
               << intervalleRenvoie
               << validiteEntrees
               << validiteRegles;

    return listReturn;
}










QString Fonctions::preparerErreur(const QString &msgId, const QString &newMsgId, QString error)
{
    QSettings settings(cfg->_fileQueue, QSettings::IniFormat);

    settings.beginGroup(msgId);
    const QString &from(settings.value("from").toString());
    const QString &subject(settings.value("subject").toString());
    const QString &date(settings.value("date").toString());
    settings.endGroup();

    QString fileMsg(cfg->_queueDir + msgId + ".eml");
    QFile fMsg(fileMsg);
    fMsg.open(QIODevice::ReadOnly);
    QTextStream inMsg(&fMsg);
    QString msgContents(inMsg.readAll());
    fMsg.close();

    // Préparation du message [[[

    QString contents("Return-Path: <>\r\n"
                     "Reply-To: <>\r\n"
                     "Message-ID: <" + newMsgId + "@" + cfg->defaultDomain + ">\r\n"
                                                                             "Date: " + timeStampMail() + "\r\n"
                                                                                                          "From: \"aMailServer\" <mailer-daemon@" + cfg->defaultDomain + ">\r\n"
                                                                                                                                                                         "To: " + from + "\r\n"
                                                                                                                                                                                         "Subject: Undeliverable " + (subject.isEmpty() ? "mail returned to sender" : subject) + "\r\n"
                     );

    QFile f(cfg->_fileErrorMsg);
    f.open(QIODevice::ReadOnly);
    QTextStream in(&f);
    QString fileContents(in.readAll().trimmed());

    if(fileContents.isEmpty())
    {
        return "";
    }

    contents += fileContents;
    QRegExp rx;
    rx.setCaseSensitivity(Qt::CaseInsensitive);

    rx.setPattern("#DEFAULT_DOMAINE#");
    contents.replace(rx, cfg->defaultDomain);

    rx.setPattern("#DATE#");
    contents.replace(rx, date);

    rx.setPattern("#ERROR_TXT#");
    contents.replace(rx, error + "\r\n--------------------\r\naMailServer\r\n");

    rx.setPattern("#ERROR_HTML#");
    error.replace("\t", "&emsp; ");
    error.replace("<", "&lt;");

    contents.replace(rx, error.replace("\r\n", "<br />") + "<br />"
                                                           "<font color=\"#222222\"><i>--------------------<br />"
                                                           "aMailServer</i></font><br />"
                     );

    rx.setPattern("#ID_MAIL#");
    contents.replace(rx, msgId);

    rx.setPattern("#MAIL_A_ATTACHER#");
    contents.replace(rx, msgContents);

    // ]]]

    return addHeader(aMailServerIpAddress(), from, msgId, "", contents) + contents;


    return "";
}




QString Fonctions::currentTxtDateTime() const
{
    return QDateTime::currentDateTime().toString("dd-MM-yyyy hh:mm:ss.zzz");
}


qint64 Fonctions::timeStampMSecs() const
{
    return QDateTime::currentDateTime().currentMSecsSinceEpoch();
}

qint64 Fonctions::timeStampSecs() const
{
    return(QDateTime::currentDateTime().currentMSecsSinceEpoch() / 1000);
}





bool Fonctions::manipLog(QString const &log) const
{

    QString logDir(cfg->_logsDir.arg(log));
    QDir dir;

    if(! dir.exists(logDir) && ! dir.mkpath(logDir))
    {
        return false;
    }

    bool supprimerAncien(true);
    QString path(logDir  + QDateTime::currentDateTime().toString("dd-MM-yyyy"));
    QString file(path + ".log");
    QFile f(file);

    // Taille des logs atteint {{{
    if(f.size() >= cfg->tailleLogs)
    {

        // Supprimer
        if(cfg->actionLogs < 1)
        {
            if(! f.remove())
            {
                return false;
            }
        }

        // Sauvegarder
        else
        {

            for(int i = 0; i <= 10; i++)
            {
                QString newFile(path + "-" + QString::number(i) + ".log");

                if(! QFile::exists(newFile))
                {
                    if(! f.rename(newFile))
                    {
                        return false;
                    }

                    supprimerAncien = false;

                    break;
                }
            }

            if(supprimerAncien && ! f.remove())
            {
                return false;
            }
        }
    }

    return true;

}
// }}}



/////////////////////////////////////////////////////////
// Equivalent de Contains mais en liste {{{

bool Fonctions::listContains(const QStringList &listOut, const QStringList &listIn, const bool &sensitivity) const
{
    foreach(const QString &str, listOut)
    {
        if(listIn.contains(str, (sensitivity ? Qt::CaseSensitive : Qt::CaseInsensitive)))
        {
            return true;
        }
    }
    return false;
}

// }}}






/////////////////////////////////////////////////////////
// Stopper ts les serveurs {{{

void Fonctions::stopAllServer() const
{
    pid("smtp", "0");
    pid("pop3", "0");
    pid("imap", "0");
    pid("delivrerLocale", "0");
    pid("delivrerExterne", "0");
}

// }}}



/////////////////////////////////////////////////////////
// Création des pid serveurs {{{

void Fonctions::pid(const QString &server, const QString &etat) const
{

    QString dir(cfg->_pidDir);
    QString pid(dir + server + ".pid");
    QDir d;
    if(! d.exists(dir))
    {
        d.mkpath(dir);
    }

    QFile f(pid);
    f.open(QIODevice::WriteOnly);
    QTextStream out(&f);
    out << etat;
    f.close();

}

// }}}



/////////////////////////////////////////////////////////
// Etat des serveurs {{{

// 0 stop; 1 start, 2 restart

int Fonctions::etatServeur(const QString &server) const
{

    QString pid(cfg->_pidDir + server + ".pid");
    QFile f(pid);
    f.open(QIODevice::ReadOnly);
    QTextStream in(&f);
    int _return(in.readAll().toInt());
    f.close();
    return _return;
}

// }}}





/////////////////////////////////////////////////////////
// Création du sous-dossier et du fichier log {{{

void Fonctions::creatLog(const QString &log) const
{

    QDir dir;
    QString logDir(cfg->_logsDir.arg(log.toUpper()));
    if(! dir.exists(logDir) && ! dir.mkpath(logDir)) return;
    QFile f(logDir  + QDateTime::currentDateTime().toString("dd-MM-yyyy") + ".log");
    f.open(QIODevice::WriteOnly | QIODevice::Append);
    f.close();
}

// }}



/////////////////////////////////////////////////////////
// Enregistrement de quelques logs {{{

void Fonctions::log(const QString &resultat, const int &descripteur) const
{

    const QString &logType("TCP");

    const int &siLog(iniReturnValue(cfg->_fileConfig, "configurationLogs", "logTcp").toInt());
    if(siLog < 1 || ! manipLog(logType))
    {
        return;
    }

    QString txtLog("\"%1\"\t\"%2\"\t\"%3\"\t\"%4\"\t\"RECEIVED: %5\"\r\n");
    const QString &descri(descripteur > 0 ? QString::number(descripteur) : "-");

    txtLog = txtLog.arg(logType).arg(descri).arg(currentTxtDateTime()).arg(aMailServerIpAddress()).arg(resultat);
    const QString &logDir(cfg->_logsDir.arg(logType));
    QFile f(logDir  + QDateTime::currentDateTime().toString("dd-MM-yyyy") + ".log");
    f.open(QIODevice::WriteOnly | QIODevice::Append);
    QTextStream w(&f);
    w << txtLog.trimmed() + "\r\n";
    f.close();
    //   qDebug() << resultat;
}





/////////////////////////////////////////////////////////
// CRAM-MD5 {{{
QByteArray Fonctions::xorArray(const QByteArray input, char c)
{
    QByteArray result;
    for (int i = 0; i < input.size(); ++i) {
        result += (input[i] ^ c);
    }
    return result;
}

QByteArray Fonctions::cramMd5Response(const QByteArray &nonce, const QByteArray &user, const QByteArray &pass)
{
    char opad(0x5c);
    char ipad(0x36);
    QByteArray result = user + " ";
    QCryptographicHash hash(QCryptographicHash::Md5);
    QCryptographicHash hash1(QCryptographicHash::Md5);
    QCryptographicHash hash2(QCryptographicHash::Md5);
    QByteArray passwordPad(pass);

    if (passwordPad.size() > 64)
    {
        hash.addData(passwordPad);
        passwordPad = hash.result();
    }

    while(passwordPad.size() < 64)
    {
        passwordPad.append(char(0));
    }
    hash1.addData(xorArray(passwordPad, ipad));
    hash1.addData(nonce);
    hash2.addData(xorArray(passwordPad, opad));
    hash2.addData(hash1.result());
    result.append(hash2.result().toHex());

    return result;
}
// }}}



bool Fonctions::joker(const QString &contents, QString regex) const
{
    regex.replace("*", ".*");
    regex.replace("..*", ".*");

    QRegExp rx(regex, Qt::CaseInsensitive);
    rx.setMinimal(true);
    return rx.indexIn(contents) > -1 ? true : false;

}




QStringList Fonctions::detectUserDomaine(QString value)
{
    QStringList returnList(QStringList() << "" << "");

    QStringList listUserDomaine(value.trimmed().toLower().split("@"));

    if(listUserDomaine.count() != 2)
    {
        return returnList;
    }

    returnList.clear();
    returnList << listUserDomaine.at(0) << listUserDomaine.at(1);

    return returnList;
}





QStringList Fonctions::replyToError(const QString &replyTo, const QString &returnPath, const QString &from)
{
    QString replyToMail, replyToType, domaine;
    QStringList returnList, listIps;

    QStringList userDomaine;

    userDomaine = detectUserDomaine(replyTo);
    domaine = userDomaine.at(1);

    listIps = domaineIps(domaine);
    if(listIps.count() > 0)
    {
        replyToMail = replyTo;
        replyToType = listContains(listIps, aMailServerIpAddresses()) ? "locale" : "externe";
        returnList << replyToMail << replyToType;
        return returnList;
    }

    if(! returnPath.isEmpty())
    {
        userDomaine = detectUserDomaine(returnPath);
        domaine = userDomaine.at(1);

        listIps = domaineIps(domaine);
        if(listIps.count() > 0)
        {
            replyToMail = returnPath;
            replyToType = listContains(listIps, aMailServerIpAddresses()) ? "locale" : "externe";
            returnList << replyToMail << replyToType;
            return returnList;
        }
    }


    if(! from.isEmpty())
    {
        userDomaine = detectUserDomaine(from);
        domaine = userDomaine.at(1);

        listIps = domaineIps(domaine);
        if(listIps.count() > 0)
        {
            replyToMail = from;
            replyToType = listContains(listIps, aMailServerIpAddresses()) ? "locale" : "externe";
            returnList << replyToMail << replyToType;
            return returnList;
        }
    }

    returnList << "" << "";
    return returnList;
}




void Fonctions::addMsgToQueue(const QString &contents, const QStringList &params, const QStringList &rcptTo)
{

    if(params.count() < 8 || rcptTo.count() < 1)
    {
        return;
    }

    QDir dir(cfg->_queueDir);

    if(! dir.exists())
    {
        dir.mkpath(cfg->_queueDir);
    }

    const QString &msgId(params.at(0));
    const QString &from(params.at(1));
    const QString &sender(params.at(2));
    QString subject(params.at(3));
    subject.replace(QRegExp("\r|\n"), "");
    const QString &hostConnectedIp(params.at(4));
    const QString &replyToError(params.at(5));
    const QString &replyToType(params.at(6));
    const QString &returnToSender(params.at(7));

    QFile f(cfg->_queueDir + msgId + ".eml");
    f.open(QIODevice::WriteOnly);
    QTextStream w(&f);
    w << contents;
    f.close();


    // Enregistrement du message
    QSettings settings(cfg->_fileQueue, QSettings::IniFormat);
    settings.beginGroup(msgId);
    settings.setValue("from", from);
    settings.setValue("sender", sender);
    settings.setValue("subject", subject);
    settings.setValue("date", timeStampMail());
    settings.setValue("hostConnectedIp", hostConnectedIp);
    settings.setValue("replyToError", replyToError);
    settings.setValue("replyToType", replyToType);
    settings.setValue("createTime", QString::number(timeStampSecs()));

    // Utilisé pour différencier les nouveaux mails des erreur (udelivrable mail)
    settings.setValue("returnToSender", returnToSender);

    int nb(0);
    foreach(const QString &to, rcptTo)
    {
        if(to.isEmpty())
        {
            continue;
        }

        const QStringList &userDomaine(detectUserDomaine(to));
        const QString &domaineTo(userDomaine.at(1));
        const QStringList &listIps(domaineIps(domaineTo));

        const QString &toType(listContains(listIps, aMailServerIpAddresses()) ? "locale" : "externe");
        settings.setValue(to, "0");
        settings.setValue(to + "/type", toType);
        settings.setValue(to + "/nbTest", "0");
        settings.setValue(to + "/lastTest", "0");
        settings.setValue(to + "/error", "");
        settings.setValue(to + "/seen", "0");
        nb++;
    }
    settings.setValue("nbRecipient", QString::number(nb));

    settings.endGroup();
}







bool Fonctions::isValidMsgInQueue(const QString &msgId)
{
    bool etat(true);
    QSettings settings(cfg->_fileQueue, QSettings::IniFormat);
    settings.beginGroup(msgId);
    const int nbDestinataire(settings.childKeys().count() - 10);
    const QString &from(settings.value("from").toString());
    const QString &sender(settings.value("sender").toString());
    const QString &hostConnectedIp(settings.value("hostConnectedIp").toString());
    const QString &replyToError(settings.value("replyToError").toString());
    const QString &replyToType(settings.value("replyToType").toString());
    const QString &createTime(settings.value("createTime").toString());
    const QString &returnToSender(settings.value("returnToSender").toString());
    const int &nbRecipient(settings.value("nbRecipient").toString().toInt());

    if(
            ! verifMail(from) ||
            (! sender.isEmpty() && ! verifMail(sender)) ||
            hostConnectedIp.isEmpty() ||

            ! verifMail(replyToError) ||

            (replyToType != "locale" && replyToType != "externe") ||
            createTime.isEmpty() ||
            (returnToSender != "0" && returnToSender != "1") ||

            // Courrier introuvable !
            ! QFile::exists(cfg->_queueDir + msgId + ".eml")
            )
    {
        etat = false;
    }


    // Si le message a été créé de puis plus de 3 mn
    else if(((msgId.toLongLong() / 1000) + 180) < timeStampMSecs())
    {
        if(
                // Mal formaté (10 clés et au moins un destinataire)
                (settings.childKeys().count() < 11) ||

                // Ne contient pas ts les destinataires
                (nbDestinataire != nbRecipient)

                )
        {
            etat = false;
        }
    }

    settings.endGroup();
    return etat;
}






// Detecter les IPs d'une hote
QStringList Fonctions::domaineIps(const QString &domaine)
{
    QStringList returnList;

    QHostInfo host = QHostInfo::fromName(domaine);

    if(host.error() != QHostInfo::NoError)
    {
        // qDebug() << "Lookup failed:" << host.errorString();
        return returnList;
    }

    foreach(const QHostAddress &address, host.addresses())
    {
        returnList << address.toString();
    }

    return returnList;
}







int Fonctions::serverAccess(const QString &domaine, const QString &user, QString type)
{

    type.toUpper();

    QString serverType(type == "POP3" ? "permettreConnexionsPop3" : type == "IMAP" ? "permettreConnexionsImap" : "permettreConnexionsSmtp");



    QString dIniFile(cfg->_fileDomaines);
    QSettings dSettings(dIniFile, QSettings::IniFormat);
    dSettings.beginGroup(domaine);
    QString dAccess(dSettings.value(serverType).toString().trimmed());
    dSettings.endGroup();

    QString cIniFile(cfg->_fileMails.arg(domaine));
    QSettings cSettings(cIniFile, QSettings::IniFormat);
    cSettings.beginGroup(user);
    QString cAccess(cSettings.value(serverType).toString().trimmed());
    cSettings.endGroup();

    return(dAccess != "1" ? -1 : (cAccess != "1" ? 0 : 1));
}






/////////////////////////////////////////////////////////
// Permet de supprimer les doublons d'une liste (un tableau)

QStringList Fonctions::arrayUnique(const QStringList list, const bool caseSensitive)
{

    if(list.count() < 1) return list;
    QStringList newList;
    foreach(QString value, list)
    {
        if(! inArray(value, newList, caseSensitive))
            newList << value;
    }
    return newList;
}






/////////////////////////////////////////////////////////
// Vérifie si un élément existe dans une liste

bool Fonctions::inArray(QString nouvelleEntree, QStringList list, const bool caseSensitive)
{

    if(nouvelleEntree.isEmpty() || list.count() < 1) return false;

    foreach(QString value, list)
    {
        if(nouvelleEntree == value) return true;
        if(caseSensitive && (nouvelleEntree.trimmed().toLower() == value.trimmed().toLower())) return true;
    }

    return false;
}










bool Fonctions::verifContent(const QString &content, const QString &regex) const
{
    QRegExp rx;
    rx.setMinimal(true);
    rx.setPattern(regex);
    return rx.exactMatch(content);
}






QString Fonctions::chemain(QString value)
{
    value = value.trimmed();
    value.replace("\\", "/");
    value.replace(QRegExp("(/)+"), "/");

    return value;
}






//! ////////////////////////////////////////////////////////////////////////
// Recherche de la signature text/html du domaine [[[

QStringList Fonctions::listSignatureDomaine(QString const &domaine)
{

    QRegExp rx;
    rx.setMinimal(true);
    rx.setCaseSensitivity(Qt::CaseInsensitive);
    QString signatureHtml, signatureText;
    QStringList returnList;

    QFile file(cfg->_fileDomaineSignature.arg(domaine));
    if(file.exists())
    {
        file.open(QIODevice::ReadOnly);
        QTextStream in(&file);
        QString contents = in.readAll().trimmed();
        file.close();

        rx.setPattern("\\s*<\\s*signatureText\\s*>(.*)<\\s*/\\s*signatureText\\s*>\\s*");
        rx.indexIn(contents);
        signatureText = rx.cap(1).trimmed();

        rx.setPattern("\\s*<\\s*signatureHtml\\s*>(.*)<\\s*/\\s*signatureHtml\\s*>\\s*");
        rx.indexIn(contents);
        signatureHtml = rx.cap(1).trimmed();
        signatureHtml.replace(QRegExp("\r|\n"), "");



    }

    returnList << signatureText << signatureHtml;

    return returnList;
}







//! ////////////////////////////////////////////////////////////////////////
// Régénérer un message id

QString Fonctions::insererSignature(QString from, QString to, QString const &value)
{

    QString signatureTxt, signatureHtml, contentsMsg, contents, user, domaine;

    QString userTo, domaineTo;


    QString signatureDomaineTxt, signatureDomaineHtml, signatureCompteTxt, signatureCompteHtml;

    // Message [[[
    QString msgFile(value);
    QFile file(msgFile);
    if(file.exists())
    {
        file.open(QIODevice::ReadOnly);
        QTextStream in(&file);
        contentsMsg = in.readAll().trimmed();
        file.close();
    }
    else
    {
        contentsMsg = value;
    }

    // ]]]

    QStringList userDomainFrom(from.trimmed().toLower().split("@"));
    if(userDomainFrom.count() > 1) // symbole @ existe
    {
        QString userFrom = userDomainFrom.at(0);
        QString domaineFrom = userDomainFrom.at(1);
        user = userFrom;
        domaine = domaineFrom;

        // Expéditeur externe
        if(! mailExists(user, domaine))
        {

            return contentsMsg;
        }

    }
    else // Erreur
    {
        return contentsMsg;
    }


    QStringList userDomainTo(to.trimmed().toLower().split("@"));

    if(userDomainTo.count() > 1) // symbole @ existe
    {
        userTo = userDomainTo.at(0);
        domaineTo = userDomainTo.at(1);
    }
    else // Erreur
    {
        return contentsMsg;
    }



    QRegExp rx;
    rx.setMinimal(true);
    rx.setCaseSensitivity(Qt::CaseInsensitive);


    // Option signature (pour le domaine et donc tous ses comptes) [[[
    QSettings settingsDomaine(cfg->_fileDomaines, QSettings::IniFormat);
    settingsDomaine.beginGroup(domaine);
    int permettreSignature(settingsDomaine.value("permettreSignature").toString().toInt());
    int typeSignatureDomaine(settingsDomaine.value("typeSignatureDomaine").toString().toInt());
    int signatureDomaine(settingsDomaine.value("signatureDomaine").toString().toInt());
    settingsDomaine.endGroup();


    // Recherche de la signature text/html du domaine [[[
    if(signatureDomaine > 0)
    {
        QStringList listSignatures(listSignatureDomaine(domaine));
        signatureDomaineTxt = listSignatures.at(0);
        signatureDomaineHtml = listSignatures.at(1);

        // Pas de signature trouvé donc on la désactive pour le domaine
        if(signatureDomaineTxt.trimmed().isEmpty() || signatureDomaineHtml.trimmed().isEmpty())
        {
            signatureDomaineTxt = signatureDomaineHtml = "";
        }


        // ]]]


        /**
        1 : n'apposer la signature qu'aux mails sortants (mails vers domaines externes non gérés par aMailServer) ;
        2 : n'apposer la signature qu'aux mail locaux (domaines gérés par aMailServer) ;
        3 : apposer la signature sur tous les mails (entrants et sortants).
        */
        if(signatureDomaine == 1 && mailExists(userTo, domaineTo))
            signatureDomaineTxt = signatureDomaineHtml = "";

        else if(signatureDomaine == 2 && ! mailExists(userTo, domaineTo))
            signatureDomaineTxt = signatureDomaineHtml = "";
        // else option = 3 donc tous les mails

    }




    // Option signature pour le compte
    QSettings settingsCompte(cfg->_fileMails.arg(domaine), QSettings::IniFormat);
    settingsCompte.beginGroup(user);
    //QString idCompte(settingsCompte.value("id").toString().trimmed());
    int signatureCompte(settingsCompte.value("signature").toString().toInt());
    settingsCompte.endGroup();


    if(permettreSignature != 0)
    {

        // Recherche de la signature text/html [[[
        QFile fsc(cfg->_fileSignatureEtRepondeur.arg(domaine).arg(user));

        if(fsc.exists() && signatureCompte != 0)
        {
            fsc.open(QIODevice::ReadOnly);
            QTextStream inC(&fsc);
            contents = inC.readAll().trimmed();
            fsc.close();

            rx.setPattern("\\s*<\\s*signatureText\\s*>(.*)<\\s*/\\s*signatureText\\s*>\\s*");
            rx.indexIn(contents);
            signatureCompteTxt = rx.capturedTexts().at(1).trimmed();

            rx.setPattern("\\s*<\\s*signatureHtml\\s*>(.*)<\\s*/\\s*signatureHtml\\s*>\\s*");
            rx.indexIn(contents);
            signatureCompteHtml = rx.capturedTexts().at(1).trimmed();
        }
        // ]]]

        // Pas de signature trouvé donc on la désactive pour le domaine
        if(signatureCompteTxt.isEmpty() || signatureCompteHtml.isEmpty())
        {
            signatureCompteTxt = signatureCompteHtml = "";
            signatureCompte = 0;
        }

    }
    else
    {
        signatureCompte = 0;
    }




    /**
        0 pas de signature (signature du domaine désactivée) ;
        1 apposer la signature du domaine si le compte n'a pas spécifié de signature ;
        2 apposer la signature du domaine après la signature du compte ;
        3 ecraser la signature du compte et mettre celle du domaine).
        */

    if(typeSignatureDomaine == 1)
    {
        signatureTxt = signatureCompte < 1 ? signatureDomaineTxt : signatureCompteTxt;
        signatureHtml = signatureCompte < 1 ? signatureDomaineHtml : signatureCompteHtml;
    }

    else if(typeSignatureDomaine == 2)
    {
        signatureTxt = signatureCompteTxt + "\r\n\r\n" + signatureDomaineTxt;
        signatureHtml = signatureCompteHtml + "<br /><br />" + signatureDomaineHtml;
    }

    else if(typeSignatureDomaine == 3)
    {
        signatureTxt = signatureDomaineTxt;
        signatureHtml = signatureDomaineHtml;
    }

    else     // Erreur de configuration
    {
        signatureTxt = signatureHtml = "";
    }


    QString strCopy;

    rx.setPattern(QString::fromLatin1("Content\\-Type\\s*:(.*)boundary\\s*=\\s*(\"|')(.*)\\2\\s*"));
    QStringList list;
    int pos = 0;
    while((pos = rx.indexIn(contentsMsg, pos)) != -1)
    {
        list << rx.cap(3);
        pos += rx.matchedLength();
    }

    if(list.count() > 0)
    {
        QString boundary(list.at(list.count() - 1)); // Derniere boundary;
        contentsMsg.replace(QRegExp("(\\r\\n|\\r|\\n)"), "\\r\\n");
        QStringList listLine(contentsMsg.split("\\r\\n"));

        int i(1), j(0);
        foreach(QString line, listLine)
        {

            if(line.contains(boundary, Qt::CaseSensitive))
            {
                j++;

                // J = 1 :
                // Content-Type: multipart/alternative; boundary="--XXXXXXXX"       => ignorer
                // J = 2 :
                // This is a multi-part message in MIME format                      => ignorer
                //                --XXXXXXXX
                if(j == 3)
                    strCopy += "\r\n" + signatureTxt + "\r\n";
                if(j == 4)
                    strCopy += "\r\n<br />" + signatureHtml + "<br />\r\n";

            }

            strCopy += line + "\r\n" ;
            i++;
        }
    }
    else
    {

        strCopy = contentsMsg + "\r\n\r\n" + signatureTxt + "\r\n\r\n";

    }

    return strCopy.trimmed() + "\r\n";
}











//! ////////////////////////////////////////////////////////////////////////
// Régénérer un message id

QString Fonctions::regenererMessageId() const
{
    /*   QByteArray hash = QCryptographicHash::hash(QString(QString::number(qrand())).toUtf8(),
                                                       QCryptographicHash::Md5);
            return hash.toHex();

        */
    qint64 time(QDateTime::currentMSecsSinceEpoch());
    return QString::number(time);

}








//! ////////////////////////////////////////////////////////////////////////
// Detecter les adresses Ip de la machine hebergeant aMailServer

QStringList Fonctions::machineIpAddresses() const
{
    QStringList ipAddress;
    ipAddress << QHostAddress(QHostAddress::LocalHost).toString() << "127.0.0.1";
    QList<QHostAddress> ipAddressesList = QNetworkInterface::allAddresses();
    for (int i = 0; i < ipAddressesList.count(); i++)
    {
        if(ipAddressesList.at(i).toIPv4Address())
        {
            ipAddress << ipAddressesList.at(i).toString();
        }
    }

    ipAddress.removeDuplicates();

    return ipAddress;
}


//! ////////////////////////////////////////////////////////////////////////
// Detecter les adresses Ip sur lesquelles aMailServer ecoute

QStringList Fonctions::aMailServerIpAddresses() const
{
    return (cfg->smtpHost == "any" ? machineIpAddresses() : QStringList() << cfg->smtpHost);
}




//! ////////////////////////////////////////////////////////////////////////
// Detecter l'adresse Ip de la machine hebergeant aMailServer

QString Fonctions::aMailServerIpAddress() const
{

    if(cfg->smtpHost != "any")
    {
        return cfg->smtpHost;
    }
    else
    {
        QString ipAddress;
        QList<QHostAddress> ipAddressesList = QNetworkInterface::allAddresses();

        // Detection de la première non-localhost IPv4 addresse
        for(int i = 0; i < ipAddressesList.count(); i++)
        {
            if(ipAddressesList.at(i) != QHostAddress::LocalHost &&
                    ipAddressesList.at(i).toIPv4Address())
            {
                ipAddress = ipAddressesList.at(i).toString();
                break;
            }
        }

        // Aucune détéctée, donc IPv4 localhost
        if (ipAddress.isEmpty())
        {
            ipAddress = QHostAddress(QHostAddress::LocalHost).toString();
        }

        return (! ipAddress.isEmpty() ? ipAddress : "127.0.0.1");
    }

}











//! ////////////////////////////////////////////////////////////////////////
// Verification syntaxique des adresses mail

bool Fonctions::verifMail(QString mail)
{
    mail = mail.trimmed().toLower();

    if(mail.isEmpty()) return false;

    QString atom = "[-a-z0-9!#$%&\"*+\\\\/=?^_`{|}~]";
    QString domaine = "([a-z0-9]([-a-z0-9]*[a-z0-9]+)?)";
    QString regex = "^" + atom + "+(\\." + atom + "+)*@"
                                                  "(" + domaine + "{1,63}\\.)+"+ domaine + "{2,63}$";

    QRegExp rx(regex);
    return rx.exactMatch(mail);
}







//! ////////////////////////////////////////////////////////////////////////
// Verification syntaxique des adresses Ips

bool Fonctions::verifIp(QString ip, const bool &sensitivity)
{
    if(! sensitivity)
    {
        ip = ip.trimmed();
    }

    if(ip.trimmed().isEmpty())
    {
        return false;
    }

    QRegExp rx("^([\\d]{1,3})\\.([\\d]{1,3})\\.([\\d]{1,3})\\.([\\d]{1,3})$");
    rx.indexIn(ip);
    QString a(rx.capturedTexts().at(1)), b(rx.capturedTexts().at(2)),
            c(rx.capturedTexts().at(3)), d(rx.capturedTexts().at(4));
    if(
            a.isEmpty() || a .toInt() < 0 || a.toInt() > 255 ||
            b.isEmpty() || b .toInt() < 0 || b.toInt() > 255 ||
            c.isEmpty() || c .toInt() < 0 || c.toInt() > 255 ||
            d.isEmpty() || d .toInt() < 0 || d.toInt() > 255
            )
    {
        return false;
    }

    return true;
}





//! ////////////////////////////////////////////////////////////////////////
// Verification syntaxique des domaines

bool Fonctions::verifDomaine(QString domaine)
{
    QRegExp rx;
    rx.setMinimal(true);
    rx.setPattern("^[a-z0-9]+([\\-\\.]{1}[a-z0-9]+)*\\.[a-z]{2,6}$");
    return rx.exactMatch(domaine.toLower());
}





//! ////////////////////////////////////////////////////////////////////////
// Calculer le poids

QString Fonctions::stringNumber(const qint64 &number) const
{
    QString tmp;
    if (number > (1024 * 1024 * 1024))
        tmp.sprintf("%.2f GB", number / (1024.0 * 1024.0 * 1024.0));
    else if (number > (1024 * 1024))
        tmp.sprintf("%.2f MB", number / (1024.0 * 1024.0));
    else if (number > (1024))
        tmp.sprintf("%.2f KB", number / (1024.0));
    else
        tmp.sprintf("%d octets", int(number));
    return tmp;
}









//! ////////////////////////////////////////////////////////////////////////
// Créer les sous-dossiers et fichiers de base de aMailServer

void Fonctions::creatDataDirectory(const bool alert)
{

    QStringList listDir, listFile;

    listDir << cfg->_dataDir << cfg->_queueDir << cfg->_traitementDir
            << cfg->_helpDir << cfg->_pidDir;
    QDir d;

    foreach(const QString &dir, listDir)
    {

        if(! d.exists(dir) && ! d.mkpath(dir))
        {
            if(alert)
            {
                msgBoxHtml("Impossible de créer le sous-dossier " + dir +
                           "Veuillez le créer manuellement", "", 3);
            }

            exit(404);
        }
    }

    listFile
            // Queue
            << cfg->_fileQueue

               // Conf
            << cfg->_fileConfig

               // Anti-Attaque par force brute
            << cfg->_fileAntiHammering

               // Pids
            << cfg->_pidDir + "delivrerLocale.pid"
            << cfg->_pidDir + "delivrerExterne.pid"
            << cfg->_pidDir + "pop3.pid"
            << cfg->_pidDir + "imap.pid"
            << cfg->_pidDir + "smtp.pid";

    QFile f;
    foreach(const QString &file, listFile)
    {
        f.setFileName(file);
        if(! f.open(QIODevice::ReadWrite | QIODevice::Append))
        {
            if(alert)
            {
                msgBoxHtml("Impossible d'ouvrir le fichier <c:red>" + file +
                           "</c> en lecture/ecriture ! Veuillez lui appliquer un chmod <b>777</B>",
                           "", 3);
            }

            exit(404);
        }
        f.close();

    }


}



//! ////////////////////////////////////////////////////////////////////////
// Créer les sous-dossiers et fichiers de base pour les comptes

bool Fonctions::creatDirectory(const QString &dirToCreate, const int &uidvalidity) const
{

    QString mailFile(dirToCreate + "/mails.ini");
    QString globalFile(dirToCreate + "/globals.ini");
    QDir myDir;
    QFile fMails(mailFile);
    QFile fGlobals(globalFile);

    if(! myDir.mkpath(dirToCreate) || ! fMails.open(QIODevice::ReadWrite | QIODevice::Append) || ! fGlobals.open(QIODevice::ReadWrite | QIODevice::Append))
    {
        return false;
    }
    fMails.close();
    fGlobals.close();

    QSettings settings(globalFile, QSettings::IniFormat);
    settings.beginGroup("globals");
    settings.setValue("uidvalidity", uidvalidity);
    settings.setValue("subscribe", 1);
    settings.endGroup();

    return true;
}





//! ////////////////////////////////////////////////////////////////////////
// Créer les sous-dossiers et fichiers de base pour les comptes

void Fonctions::preparerMail(QString value)
{

    value = value.trimmed().toLower();
    QString user;
    QString domaine(value);
    QStringList userDomain(value.split("@"));

    if(userDomain.count() > 1) // symbole @ existe
    {
        user = userDomain.at(0);
        domaine = userDomain.at(1);
    }


    const QString &domaineDir(cfg->_dataDir + domaine + "/");
    const QString &confDir(domaineDir + "@conf/");
    const QString &fileDomaineFiltres = cfg->_fileFiltres.arg(domaine);
    const QString &fileMails = cfg->_fileMails.arg(domaine);
    const QString &fileAlias = cfg->_fileAlias.arg(domaine);
    const QString &fileListes = cfg->_fileListes.arg(domaine);
    const QString &fileDomaineGreyList = cfg->_fileDomaineGreyListingTriplets.arg(domaine);
    const QString &fileDomaineRbls = cfg->_fileDomaineRbls.arg(domaine);
    const QString &fileDomaineSignature = cfg->_fileDomaineSignature.arg(domaine);


    QStringList listDir, listFile;

    listDir << domaineDir << confDir;
    QDir d;
    foreach(const QString &dir, listDir)
    {
        if(! d.exists(dir) && ! d.mkpath(dir))
        {
            msgBoxHtml("Impossible de créer le sous-dossier " + dir +
                       "Veuillez le créer manuellement", "", 3);
            exit(404);
        }
    }


    listFile << fileMails
             << fileAlias << fileDomaineFiltres << fileDomaineSignature
             << fileListes << fileDomaineGreyList << fileDomaineRbls;

    QFile f;
    foreach(const QString &file, listFile)
    {
        f.setFileName(file);
        if(! f.open(QIODevice::ReadWrite | QIODevice::Append))
        {
            msgBoxHtml("Impossible d'ouvrir le fichiersss <c:red>" + file +
                       "</c> en lecture/ecriture ! Veuillez lui appliquer un chmod <b>777</B>",
                       "", 3);
            exit(404);
        }
        f.close();


        if(file == fileDomaineRbls)
        {
            QSettings settings1(cfg->_fileDomaineRbls.arg(domaine), QSettings::IniFormat);
            settings1.beginGroup("z" + regenererMessageId());
            settings1.setValue("dns", "bl.spamcop.net");
            settings1.setValue("etat", "0");
            settings1.endGroup();

            QSettings settings2(cfg->_fileDomaineRbls.arg(domaine), QSettings::IniFormat);
            settings2.beginGroup("z" + regenererMessageId());
            settings2.setValue("dns", "dnsbl.sorbs.net");
            settings2.setValue("etat", "0");
            settings2.endGroup();

            QSettings settings3(cfg->_fileDomaineRbls.arg(domaine), QSettings::IniFormat);
            settings3.beginGroup("z" + regenererMessageId());
            settings3.setValue("dns", "zen.spamhaus.org");
            settings3.setValue("etat", "1");
            settings3.endGroup();
        }

    }



    if(! user.isEmpty())
    {

        const QString &fileMailsFiltres = cfg->_fileMailsFiltres.arg(domaine).arg(user);
        const QString &fileMailsListes = cfg->_fileMailsListes.arg(domaine).arg(user);
        const QString &fileCompteGreyList = cfg->_fileCompteGreyListingTriplets.arg(domaine).arg(user);
        const QString &fileUids = cfg->_fileUids.arg(domaine).arg(user);
        const QString &fileSignatureEtRepondeur = cfg->_fileSignatureEtRepondeur.arg(domaine).arg(user);

        const QString &userDir(cfg->_mailDir.arg(domaine, user));
        const QString &userConfDir(userDir + "@conf");

        listDir.clear();
        listDir << userDir << userConfDir;

        foreach(const QString &dir, listDir)
        {
            if(! d.exists(dir) && ! d.mkpath(dir))
            {
                msgBoxHtml("Impossible de créer le sous-dossier " + dir +
                           "Veuillez le créer manuellement", "", 3);
                exit(404);
            }
        }

        QStringList subDirs(QStringList() << "Drafts" << "Junk" << "INBOX" << "Sent" << "Trash");
        int i(1);
        foreach(const QString &myDir, subDirs)
        {
            QString userDirs(userDir + base64Encode(myDir));
            if(! d.exists(userDirs) && ! creatDirectory(userDirs, i))
            {
                msgBoxHtml("Impossible de créer le sous-dossier <c:red>" + userDirs +
                           "Veuillez le créer manuellement", "", 3);
                exit(404);
            }
            i++;
        }

        listFile.clear();
        listFile << fileUids << fileSignatureEtRepondeur
                 << fileMailsFiltres << fileMailsListes << fileCompteGreyList;

        QFile f;
        foreach(const QString &file, listFile)
        {
            f.setFileName(file);
            if(! f.open(QIODevice::ReadWrite | QIODevice::Append))
            {
                msgBoxHtml("Impossible d'ouvrir le fichiersss <c:red>" + file +
                           "</c> en lecture/ecriture ! Veuillez lui appliquer un chmod <b>777</B>",
                           "", 3);
                exit(404);
            }
            f.close();
        }



        QSettings settings(fileUids, QSettings::IniFormat);
        settings.beginGroup("globals");
        settings.setValue("nextUid", 1);
        settings.setValue("nextUidvalidity", i); // Pas de (i + 1) Tested
        settings.setValue("subscribe", 1);
        settings.setValue("marked", 1);
        settings.endGroup();

    }

}











//! ////////////////////////////////////////////////////////////////////////
// Detecter une adrsse mail dans une chaine
// "Prénom Nom" <adresse@domaine.tld> => adresse@domaine.tld

QString Fonctions::detecterMail(const QString &mail) const
{
    QString sOut = mail;

    if (sOut.indexOf("<") >= 0)
    {
        int iStartPos = sOut.indexOf("<") + 1;
        int iEndPos = sOut.indexOf(">", iStartPos);
        sOut = sOut.mid(iStartPos, iEndPos - iStartPos);
    }

    return sOut.trimmed();
}









//! ////////////////////////////////////////////////////////////////////////
// Detecter la valeur d'une entête (header) d'un message
// Message-Id : 1234[\r\n] => 1234
// Reply-To : mail@domaine.tld[\r\n] => mail@domaine.tld

QString Fonctions::headerReturnValues(QString header, const QString &values)
{
    QString headers(returnAllHeadres(values));

    const QStringList &list(headers.replace(QRegExp("\\r\\n"), "\n").split("\n"));
    const int &count(list.count());
    QString line, trimmedLine, returnValue, headerReplaced;
    headerReplaced = header;
    headerReplaced.replace("-", "");
    int i(0);
    while(i < count)
    {

        line = list.at(i);
        i++;
        trimmedLine = line;
        trimmedLine = trimmedLine.trimmed().replace("-", "");

        if(trimmedLine.startsWith(headerReplaced, Qt::CaseInsensitive))
        {
            returnValue = line;

            while(i < count)
            {
                line = list.at(i);
                if(line.startsWith(" ") || line.startsWith("\t"))
                {
                    returnValue += line;
                }
                else
                {
                    break;
                }

                i++;
            }

            break;
        }

    }




    return returnValue.replace(QRegExp(header + "\\s*:\\s*", Qt::CaseInsensitive), "");

}







QString Fonctions::returnAllHeadres(const QString &values)
{

    QString headres, contents;
    QFile f(values);

    if(f.exists())
    {
        f.open(QIODevice::ReadOnly);
        QTextStream in(&f);
        contents = in.readAll();
        f.close();
    }
    else
    {
        contents = values;
    }


    const QStringList &list(contents.replace("\r\n", "\n").split("\n"));
    int i(0), j(0);
    while(i < list.count())
    {
        QString line(list.at(i) + "\r\n");
        i++;
        headres += line;
        // S'arréter au niveau des Header [headers(\r\n\r\n)Body] [[[
        if(line.trimmed().isEmpty())
        {
            j++;
        }
        else
        {
            j = 0;
        }
        if(j >= 1 || i >= 100)
        {
            break;
        }
        // ]]]
    }

    return headres.trimmed();

}




//! ////////////////////////////////////////////////////////////////////////
// Rajouter les entêtes manquantes conformement aux recommandations de la RFC

QString Fonctions::addHeader(
        QString const &hostConnectedIp,
        QString const &from, QString const &messageId,
        QString const &authUser, QString const &contents
        )
{





    QString returnValue("Received: from ([" + hostConnectedIp + "])"
                                                                "\r\n\twith aMailServer " + cfg->defaultDomain + " (" + aMailServerIpAddress() + ") ;"
                                                                                                                                                 "\r\n\t"+ timeStampMail() + "\r\n");

    QString msgReturnPath(headerReturnValues("Return-Path", contents));
    QString msgMessageId(headerReturnValues("Message-ID", contents));

    QString msgAuthUser(headerReturnValues("X-AuthUser", contents));

    if(msgReturnPath.isEmpty())
    {
        returnValue += "Return-Path: <" + from + ">\r\n";
    }

    if(msgMessageId.isEmpty())
    {
        returnValue += "Message-ID: <" + messageId + "@" + cfg->defaultDomain  + ">\r\n";
    }

    if(msgAuthUser.isEmpty() && ! authUser.isEmpty())
    {
        returnValue += "X-AuthUser: <" + authUser + ">\r\n";
    }

    return returnValue;
}









//! ////////////////////////////////////////////////////////////////////////
// gestion des repondeurs (domaines et comptes)

QStringList Fonctions::gestionRepondeur(QString user, QString domaine) const
{

    QStringList returnList;
    returnList << "" << "" << "";

    user = user.toLower().trimmed();
    domaine = domaine.toLower().trimmed();

    // Option répondeur (pour le domaine et donc tous ses comptes) [[[
    QSettings settingsDomaine(cfg->_fileDomaines, QSettings::IniFormat);
    settingsDomaine.beginGroup(domaine);
    QString permettreRepondeur(
                settingsDomaine.value("permettreRepondeur").toString().trimmed());
    settingsDomaine.endGroup();


    if(permettreRepondeur != "1")
    {
        return returnList;
    }
    // ]]]



    // Recherche du sujet/message [[[
    QFile file(cfg->_fileSignatureEtRepondeur.arg(domaine).arg(user));

    if(! file.exists())
    {
        return returnList;
    }


    file.open(QIODevice::ReadOnly);
    QTextStream in(&file);
    QString contents(in.readAll().trimmed());
    file.close();
    if(contents.isEmpty())
    {
        return returnList;
    }
    // ]]]



    // Parametres du repondeur [[[
    QSettings settings(cfg->_fileMails.arg(domaine), QSettings::IniFormat);
    settings.beginGroup(user);
    QString repondeur(settings.value("repondeur").toString().trimmed());
    QString repondeurExpirTxt(settings.value("repondeurExpire").toString().trimmed());
    settings.endGroup();
    // ]]]

    QString repondeurExpir(repondeurExpirTxt.replace("/", ""));
    repondeurExpir.toLongLong();

    // Verifier que le repondeur est actif [[[
    QString strDate(QDateTime::currentDateTime().toString("ddMMyyyy"));
    strDate.toLongLong();

    if(repondeur != "1" || (strDate >= repondeurExpir && repondeurExpirTxt != "0" && ! repondeurExpirTxt.isEmpty()))
    {
        return returnList;
    }
    // ]]]



    QRegExp rx;
    rx.setMinimal(true);
    rx.setCaseSensitivity(Qt::CaseInsensitive);

    rx.setPattern("\\s*<\\s*sujet\\s*>(.*)<\\s*/\\s*sujet\\s*>\\s*");
    rx.indexIn(contents);
    QString sujet(rx.capturedTexts().at(1).trimmed());

    rx.setPattern("\\s*<\\s*repondeurText\\s*>(.*)<\\s*/\\s*repondeurText\\s*>\\s*");
    rx.indexIn(contents);
    QString repondeurText = rx.cap(1).trimmed();

    rx.setPattern("\\s*<\\s*repondeurHtml\\s*>(.*)<\\s*/\\s*repondeurHtml\\s*>\\s*");
    rx.indexIn(contents);
    QString repondeurHtml = rx.cap(1).trimmed();
    repondeurHtml.replace(QRegExp("\r|\n"), "");

    // Balise repondeur non renseignée
    if(repondeurText.isEmpty() && repondeurHtml.isEmpty())
    {
        return returnList;
    }

    returnList.clear();

    returnList << sujet << repondeurText << repondeurHtml;

    return returnList;
}









//! ////////////////////////////////////////////////////////////////////////
// Affichage d'alertes HTML

bool Fonctions::msgBoxHtml(QString msg, QString const &title, int const &type) const
{

    QMessageBox msgBox(0);

    switch(type) {

    case 0:
        msgBox.setWindowTitle("\t" + (! title.isEmpty() ? title : "Nota Bene") + "\t");
        msgBox.setIcon(QMessageBox::NoIcon);
        break;

    case 2:
        msgBox.setWindowTitle("\t" + (! title.isEmpty() ? title : "Votre attention") + "\t");
        msgBox.setIcon(QMessageBox::Warning);
        break;

    case 3:
        msgBox.setWindowTitle("\t" + (! title.isEmpty() ? title : "Erreur !") + "\t");
        msgBox.setIcon(QMessageBox::Critical);
        break;

    case 4:
        msgBox.setWindowTitle("\t" + (! title.isEmpty() ? title : "Question") + "\t");
        msgBox.setIcon(QMessageBox::Question);
        msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
        break;

    default:
        msgBox.setWindowTitle("\t" + (! title.isEmpty() ? title : "Information") + "\t");
        msgBox.setIcon(QMessageBox::Information);
        break;
    }


    msgBox.setTextFormat(Qt::RichText);
    QIcon icon(":/icones/48/aMailServer.png");
    msgBox.setWindowIcon(icon);

    QRegExp rx;
    rx.setMinimal(true);
    rx.setCaseSensitivity(Qt::CaseInsensitive);
    rx.setPattern("<\\s*c\\s*:\\s*#?\\s*([a-zA-z0-9]+)\\s*>");
    msg.replace(rx, "<font color=\"\\1\">");
    rx.setPattern("<\\s*/\\s*c\\s*>");
    msg.replace(rx, "</font>");
    msg.replace(":)", "<img src=\":/icones/16/smile.gif\">");
    msg.replace(":-)", "<img src=\":/icones/16/smile.gif\">");
    msg.replace(":(", "<img src=\":/icones/16/frown.gif\">");
    msg.replace(":-(", "<img src=\":/icones/16/frown.gif\">");
    msgBox.setText(msg + "<br>");

    if(type != 4)
        msgBox.setStandardButtons(QMessageBox::Ok);

    int ret = msgBox.exec();
    if(ret == QMessageBox::Yes)
        return true;
    return false;
}






//! ////////////////////////////////////////////////////////////////////////
// Detecter si un compte est local (géré par aMailServer)

bool Fonctions::mailExists(QString mail, QString domaine)
{
    mail = mail.trimmed().toLower();
    domaine = domaine.trimmed().toLower();
    if(mail.isEmpty() || domaine.isEmpty()) return false;

    QSettings settings(cfg->_fileMails.arg(domaine), QSettings::IniFormat);
    settings.beginGroup(mail);
    return settings.allKeys().count() > 2;
}

//! ////////////////////////////////////////////////////////////////////////
// Detecter si un domaine est local (géré par aMailServer)

bool Fonctions::domaineExists(QString domaine)
{
    domaine = domaine.trimmed().toLower();
    if(domaine.isEmpty()) return false;

    QSettings settings(cfg->_fileDomaines, QSettings::IniFormat);
    settings.beginGroup(domaine);
    return settings.allKeys().count() > 2;
}




bool Fonctions::domaineExpired(QString const &domaine) const
{

    QString expire(iniReturnValue(cfg->_fileDomaines, domaine, "expire"));
    expire.replace("/", "");

    QDate expireDate = QDate::fromString(expire, "ddMMyyyy");

    if(expire.toInt() > 0 && expireDate < QDate::currentDate())
    {
        return true;
    }

    return false;
}





bool Fonctions::accountExpired(QString const &user, QString const &domaine) const
{

    QString expire(iniReturnValue(cfg->_fileMails.arg(domaine), user, "expire"));
    expire.replace("/", "");
    QDate expireDate = QDate::fromString(expire, "ddMMyyyy");

    if(expire.toInt() > 0 && expireDate < QDate::currentDate())
    {
        return true;
    }

    return false;
}



int Fonctions::minMax(QStringList const &list, bool const &type) const
{
    if(list.count() < 1) return 0;

    QList<int> intList;
    foreach(QString str, list)
    {
        intList << str.toInt();
    }
    qSort(intList.begin(), intList.end());

    return (intList.at(type ? 0 : intList.count() -1));
}


QString Fonctions::iniReturnValue(const QString &file, QString const &groupe, QString const &directive) const
{
    if(! QFile::exists(file)) return "";

    QSettings settings(file, QSettings::IniFormat);
    settings.beginGroup(groupe);
    QString returnValue(settings.value(directive).toString().simplified());
    settings.endGroup();

    return returnValue;
}






QString Fonctions::nettoyageFlags(QString flags)
{
    // flags = flags.toLower().replace(QRegExp("[^a-z0-9\\*\\$ ]+"), "");
    flags = flags.toLower().replace("\\", "");
    flags = flags.replace(QRegExp("[ ]+"), " ");

    QStringList tmpFlags(flags.trimmed().split(" "));
    tmpFlags.removeDuplicates();

    return tmpFlags.join(" ");
}





QString Fonctions::prepareFlags(const QString &flags)
{
    QString returnFlags;
    QStringList listFlags(nettoyageFlags(flags).split(" "));
    listFlags.removeDuplicates();
    foreach(const QString &strFlags, listFlags)
    {
        if(strFlags.trimmed().isEmpty()) continue;

        returnFlags += (strFlags.startsWith("$") ? strFlags : "\\" + strFlags) + " ";
    }

    return returnFlags.trimmed();
}


void Fonctions::addNewMsg(const QString &user, const QString &domaine,
                          const QString &msgId, const int &size, const QString &dir, const QString &flags)
{

    QString stringFlags(nettoyageFlags(flags));
    const QString &inbox(base64Encode("INBOX"));

    QString userDir(cfg->_mailDir.arg(domaine).arg(user));
    QString mIniFile((! dir.isEmpty() ? dir : userDir + inbox) + "/mails.ini");

    QSettings mSettings(mIniFile, QSettings::IniFormat);
    QStringList listMsg(mSettings.childGroups());
    if(listMsg.count() < 1)
    {
        listMsg << "0";
    }
    int maxId(minMax(listMsg, false) + 1);

    QString currentId(QString::number(maxId));
    QString gIniFile(cfg->_fileUids.arg(domaine).arg(user));
    QSettings gSettings(gIniFile, QSettings::IniFormat);
    gSettings.beginGroup("globals");
    qint64 nextUid(gSettings.value("nextUid").toString().toLongLong());
    nextUid = nextUid > 0 ? nextUid : 1;

    gSettings.setValue("nextUid", nextUid + 1);
    gSettings.endGroup();

    mSettings.beginGroup(currentId);
    mSettings.setValue("uid", nextUid);
    mSettings.setValue("file", msgId);
    mSettings.setValue("size", size);
    mSettings.setValue("flags", stringFlags);
    mSettings.setValue("dateText", timeStampMail());
    mSettings.setValue("dateTime", timeStampSecs());
    mSettings.endGroup();
}





void Fonctions::updateIniDirective(const QString &groupe, const QString &iniFile, const QString &directive, const QString &newValue) const
{
    if(groupe.isEmpty() || ! QFile::exists(iniFile) || directive.isEmpty())
    {
        return;
    }


    QSettings settings(iniFile, QSettings::IniFormat);
    settings.beginGroup(groupe);

    QStringList listKeys(settings.childKeys());

    if(listKeys.count() < 1 || ! listKeys.contains(directive))
    {
        return;
    }
    settings.setValue(directive, newValue);
    settings.endGroup();
}




/**
        Suppression recursive de sous-dossiers
        */

bool Fonctions::removeDir(QString dirPath)
{
    dirPath = chemain(dirPath + "/");
    if(dirPath == "/")
    {
        return false;
    }
    QDir folder(dirPath);
    folder.setFilter(QDir::NoDotAndDotDot | QDir::AllEntries | QDir::System | QDir::Hidden);

    foreach(QFileInfo fileInfo, folder.entryInfoList())
    {
        if(fileInfo.isDir())
        {
            removeDir(fileInfo.filePath());
        }
        else
        {
            QFile::remove(fileInfo.filePath());
        }
    }

    folder.rmdir(dirPath);

    return true;
}




QStringList Fonctions::listeDomaines() const
{
    QStringList listReturn;
    QString iniFile(cfg->_fileDomaines);
    QSettings settings(iniFile, QSettings::IniFormat);

    foreach(QString key, settings.childGroups())
    {
        listReturn << key.toLower().trimmed();
    }

    return listReturn;
}






QStringList Fonctions::listeComptes(QString const &domaine) const
{
    QStringList listReturn;
    QString iniFile(cfg->_fileMails.arg(domaine));
    QSettings settings(iniFile, QSettings::IniFormat);

    foreach(QString key, settings.childGroups())
    {
        listReturn << key.toLower().trimmed();
    }

    return listReturn;
}





