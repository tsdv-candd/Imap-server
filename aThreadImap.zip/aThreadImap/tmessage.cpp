#include "tmessage.h"

bool TMessage::isCover() {
    return isMultipart() || isRfc822();
}

bool TMessage::isMultipart() {
    return Header.ContentType.Type == "multipart";
}

bool TMessage::isRfc822() {
    return Header.ContentType.Type == "message" && Header.ContentType.SubType == "rfc822";
}

