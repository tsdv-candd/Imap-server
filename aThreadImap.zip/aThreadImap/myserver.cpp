
#include "myserver.h"

#include "sslServer.h"

#include <QCoreApplication>
#include <QHostAddress>
#include <QSslSocket>
#include <QThread>
#include <QFileInfo>



myServer::myServer(const QString grp, QObject *parent) : QThread(parent)
{

    Conf cfg;
    QFileInfo info(__FILE__);
    QString path(info.absoluteFilePath().replace(info.fileName(), ""));

    QSettings settings(cfg._fileMultiHoming, QSettings::IniFormat);

    settings.beginGroup(grp);
    this->grp = grp;
    this->addr = settings.value("addr").toString().simplified();
    this->server = settings.value("server").toString().simplified().toUpper();
    this->port = settings.value("port").toString().simplified().toLongLong();
    this->security = settings.value("security").toString().simplified().toUpper();
    this->certificate = path + settings.value("certificate").toString().simplified();
    this->key = path + settings.value("key").toString().simplified();
    settings.endGroup();


    if(security == "SSL")
    {
        this->protocol = QSsl::TlsV1SslV3;
    }
    else if(security == "TLS" || security == "STARTTLS0" || security == "STARTTLS1")
    {
        this->protocol = QSsl::SecureProtocols;
    }
    else // if(security == "NO")
    {
        this->protocol = QSsl::UnknownProtocol;
    }

    fctn = new Fonctions;

}





void myServer::run()
{

    if(server != "IMAP")
    {
        return;
    }




    QHostAddress address(addr);
    SslServer *sslServer = new SslServer;

    QString un = "NO";
    const QStringList listProtocol(QStringList() << "SSL" << "TLS" << "STARTTLS0" << "STARTTLS1");
    if(listProtocol.contains(security, Qt::CaseInsensitive))
    {

        if(! sslServer->setSslLocalCertificate(certificate))
        {
            qDebug() << "Error! Certificate [" + certificate + "] in entry [" + grp + "] can not be loaded.";
           // fctn->log("Error! Certificate [" + certificate + "] in entry [" + grp + "] can not be loaded.");
            return;
        }
        else
        {
            qDebug() << "OK. Certificate [" + certificate + "] in entry [" + grp + "] loaded successfully.";
          //  fctn->log("OK. Certificate [" + certificate + "] in entry [" + grp + "] loaded successfully.");
        }

        if(! sslServer->setSslPrivateKey(key))
        {
            qDebug() << "Error! Key [" + key + "] in entry [" + grp + "] can not be loaded.";
            fctn->log("Error! Key [" + key + "] in entry [" + grp + "] can not be loaded.");
            return;
        }
        else
        {
            qDebug() << "OK. Key [" + key + "] in entry [" + grp + "] loaded successfully.";
        //    fctn->log("OK. Key [" + key + "] in entry [" + grp + "] loaded successfully.");
        }

        un = security;

        // STARTTLS
        un.replace("0", "");
        un.replace("1", "");

        sslServer->setSslProtocol(protocol);
    }


    sslServer->setParams(grp, addr, port, security, protocol, certificate, key);

    QString str;

    if (sslServer->listen(address, port))
    {
        str = "\t\t+ Now listening on " + addr + ":" + QString::number(port) + " with " + un + " secure mode";
        fctn->log(str);
        qDebug() << str;
    }
    else
    {
        str = "\t\t- Error! Could not bind to " + addr + ":" + QString::number(port) + " with " + un + " secure mode";
        fctn->log(str);
        qDebug() << str;
        return;
    }

    exec();
}
