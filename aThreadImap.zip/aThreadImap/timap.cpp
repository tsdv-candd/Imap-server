#include "timap.h"
#include <QFile>
#include <QTextStream>
#include <QRegularExpression>
#include <QStack>
#include <QDebug>

/* Defaults:
 * Content-type: text/plain; charset=us-ascii
 * Content-Transfer-Encoding: 7BIT
*/

const QString crlf = "\r\n";
const int crlfLength = 2;
bool see = false;


bool TImap::startPositionLessThan(const QSharedPointer<TFieldInfo> fieldInfo1, const QSharedPointer<TFieldInfo> fieldInfo2)
{
    return fieldInfo1->startPosition < fieldInfo2->startPosition;
}

QSharedPointer<TMessage> TImap::parseString(QString imfString) {
    QSharedPointer<TMessage> res(new TMessage);
    res->root = res;
    res->startOffset = 0;
    res->rawText = imfString;

    TImfPhase phase = TImap::HeaderReading;

    int startPosition = 0;
    int endPosition;

    QStack<QSharedPointer<TMessage> > coverStack;
    QStack<QString> boundaryStack;

    QSharedPointer<TMessage> currentMessage(res);

    while (startPosition >= 0 && startPosition < imfString.length())
    {
        endPosition = imfString.indexOf(crlf,startPosition);
        if (endPosition >=0) endPosition+=crlfLength;

        if (phase == TImap::HeaderReading) {
            while (endPosition >= 0 && endPosition < imfString.length()
                   && imfString[endPosition].isSpace() && imfString[endPosition] != '\r') {
                endPosition = imfString.indexOf(crlf,endPosition);
                if (endPosition >=0) endPosition+=crlfLength;
            }
        }

        QString currentBoundary = boundaryStack.isEmpty() ? "" : boundaryStack.top();

        QString line = imfString.mid(startPosition,endPosition-startPosition);

        if (currentMessage) {
            bool boundaryFound = false;
            bool isEnd;

            if (currentBoundary != "") {
                QRegularExpression boundaryRegex(QString("^(?<boundary>--%1)(?<end>--)?").arg(currentBoundary),
                                                 //QRegularExpression::CaseInsensitiveOption
                                                 QRegularExpression::DontCaptureOption
                                                 |QRegularExpression::OptimizeOnFirstUsageOption
                                                 | QRegularExpression::DotMatchesEverythingOption);
                QRegularExpressionMatch m = boundaryRegex.match(line);

                if (m.hasMatch()) {
                    boundaryFound = true;

                    isEnd = m.captured("end") != "";
                }
            }

            if (boundaryFound)
            {
                do {
                    QSharedPointer<TMessage> coverMessage = coverStack.top();

                    if (isEnd && coverMessage->isMultipart()) {
                        boundaryStack.pop();
                        coverStack.pop();
                        coverMessage->endOffset = endPosition;
                        if (coverMessage->bodyStartOffset < 0) coverMessage->bodyStartOffset = coverMessage->endOffset;
                        break;
                    }
                    else if (coverMessage->isRfc822()) {
                        coverStack.pop();
                        coverMessage->endOffset = startPosition-crlfLength;
                        if (coverMessage->bodyStartOffset < 0 || coverMessage->bodyStartOffset > coverMessage->endOffset)
                            coverMessage->bodyStartOffset = coverMessage->endOffset;
                    }
                    else break;
                }
                while(true);

                if (!currentMessage->isCover()) {
                    currentMessage->endOffset = startPosition-crlfLength;
                    if (currentMessage->bodyStartOffset < 0 || currentMessage->bodyStartOffset > currentMessage->endOffset)
                        currentMessage->bodyStartOffset = currentMessage->endOffset;
                }

                currentMessage = coverStack.isEmpty() ? QSharedPointer<TMessage>() : coverStack.top();

                if (!isEnd) {
                    QSharedPointer<TMessage> coverMessage = coverStack.top();
                    currentMessage = QSharedPointer<TMessage>(new TMessage);
                    currentMessage->root = res;
                    currentMessage->startOffset = endPosition;
                    coverMessage->Body.Children.append(currentMessage);

                    phase = TImap::HeaderReading;
                }
            }
            else {
                switch(phase) {
                case TImap::HeaderReading: {
                    if (line == crlf) {
                        currentMessage->bodyStartOffset = endPosition;
                        if (currentMessage->isRfc822()) {
                            QSharedPointer<TMessage> coverMessage = coverStack.top();

                            currentMessage =  QSharedPointer<TMessage>(new TMessage);
                            currentMessage->root = res;
                            currentMessage->startOffset = endPosition;
                            coverMessage->Body.Children.append(currentMessage);

                            phase = TImap::HeaderReading;
                        }
                        else {
                            phase = TImap::BodyReading;
                        }
                    }
                    else {
                        QRegularExpression fieldRegex("^(?<key>[\\-\\w]+)\\s*\\:(?<value>.*)",
                                                      QRegularExpression::CaseInsensitiveOption
                                                      | QRegularExpression::DontCaptureOption
                                                      | QRegularExpression::OptimizeOnFirstUsageOption
                                                      | QRegularExpression::DotMatchesEverythingOption);
                        QRegularExpressionMatch m = fieldRegex.match(line);
                        if (m.hasMatch()) {

                            QString key = m.captured("key").toLower();
                            QString value = m.captured("value").trimmed();

                            QSharedPointer<TFieldInfo> fieldInfo = QSharedPointer<TFieldInfo>(new TFieldInfo);
                            fieldInfo->value = value;
                            fieldInfo->startPosition = startPosition;
                            fieldInfo->endPosition = endPosition;

                            currentMessage->Header.Items.insertMulti(key,fieldInfo);

                            if (key == "content-type") {
                                QRegularExpression contentTypeRegex("(?<type>[\\w]+)/(?<subType>[\\w\\.-]+)(?<parameters>.*)",
                                                                    QRegularExpression::CaseInsensitiveOption
                                                                    | QRegularExpression::DontCaptureOption
                                                                    |QRegularExpression::OptimizeOnFirstUsageOption
                                                                    | QRegularExpression::DotMatchesEverythingOption);

                                QRegularExpressionMatch m = contentTypeRegex.match(value);
                                if (m.hasMatch()) {
                                    currentMessage->Header.ContentType.Type = m.captured("type").toLower();
                                    currentMessage->Header.ContentType.SubType = m.captured("subType").toLower();

                                    QRegularExpression parameterRegex(";\\s*(?<key>[^=]+)=(?<quoted>\")?(?<value>(?(quoted).+?(?=\")|[^;\"]+))(?(quoted)\"|)",
                                                                      QRegularExpression::CaseInsensitiveOption
                                                                      | QRegularExpression::DontCaptureOption
                                                                      |QRegularExpression::OptimizeOnFirstUsageOption
                                                                      | QRegularExpression::DotMatchesEverythingOption);

                                    QRegularExpressionMatchIterator matchIterator = parameterRegex.globalMatch(m.captured("parameters"));
                                    while (matchIterator.hasNext()) {
                                        QRegularExpressionMatch m = matchIterator.next();

                                        QString key = m.captured("key").trimmed().toLower();
                                        QString value = m.captured("value").trimmed();
                                        currentMessage->Header.ContentType.Parameters.insert(key,value);
                                    }

                                    if (currentMessage->isCover()) {
                                        coverStack.push(currentMessage);
                                        if (currentMessage->isMultipart()) {
                                            boundaryStack.push(currentMessage->Header.ContentType.Parameters.value("boundary"));
                                        }
                                    }
                                }
                            }
                            else if (key == "content-disposition") {
                                QRegularExpression contentDispositionRegex("(?<type>[\\w]+)(?<parameters>.*)",
                                                                           QRegularExpression::CaseInsensitiveOption
                                                                           | QRegularExpression::DontCaptureOption
                                                                           |QRegularExpression::OptimizeOnFirstUsageOption
                                                                           | QRegularExpression::DotMatchesEverythingOption);

                                QRegularExpressionMatch m = contentDispositionRegex.match(value);
                                if (m.hasMatch()) {
                                    currentMessage->Header.ContentDisposition.Type = m.captured("type").toLower();

                                    QRegularExpression parameterRegex(";\\s*(?<key>[^=]+)=(?<quoted>\")?(?<value>(?(quoted).+?(?=\")|[^;\"]+))(?(quoted)\"|)",
                                                                      QRegularExpression::CaseInsensitiveOption
                                                                      | QRegularExpression::DontCaptureOption
                                                                      |QRegularExpression::OptimizeOnFirstUsageOption
                                                                      | QRegularExpression::DotMatchesEverythingOption);

                                    QRegularExpressionMatchIterator matchIterator = parameterRegex.globalMatch(m.captured("parameters"));
                                    while (matchIterator.hasNext()) {
                                        QRegularExpressionMatch m = matchIterator.next();

                                        QString key = m.captured("key").trimmed().toLower();
                                        QString value = m.captured("value").trimmed();
                                        currentMessage->Header.ContentDisposition.Parameters.insert(key,value);
                                    }
                                }
                            }


                        }
                    }
                }
                    break;
                case TImap::BodyReading: {
                    //                    //Unused. Now body can be retreived by its start and end positions.
                    //                    if (!boundaryFound)
                    //                    {
                    //                        if (currentMessage->isCover())
                    //                        {
                    //                        }
                    //                        else {
                    //                            currentMessage->Body.InnerText += coverStack.isEmpty()
                    //                                    ? line
                    //                                    : (currentMessage->Body.InnerText == "" ? "" : crlf)
                    //                                      +line.remove(line.length()-crlfLength,crlfLength);
                    //                        }
                    //                    }
                }
                    break;
                }
            }
        }

        startPosition = endPosition;
    }

    //For standalone messages.
    if (res->endOffset < 0) {
        res->endOffset = imfString.length();
    }
    if (res->bodyStartOffset < 0) {
        res->bodyStartOffset = imfString.length();
    }

    return res;
}

QString TImap::loadFromFile(QString fileName) {
    QString res;

    QFile emlFile(fileName);

    if (emlFile.open(QFile::ReadOnly)) {
        QTextStream in(&emlFile);
        res = in.readAll();
        //QString allText = in.readAll();
        //res = emlFile.error() == QFile::NoError;
        emlFile.close();
    }

    return res;
}

QString TImap::fetchBody(QSharedPointer<TMessage> message, QString section, int origin, int octet) {
    QString res;
    see = false;
    if (section == "") {
        res = message->root->rawText.mid(message->startOffset, message->endOffset-message->startOffset);
        see = true;
    }
    else if (section == "header") {
        res = message->root->rawText.mid(message->startOffset, message->bodyStartOffset-message->startOffset);
    }
    else if (section.startsWith("header.fields")) {
        QRegularExpression fieldsRegex("header.fields(?<not>.not)?\\s*\\((?<fieldNames>[^\\)]*)\\)",
                                       QRegularExpression::CaseInsensitiveOption
                                       | QRegularExpression::DontCaptureOption
                                       | QRegularExpression::OptimizeOnFirstUsageOption
                                       | QRegularExpression::DotMatchesEverythingOption);
        QRegularExpressionMatch m = fieldsRegex.match(section);

        if (m.hasMatch()) {
            bool notPresent = m.captured("not") != "";
            QString fieldNames = m.captured("fieldNames").trimmed();

            QList<QSharedPointer<TFieldInfo> > list;
            QHashIterator<QString, QSharedPointer<TFieldInfo> > it(message->Header.Items);
            while (it.hasNext()){
                it.next();
                //QRegularExpression singleFieldRegex(QString("\\b%1\\b").arg(it.key()),
                QRegularExpression singleFieldRegex(QString("\\b(?<!\\-)%1(?!\\-)\\b").arg(it.key()),
                                                    QRegularExpression::CaseInsensitiveOption
                                                    //| QRegularExpression::DontCaptureOption
                                                    //| QRegularExpression::OptimizeOnFirstUsageOption
                                                    | QRegularExpression::DotMatchesEverythingOption);

                bool contains = fieldNames.contains(singleFieldRegex);
                if ((contains && !notPresent) || (!contains && notPresent)) {
                    list.append(it.value());
                }
            }

            qSort(list.begin(),list.end(),startPositionLessThan);

            foreach (QSharedPointer<TFieldInfo> fieldInfo, list) {
                res += message->root->rawText.mid(fieldInfo->startPosition, fieldInfo->endPosition-fieldInfo->startPosition);
            }
        }
    }
    else if (section == "mime") {
        //if (message != message->root) {
        res = message->root->rawText.mid(message->startOffset, message->bodyStartOffset-message->startOffset);
        //        }
        //        else {
        //            //Error???
        //            res = "";
        //        }
    }
    else if (section == "text") {
        res = message->root->rawText.mid(message->bodyStartOffset, message->endOffset-message->bodyStartOffset);
        see = true;
    }
    else {
        //Should be numbers.
        QString rest = section;
        QSharedPointer<TMessage> currentMessage = message;

        QRegularExpression numberRegex("(?<index>[^\\.]*)(\\.(?<rest>.*))?",
                                       QRegularExpression::CaseInsensitiveOption
                                       | QRegularExpression::DontCaptureOption
                                       | QRegularExpression::OptimizeOnFirstUsageOption
                                       | QRegularExpression::DotMatchesEverythingOption);
        QRegularExpressionMatch m = numberRegex.match(rest);

        if (m.hasMatch()) {
            bool ok = false;
            int index = m.captured("index").trimmed().toInt(&ok);
            rest = m.captured("rest").trimmed();

            if (ok) {
                if (index == 0) {
                    res = fetchBody(currentMessage,rest,origin,octet);
                }
                else {
                    index--;//Should become zero-based.

                    if (rest == "") {
                        rest = "text";
                        see = true;
                    }

                    QSharedPointer<TMessage> subMessage = currentMessage->isCover()
                            ? (index >= 0 && index < currentMessage->Body.Children.length()
                               ? currentMessage->Body.Children[index] : QSharedPointer<TMessage>())
                            : (index == 0 ? currentMessage : QSharedPointer<TMessage>());
                    if (!subMessage.isNull()) {
                        res = fetchBody(subMessage,rest,origin,octet);
                    }

                    //                    if (index >= 0 && index < currentMessage->Body.Children.length()) {
                    //                        currentMessage = currentMessage->Body.Children[index];
                    //                        res = fetchBody(currentMessage,rest,origin,octet);
                    //                    }
                }
            }
        }
    }

    if (origin >= 0 && octet >= 0) {
        res = res.mid(origin,octet);
    }

    return res;
}

QString TImap::fetchBody(QSharedPointer<TMessage> message, QString command, QString returnStr) {
    QString res;
    returnStr = returnStr.trimmed().toUpper();


    //    QRegularExpression commandRegex("body\\[(?<section>[^\\]]*)\\]((?<bracket>\\<)?(?<origin>[^\\.]+)\\.(?<octet>[^\\>]+)(?(bracket)\\>|))?",
    QRegularExpression commandRegex("body(?<peek>.peek)?\\[(?<section>[^\\]]*)\\]((?<bracket>\\<)?(?<origin>[^\\.]+)\\.(?<octet>[^\\>]+)(?(bracket)\\>|))?",
                                    QRegularExpression::CaseInsensitiveOption
                                    | QRegularExpression::DontCaptureOption
                                    | QRegularExpression::OptimizeOnFirstUsageOption
                                    | QRegularExpression::DotMatchesEverythingOption);
    QRegularExpressionMatch m = commandRegex.match(command);

    if (m.hasMatch()) {
        //QString peek = m.captured("peek").trimmed().toLower();
        QString sectionTmp = m.captured("section").trimmed();
        QString section = m.captured("section").toLower();
        QString origin = m.captured("origin").trimmed().toLower();
        QString octet = m.captured("octet").trimmed().toLower();

        bool ok;
        int nOrigin = origin.toInt(&ok);
        if (!ok) nOrigin = -1;
        int nOctet = octet.toInt(&ok);
        if (!ok) nOctet = -1;

        QString originInAnswer = origin == "" ? "" : QString("<%1>").arg(origin);
        QString answer = fetchBody(message, section, nOrigin, nOctet).trimmed();
        if(returnStr.isEmpty())
        {
            res = QString("BODY[%1]%2 {%3}\r\n%4").arg(sectionTmp,originInAnswer, QString::number(answer.length()), answer);
        }
        else
        {
            res = QString(returnStr + " {%1}\r\n%2").arg(QString::number(answer.length()), answer);
        }

    }

    return res;
}

QString TImap::fetchBodyStructure(QSharedPointer<TMessage> message) {
    QString res;

    bool hasContentType = message->Header.Items.contains("content-type");
    QString type = inQuote(message->Header.ContentType.Type, hasContentType, true, "\"text\"");
    QString subType = inQuote(message->Header.ContentType.SubType,hasContentType, true, "\"plain\"");

    QHash<QString,QString> messageParameters = message->Header.ContentType.Parameters;
    QString parameters = QString("(");
    for (QHash<QString, QString>::iterator it = messageParameters.begin(); it != messageParameters.end(); it++) {
        parameters += QString("%1\"%2\" \"%3\"").arg(it == messageParameters.begin() ? "": " ",it.key(),it.value());
    }
    parameters += ")";
    if (parameters == "()") parameters = "NIL";

    if (message->Header.ContentType.Type == "multipart") {
        res += "(";
        for (QList<QSharedPointer<TMessage> >::iterator it = message->Body.Children.begin(); it != message->Body.Children.end(); it++) {
            res += fetchBodyStructure(*it);
        }
        res += QString(" %1 %2").arg(subType,parameters);
    }
    else
    {
        QString bodyId = getAndQuote(message->Header.Items,"content-id");
        QString bodyDescription = getAndQuote(message->Header.Items,"content-description");
        QString bodyEncoding = getAndQuote(message->Header.Items,"content-transfer-encoding",true,"\"7bit\"");

        //QString bodyText = message->textReference.toString();
        QString bodyText = QStringRef(&message->root->rawText,message->bodyStartOffset,
                                      message->endOffset-message->bodyStartOffset).toString();


        //        {
        //            QFile destFile("body.txt");
        //            destFile.open(QFile::WriteOnly);
        //            QTextStream out(&destFile);
        //            out << bodyText;
        //            destFile.flush();
        //            destFile.close();
        //        }

        //QString bodySize = QString::number(message->Body.InnerText.length());
        QString bodySize = QString::number(bodyText.length());

        res = QString("(%1 %2 %3 %4 %5 %6 %7")
                .arg(type, subType, parameters, bodyId, bodyDescription, bodyEncoding, bodySize);

        QStringRef endOfText(&bodyText, bodyText.length()-crlfLength, crlfLength);
        QString textSize = QString::number(bodyText.count(crlf)
                                           +(bodyText == "" ? 0 : 1)
                                           +(endOfText == crlf ? -1 : 0));

        if (message->isRfc822()) {
            QSharedPointer<TMessage> innerMessage = message->Body.Children[0];

            QString date = getAndQuote(innerMessage->Header.Items,"date");
            QString subject = getAndQuote(innerMessage->Header.Items, "subject");
            QString from = getAddressStructure(innerMessage->Header.Items.value("from"));
            QString sender = getAddressStructure(innerMessage->Header.Items.value("sender"));
            if (sender == "NIL") sender = from;
            QString replyTo = getAddressStructure(innerMessage->Header.Items.value("reply-to"));
            if (replyTo == "NIL") replyTo = from;
            QString to = getAddressStructure(innerMessage->Header.Items.value("to"));
            QString cc = getAddressStructure(innerMessage->Header.Items.value("cc"));
            QString bcc = getAddressStructure(innerMessage->Header.Items.value("bcc"));
            QString inReplyTo = getAndQuote(innerMessage->Header.Items,"in-reply-to");
            QString messageId = getAndQuote(innerMessage->Header.Items,"message-id");

            QString envelope = QString("(%1 %2 %3 %4 %5 %6 %7 %8 %9 ").arg(date,subject,from,sender,replyTo,to,cc,bcc,inReplyTo)
                    +messageId+")";

            QString innerBodyStructure = fetchBodyStructure(innerMessage);

            res += QString(" %1 %2 %3").arg(envelope, innerBodyStructure,textSize);
        }
        else if (message->Header.ContentType.Type == "text") {
            res += QString(" %1").arg(textSize);
        }
        else {
            //Should be NIL or empty???
        }

        QString bodyMd5 = getAndQuote(message->Header.Items,"content-md5");
        res += QString(" %1").arg(bodyMd5);
    }

    QString bodyDisposition;
    if (message->Header.ContentDisposition.Type == "") {
        bodyDisposition = "NIL";
    }
    else {
        QHash<QString,QString> messageParameters = message->Header.ContentDisposition.Parameters;
        QString parameters = QString("(");
        for (QHash<QString, QString>::iterator it = messageParameters.begin(); it != messageParameters.end(); it++) {
            parameters += QString("%1\"%2\" \"%3\"").arg(it == messageParameters.begin() ? "": " ",it.key(),it.value());
        }
        parameters += ")";

        if (parameters == "()") parameters = "NIL";

        bodyDisposition = QString("(\"%1\" %2)").arg(message->Header.ContentDisposition.Type,parameters);
    }

    QString bodyLanguage = getAndQuote(message->Header.Items,"content-language");
    QString bodyLocation = getAndQuote(message->Header.Items,"content-location");

    res +=QString(" %1 %2 %3)").arg(bodyDisposition, bodyLanguage, bodyLocation);

    return res;
}

QString TImap::getAddressStructure(QSharedPointer<TFieldInfo> fieldInfo) {
    QString res;

    if (fieldInfo) {
        res = "(";

        QString addressLine = fieldInfo->value;

        QRegularExpression addressListRegex("(?<address>[^,]*)",
                                            QRegularExpression::CaseInsensitiveOption
                                            | QRegularExpression::DontCaptureOption
                                            | QRegularExpression::OptimizeOnFirstUsageOption
                                            | QRegularExpression::DotMatchesEverythingOption);

        QRegularExpressionMatchIterator matchIterator = addressListRegex.globalMatch(addressLine);
        while (matchIterator.hasNext()) {
            QRegularExpressionMatch m = matchIterator.next();

            QRegularExpression addressRegex("(?<quoted>\")?(?<name>(?(quoted).+?(?=\")|[^\\<]+))(?(quoted)\"|)"
                                            "\\s*\\<((?<adl>@[^\\:]*)\\:)?(?<quoted1>\")?(?<localPart>(?(quoted1).+?(?=\")|[^@]+))(?(quoted1)\"|)@(?<domain>[^>]+)\\>",
                                            QRegularExpression::CaseInsensitiveOption
                                            | QRegularExpression::DontCaptureOption
                                            | QRegularExpression::OptimizeOnFirstUsageOption
                                            | QRegularExpression::DotMatchesEverythingOption);

            QString address = m.captured("address").trimmed();
            QRegularExpressionMatch addressMatch = addressRegex.match(address);
            if (addressMatch.hasMatch()) {
                QString name = addressMatch.captured("name").trimmed();
                name = inQuote(name,name != "");

                QString addrAdl = addressMatch.captured("adl").trimmed();
                addrAdl = inQuote(addrAdl,addrAdl != "");

                QString localPart = addressMatch.captured("localPart").trimmed();
                localPart = inQuote(localPart,localPart != "");

                QString domain = addressMatch.captured("domain").trimmed();
                domain = inQuote(domain,domain != "");

                res += QString("(%1 %2 %3 %4)").arg(name,addrAdl,localPart,domain);
            }
        }

        res += ")";

        if (res == "()") res = "NIL";
    }
    else {
        res = "NIL";
    }

    return res;
}

QString TImap::getAndQuote(QHash<QString,QSharedPointer<TFieldInfo> > hash, QString key, bool useDefault, QString _default) {
    QString res;

    bool exists = hash.contains(key);
    QString value = exists ? hash.value(key)->value : "";
    res = inQuote(value,exists,useDefault,_default);

    return res;
}

QString TImap::inQuote(QString value, bool exists, bool useDefault, QString _default) {
    QString res;

    if (exists) {
        QString quote = value.length()>0 && value[0]=='\"' ? "" : "\"";
        res = QString("%1%2%1").arg(quote,value);
    }
    else {
        if (useDefault) {
            res = _default;
        }
        else {
            res = "NIL";
        }
    }

    return res;
}

////For debugging purpose
//void TImap::showMessageTree(QSharedPointer<TMessage> rootMessage) {
//    if (rootMessage) {
//        qDebug() << rootMessage->Header.ContentType.Type << rootMessage->Header.ContentType.SubType
//                 << rootMessage->Header.Items.value("content-transfer-encoding")
//                 << rootMessage->startOffset << " " << rootMessage->bodyStartOffset<< " " << rootMessage->endOffset;

//        foreach (QSharedPointer<TMessage> item, rootMessage->Body.Children) {
//            showMessageTree(item);
//        }
//    }
//}
