#ifndef TMESSAGE_H
#define TMESSAGE_H

#include<QHash>
#include<QString>
#include<QList>
#include<QSharedPointer>

struct TFieldInfo {
    QString value;
    int startPosition;
    int endPosition;
};

struct TMessage {
    struct THeader {
        QHash<QString,QSharedPointer<TFieldInfo> > Items;
        struct TContentType {
            QString Type;
            QString SubType;
            QHash<QString,QString> Parameters;
        } ContentType;
        struct TContentDisposition {
            QString Type;
            QHash<QString,QString> Parameters;
        } ContentDisposition;
    } Header;
    struct TBody {
        //QString InnerText;
        QList<QSharedPointer<TMessage> > Children;
    } Body;

    int startOffset = -1;
    int endOffset = -1;
    int bodyStartOffset = -1;
    QSharedPointer<TMessage> root;
    QString rawText;

    bool isCover();
    bool isMultipart();
    bool isRfc822();
};

#endif // TMESSAGE_H
