
#include "listes.h"
#include "domaines.h"
#include "mails.h"

Listes::Listes()
{
    cfg = new Conf();
    fctn = new Fonctions();
}





bool Listes::listeExists(QString const &liste, QString const &domaine) const
{
    QSettings settings(cfg->_fileListes.arg(domaine), QSettings::IniFormat);
    settings.beginGroup(liste.trimmed().toLower());
    return settings.allKeys().count() > 1;
}





QStringList Listes::listeValues(QString const &liste, const QString &domaine) const
{
    QStringList listReturn;
    Domaines d;
    Mails m;



    // Detection du compte {{{

    QSettings lSettings(cfg->_fileListes.arg(domaine), QSettings::IniFormat);
    lSettings.beginGroup(liste);
    QString idCompte(lSettings.value("idCompte").toString().trimmed());
    QString user(m.mailDetectCompteById(idCompte, domaine));
    lSettings.endGroup();

    // Erreur de configuration
    if(user.isEmpty())
    {
        return listReturn;
    }


    int domaineNombreMaxDeMailParListe(d.domaineReturnConf(domaine, "nombreMaxDeMailParListe").toInt());
    int compteNombreMaxDeMailParListe(m.mailReturnConf(user, "nombreMaxDeMailParListe", domaine).toInt());

    // }}}




    // Entrée de la lsite {{{

    QSettings mlSettings(cfg->_fileMailsListes.arg(domaine).arg(user), QSettings::IniFormat);
    mlSettings.beginGroup(liste);

    int i(0);
    foreach(QString const &key, mlSettings.allKeys())
    {

        if(! key.contains("@")) continue;

        int etat(mlSettings.value(key).toString().trimmed().toInt());

        if((domaineNombreMaxDeMailParListe > 0 && i >= domaineNombreMaxDeMailParListe) ||
                (compteNombreMaxDeMailParListe > 0 && i >= compteNombreMaxDeMailParListe))
        {
            break;
        }

        if(etat > 0)
        {
            listReturn << key.trimmed().toLower().replace("%40", "@");
        }
        i++;
    }
    mlSettings.endGroup();

    // }}}




    return listReturn;
}







QString Listes::listeReturnConf(QString const &liste, QString directive, QString const &domaine) const
{
    directive = directive.trimmed().toLower();

    QSettings settings(cfg->_fileListes.arg(domaine),
                       QSettings::IniFormat);
    settings.beginGroup(liste);
    QString returnValue(settings.value(directive).toString().trimmed());
    settings.endGroup();

    return returnValue.toUpper();
}


